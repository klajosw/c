 #include <stdio.h>
 #include <conio.h>           //clrscr    (main)
 #include <string.h>          //strcmp    (datumbeall2)
 #include <dos.h>             //getdate   (datumbeall3)
 #include <time.h>            //time,localtime  (datumbeall4)
 #include <alloc.h>           //malloc          (main)
	struct datum {
	 int ho;
	 int nap; };

  struct datum ma;

  void datumbeall(struct datum *dp, int a, int b);      // deklaraciok
  void datumbeall2(struct datum *dp, char *d);
  void datumbeall3(struct datum *dp);
  void datumbeall4(struct datum *dp);
  void datumkiir(struct datum *dp);
  int datumkul(struct datum *dp1, struct datum *dp2);

  void datumbeall(struct datum *dp, int a, int b)
  {
   dp->ho=a;   dp->nap=b;
  }

  void datumbeall2(struct datum *dp, char *d)
	{
	 if (strcmp(d,"karacsony")==0)  { dp->ho=12; dp->nap=25; }
	 if (*d=='h')                   { dp->ho=4;  dp->nap=12; } 
	 if (strcmp(d,"szulinap")==0)   { dp->ho=5;  dp->nap=8; }   
	}
	
  void datumbeall3(struct datum *dp)
	{
		struct date *dat;
		getdate( dat);
		dp->ho=dat->da_mon;  dp->nap=dat->da_day;
	}


  void datumbeall4(struct datum *dp)
	{
		time_t t=time(NULL);
		struct tm* tmm;
		tmm=localtime(&t);
		dp->ho=(tmm->tm_mon)+1;  dp->nap=tmm->tm_mday;
	}


  void datumkiir(struct datum *dp)
	{
	 printf("Megegyszer:%d.%d",dp->ho,dp->nap);
	}


  int datumkul(struct datum *dp1, struct datum *dp2)
	{
		struct datum e;   int eredm;
		e.nap=(dp2->nap-dp1->nap);  	e.ho=(dp2->ho-dp1->ho);
		if (e.nap<0)  {e.nap+=30; --e.ho;}
		if (e.ho<0)    e.ho+=12;    eredm=(e.ho*30+e.nap);
		return(eredm);
	}
		
		 
   main()
	 {      clrscr();
	 struct datum *dp,*dp2;
	 dp=(struct datum *)malloc(sizeof(struct datum)); dp2=&ma;   //pointereknek kezdoertek adasa
	 printf("\nHonap0:%d\nNap0:%d\n",dp2->ho,ma.nap);            //mind a 2 jo
	 datumbeall(dp,3,30); 
			printf("\nHonap1:%d\nNap1:%d\n",dp->ho,dp->nap);
	 datumbeall2(dp2,"karacsony"); 
			printf("\nHonap2:%d\nNap2:%d\n",dp2->ho,dp2->nap);
	 datumbeall3(dp);
			printf("\nHonap3:%d\nNap3:%d\n",dp->ho,dp->nap);
	 datumbeall4(dp);
			printf("\nHonap4:%d\nNap4:%d\n",dp->ho,dp->nap);
	 datumkiir(dp);   datumkiir(dp2);
	 printf("\nKulonbseg: %d",datumkul(dp,dp2));
	 }





