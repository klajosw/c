/* SIGNAL.C - szign�lok haszn�lata */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

#define PROMPT ':'
float a,b;
int    ok;


void sig_fpe(int i, int j)
 {
  printf("\n**** Signal:%d \t Tipusa:%d\n",i,j);
  printf("**** Hibas eredmeny!\n");
  a=b=1.0;
  ok=0;
 signal(SIGFPE,sig_fpe);
 }


void sig_int(int i)
 {
  char c;
  signal(SIGINT,sig_int);
  printf("\n**** Signal:%d ",i);
  printf("\n**** Valoban ki akar lepni a programbol?\n");
  c=getch();
  switch(c)
   {
     case 'I': case 'i' : case 'Y' : case 'y': exit(0);
     default: printf("Folytatom...\n");
   }
  signal(SIGINT,sig_int);
 }


main()
{
   char   puf[80];
   char   op;
   float  res;

   signal(SIGFPE,sig_fpe);
   signal(SIGINT,sig_int);

   while (putchar(PROMPT), scanf("%s",puf))
    {
      ok=1;
      if (puf[0]=='e') raise(SIGINT);
      if (sscanf(puf,"%f%c%f",&a,&op,&b)!=3) ok=0;

      switch(op) {
	case '+': res=a+b; break;
	case '-': res=a-b; break;
	case '*': res=a*b; break;
	case ':':
	case '/': res=a/b; break;
	default:
	   {   ok=0;
	       printf("\tHibas muvelet\n");
	   }
       }
     if (ok)
      {
       gotoxy(strlen(puf)+2,wherey()-1);
       printf("=%g\n",res);
      }
 }
}



