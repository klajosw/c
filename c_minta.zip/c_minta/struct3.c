#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define NELEM 7

main()
{
struct book {
	       char  nev [20];
	       char  cim [40];
	       int   ev;
	       float ar;
	       struct book * kovetkezo;
	     } *aktualis, *start=NULL, *elozo, *kovetkezo;


int index;

    /* Az els� elem kit�ntetett szereppel rendelkezik */
   /*  rajta kereszt�l lehet bel�pni a list�ba        */

   /* A lista fel�p�t�se �s az elemek v�letlen felt�lt�se */
   randomize();
   for (index = 0;index < NELEM;index++) {

      /* Mem�riafoglal�s */
      aktualis = (struct book *)malloc(sizeof(struct book));
      if (!aktualis) {
	 printf("\a\nNincs el�g mem�ria!\n");
	 return -1;
      }

      /* Az adatr�sz felt�lt�se */
      sprintf(aktualis->nev,"%03d Anonymous", index);
      sprintf(aktualis->cim,"Nothing %03d", index);
      aktualis->ev = 1900+random(100);
      aktualis->ar  = random(1000) * 1.5;
      aktualis->kovetkezo = NULL;

      /* L�ncol�si �s l�ptet�se m�veletek */
      /* Az �j elem l�ncol�sa az el�z� elemhez */
      if (index==0) /* els� elem */
	 start = elozo = aktualis;
      else {        /* tov�bbi elemek */
	elozo->kovetkezo = aktualis;
	/* Tov�bbl�p�s a list�ban */
	elozo = aktualis;
      }
   }

   /* A list�ban l�pkedve az elemek adatainak ki�r�sa */

   aktualis = start;
   printf("\n");
   do {
      printf("%-20s %-40s %5d %10.2f\n", aktualis->nev,
					 aktualis->cim,
					 aktualis->ev,
					 aktualis->ar  );
      aktualis = aktualis->kovetkezo;
   }  while (aktualis != NULL);


   /* A 4. sorsz�m� elem lokaliz�l�sa �s t�rl�se */
   /* a sorsz�moz�s 0-t�l kezd�dik !             */
   /* Lokaliz�l�s */
   aktualis = start;
   for (index = 0; index<4; index++) {
       elozo    = aktualis;
       aktualis = aktualis->kovetkezo;
  }
  /* T�rl�se -kif�z�s a l�ncb�l */
  elozo->kovetkezo = aktualis->kovetkezo;
  /* A ter�let felszabad�t�sa */
  free(aktualis);


   /* A list�ban l�pkedve az elemek adatainak ki�r�sa */

   aktualis = start;
   printf("\n");
   do {
      printf("%-20s %-40s %5d %10.2f\n", aktualis->nev,
					 aktualis->cim,
					 aktualis->ev,
					 aktualis->ar  );
      aktualis = aktualis->kovetkezo;
   }  while (aktualis != NULL);




   /* A 3. sorsz�m� elem lokaliz�l�sa �s m�g� */
   /* �j elem besz�r�sa                       */
   /* Lokaliz�l�s */
   aktualis = start;
   for (index = 0; index<3; index++)
       aktualis = aktualis->kovetkezo;

  /* Uj elem besz�r�sa */
  /* A ter�let lefoglal�sa �s felt�lt�se*/
   kovetkezo = (struct book *)malloc(sizeof(struct book));
   if (!kovetkezo) {
       printf("\a\nNincs el�g mem�ria!\n");
       return -1;
   }
   strcpy(kovetkezo->nev,"!!! Anonymous");
   strcpy(kovetkezo->cim,"Nothing !!!");
   kovetkezo->ev = 1999;
   kovetkezo->ar = 2222;
  /* Bef�z�s a l�ncba */
  kovetkezo->kovetkezo = aktualis->kovetkezo;
  aktualis->kovetkezo = kovetkezo;


   /* A list�ban l�pkedve az elemek adatainak ki�r�sa */

   aktualis = start;
   printf("\n");
   do {
      printf("%-20s %-40s %5d %10.2f\n", aktualis->nev,
					 aktualis->cim,
					 aktualis->ev,
					 aktualis->ar  );
      aktualis = aktualis->kovetkezo;
   }  while (aktualis != NULL);



   /* Helyes programoz�si gyakorlat - kil�p�s el�tt a */
   /* dinamikusan foglalt ter�letek felszabad�t�sa    */

   aktualis = start;
   do {
      kovetkezo = aktualis->kovetkezo;
      free(aktualis);
      aktualis = kovetkezo;
   } while (kovetkezo != NULL);
  start = NULL;
}
