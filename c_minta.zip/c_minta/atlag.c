/* ATLAG.C */

#include <stdio.h>

main()
{
int     i;
double  a[4], atlaga;

  for(i = 0; i < 4; i++)
  {
     printf("%d. sz�m : ", i+1); scanf("%lf",&a[i]);
  }
  atlaga = 0.0;
  for(i = 0; i < 4; i++)
    atlaga += a[i];
  printf("\nAz �tlag : %lf  %g  %e \n",atlaga, atlaga, atlaga);

}
