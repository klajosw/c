/* MALLOCPR.C */
#include <stdio.h>
#include <alloc.h>
typedef int ItemType;

main()
{
 ItemType *p;
  p = (ItemType*)malloc(sizeof(ItemType));
  *p = 2;
  printf("%d", *p);
  free(p);
}
