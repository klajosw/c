/* MATHERR.C - matematikai f�ggv�nyek hibakezel�se */

#include <stdio.h>
#include <math.h>
#include <string.h>

int matherr(struct exception *e)
{
  printf("---------------------\n");
  switch (e->type)
  {
    case DOMAIN:     printf("Ertelmezesi tartomany hiba!\n");
		     break;
    case SING:       printf("Argumentum hiba!\n");
		     break;
    case OVERFLOW:   printf("Tulcsordulas!\n");
		     break;
    case UNDERFLOW:  printf("Alulcsordulas!\n");
		     break;
    case PLOSS:
    case TLOSS:	     printf("Ertekes jegyek elvesztese!\n");
		     break;

    default:         printf("Nem ertelmezheto hiba!\n");
  }
  e->retval=0;
  if (!strcmp(e->name,"sqrt"))  e->retval=sqrt(-e->arg1);
}

main()
{
    printf("1.\t %lf\n",sqrt(-3));
    printf("2.\t %lf\n",log(0));
    printf("3.\t %lf\n",exp(1000));
    printf("4.\t %lf\n",exp(-1000));
    printf("5.\t %lf\n",sin(exp(70)));

}

