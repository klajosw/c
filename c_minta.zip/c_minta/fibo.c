#include <stdio.h>

unsigned long fibr(int n)
{
  if (n<2)
     return n;
  else
     return fibr(n-1) + fibr(n-2);
}


unsigned long fib( int n )
{
  unsigned long f0 = 0, f1 = 1, f2 = n;

  while (n-- > 1) {
       f2 = f0 + f1;
       f0 = f1;
       f1 = f2;
  }
  return f2;
}


main()
{
  int i;
  for (i=0;i<=20;i+=1){
    printf( "fibr(%d) = %lu\t\t", i, fibr(i) );
    printf( "fibo(%d) = %lu\n", i, fib(i) );
  }
}

