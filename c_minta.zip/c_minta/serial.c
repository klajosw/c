  /*-------------------------------------------------------------*
                              SERIAL.C

    A soros adatvitelt megval�s�t� program, amely a vez�rl�
    k�zvetlen programoz�s�val m�k�dik. Az biztons�gos adatfogad�s
    �rdek�ben a program megszak�t�st �s soros puffert haszn�l.

    ! A ford�t�skor a Test Stack Overflow opci�t OFF-ba aj�nlott !
    ! �ll�tani !                                                 !
   *-------------------------------------------------------------*/

  #include "serial.h"
  #include <dos.h>
  #include <conio.h>
  #include <stdio.h>
  #include <string.h>

  #define FALSE           0
  #define TRUE            (!FALSE)

  #define NOERROR         0       /* Nincs hiba             */
  #define BUFOVFL         1       /* A puffer t�lcsordult   */

  #define ESC             0x1B    /* ASCII Escape karakter  */
  #define SBUFSIZ         0x4000  /* A soros puffer m�rete  */

  int      serror          = NOERROR;
  int      portbase        = 0;
  void     interrupt (*oldvects[2])();

  static   char  scbuf[SBUFSIZ];
  unsigned int   startbuf        = 0;
  unsigned int   endbuf          = 0;

/*--------------------------------------*/
/* A kommunik�ci�s megszak�t�s kezel�se */
/* A be�rkez� karakter a pufferba ker�l */
/*--------------------------------------*/
  void   interrupt com_int(void)
  {
      disable();
      if ((inportb(portbase + IIR) & RX_MASK) == RX_ID)
      {
	  if (((endbuf + 1) & SBUFSIZ - 1) == startbuf)
	      serror = BUFOVFL;

	  scbuf[endbuf++] = inportb(portbase + RXR);
	  endbuf &= SBUFSIZ - 1;
      }

      /* A hardver interrupt v�g�nek jelz�se */
      outportb(ICR, EOI);
      enable();
  }

/*---------------------------------*/
/* Karakter ki�r�sa a soros portra */
/*---------------------------------*/
  int sputch(char x)
  {
      long int timeout = 0x0000FFFFL;

      outportb(portbase + MCR,  MC_INT | DTR | RTS);

      /* V�rakoz�s a Clear To Send jelre */
      while ((inportb(portbase + MSR) & CTS) == 0)
	  if (!(--timeout)) return (-1);

      timeout = 0x0000FFFFL;

      /* V�rakoz�s a k�szenl�ti jelre */
      while ((inportb(portbase + LSR) & XMTRDY) == 0)
	  if (!(--timeout)) return (-1);

      disable();
      /* A byte elk�ld�se */
      outportb(portbase + TXR, x);
      enable();

      return (0);
  }

/*--------------------------------*/
/* Sztring ki�r�sa a soros portra */
/*--------------------------------*/
  void   sputs(char *string)
  {
      while (*string) sputch(*string++);
  }

/*-------------------------------------------*/
/* Az aktu�lis karakter kiolvas�s�sa a soros */
/* pufferb�l.                                */
/*-------------------------------------------*/
  int sgetch(void)
  {
      int res;

      if (endbuf == startbuf)
	  return (-1);

      res = (int) scbuf[startbuf++];
      startbuf %= SBUFSIZ;
      return (res);
  }

/*-------------------------------------------------*/
/* A kommunik�ci�s megszak�t�svektorok be�ll�t�sa  */
/*-------------------------------------------------*/
  void set_svects(void)
  {
      oldvects[0] = getvect(0x0B);
      oldvects[1] = getvect(0x0C);
      setvect(0x0B, com_int);
      setvect(0x0C, com_int);
  }

/*-----------------------------------------------------*/
/* Kil�p�s el�tt az eredeti kommunik�ci�s megszak�t�s- */
/* vektorok vissza�ll�t�sa                             */
/*-----------------------------------------------------*/
  void reset_svects(void)
  {
      setvect(0x0B, oldvects[0]);
      setvect(0x0C, oldvects[1]);
  }

/*---------------------------------------------------------*/
/* A kommunik�ci�s port megszak�t�sk�r�s�nek enged�lyez�se */
/*---------------------------------------------------------*/
  void sit_enable(int pnum)
  {
      int c;

      disable();
      c = inportb(portbase + MCR) | MC_INT;
      outportb(portbase + MCR, c);
      outportb(portbase + IER, RX_INT);
      c = inportb(IMR) & (pnum == COM1 ? IRQ4 : IRQ3);
      outportb(IMR, c);
      enable();
  }

/*---------------------------------------------------*/
/* A kommunik�ci�s port megszak�t�sk�r�s�nek tilt�sa */
/*---------------------------------------------------*/
  void sit_disable(void)
  {
      int c;

      disable();
      c = inportb(IMR) | ~IRQ3 | ~IRQ4;
      outportb(IMR, c);
      outportb(portbase + IER, 0);
      c = inportb(portbase + MCR) & ~MC_INT;
      outportb(portbase + MCR, c);
      enable();
  }

/*---------------------------*/
/* A kommunik�ci� elind�t�sa */
/*---------------------------*/
  void  comm_on(void)
  {
      int c, pnum;

      pnum = (portbase == COM1BASE ? COM1 : COM2);
      sit_enable(pnum);
      c = inportb(portbase + MCR) | DTR | RTS;
      outportb(portbase + MCR, c);
  }

/*---------------------------*/
/* A kommunik�ci� le�ll�t�sa */
/*---------------------------*/
  void comm_off(void)
  {
      sit_disable();
      outportb(portbase + MCR, 0);
  }

/*-------------------------------------*/
/* A soros kommunik�ci� inicializ�l�sa */
/*-------------------------------------*/
  void   initserial(void)
  {
      endbuf = startbuf = 0;
      set_svects();
      comm_on();
  }

/*-------------------------------*/
/* A soros kommunik�ci� lez�r�sa */
/*-------------------------------*/
  void  closeserial(void)
  {
      comm_off();
      reset_svects();
  }

/*-----------------------------------*/
/* A soros port adatainak be�ll�t�sa */
/*-----------------------------------*/
  int setport(int port)
  {
      int offset, far *RS232_Addr;

      switch (port)
      {
	case COM1 : offset = 0x0000;
		    break;
	case COM2 : offset = 0x0002;
		    break;
	default   : return (-1);
      }

      /* A fizikai portc�m helye a mem�ri�ban */
      RS232_Addr = MK_FP(0x0040, offset);
      /* Ha a port nem �l */
      if (*RS232_Addr == NULL) return (-1);
      /* A fizikai portc�m be�ll�t�sa */
      portbase = *RS232_Addr;
      return (0);
  }

/*-----------------------------------------------------*/
/* A soros kommunik�ci� sebess�g�nek (baud) be�ll�t�sa */
/*-----------------------------------------------------*/
  int setspeed(int speed)
  {
      char c;
      int  divisor;

      if (speed == 0)
	  return (-1);
      else
	  divisor = (int) (115200L/speed);

      if (portbase == 0) return (-1);

      disable();
      /* Az �tviteli sebess�g programoz�sa */
      c = inportb(portbase + LCR);
      outportb(portbase + LCR, (c | 0x80));
      outportb(portbase + DLL, (divisor & 0x00FF));
      outportb(portbase + DLH, ((divisor >> 8) & 0x00FF));
      outportb(portbase + LCR, c);
      enable();
      return (0);
  }

/*-----------------------------------------------------*/
/* A soros kommunik�ci� egy�b adtainak be�ll�t�sa      */
/* parit�s, adatbitek sz�ma �s a stopbitek sz�ma       */
/*-----------------------------------------------------*/
  int set_pabsb(int parity, int databits, int stopbits)
  {
      int setting;

      /* Ellen�rz�sek */
      if (portbase == 0) return  (-1);
      if (databits < 5 || databits > 8) return  (-1);
      if (stopbits != 1 && stopbits != 2) return (-1);
      if (parity != NO_PARITY && parity != ODD_PARITY
	  && parity != EVEN_PARITY) return (-1);

      setting  = databits-5;
      setting |= ((stopbits == 1) ? 0x00 : 0x04);
      setting |= parity;

      disable();
      outportb(portbase + LCR, setting);
      enable();
      return (0);
  }
/*------------------------------*/
/* A soros port felprogramoz�sa */
/*------------------------------*/
  int setserial(int port, int speed, int parity, int databits,
		int stopbits)
  {
      if (setport(port)) return (-1);
      if (setspeed(speed)) return (-1);
      if (set_pabsb(parity, databits, stopbits)) return (-1);
      return (0);
  }

/*-----------------------------------*/
/* A Control-Break megszak�t�skezel� */
/*-----------------------------------*/
  int c_break(void)
  {
      sit_disable();
      textcolor(LIGHTRED);
      cprintf("\n\rM�g �l a kapcsolat.\n\r");
      return(0);
  }

/*--------------------------*/
/* A tesztel� main f�ggv�ny */
/*--------------------------*/
main()
{
      /* A kommunik�ci�s param�terek megad�sa */
      int port     = COM1;
      int speed    = 9600;
      int parity   = NO_PARITY;
      int bits     = 8;
      int stopbits = 1;

      int c, done  = FALSE;

      if (setserial(port, speed, parity, bits, stopbits) != 0)
      {
	  textcolor(LIGHTRED);
	  cprintf("Hib�s param�termegad�s.\n\r");
	  return (1);
      }

      initserial();

      textbackground(BLACK);
      clrscr();

      ctrlbrk(c_break);
      textcolor(GREEN);
      cprintf("TURBO C soros kommunik�ci�s program\n\r");
      cprintf("... kil�p�s az <ESC> billenty�vel ...\n\r\n\r");

      /* A program f�ciklusa, amely a billenty�zet- �s a     */
      /* soros pufferb�l egyar�nt felsolgozza a karaktereket */
      do {
	  /* Olvas�s a billenty�zetpufferb�l */
	  if (kbhit())
	  {
	      switch (c=getch())
	      {

		  case ESC:  /* Kil�p�s */
			    done = TRUE;
			    textcolor(LIGHTGRAY);
			    break;

		  case 13 :  /* Soremel�s */
			    putch('\n');
			    putch('\r');
			    break;

		  default : /* Echo */
			    textcolor(GREEN);
			    putch(c);
			    break;
	      }
	      /* A karakter elk�ld�se */
	      sputch(c);
	  }

	  /* Olvas�s a sorospufferb�l */
	  if ((c=sgetch()) != -1)
	    {
	      textcolor(CYAN);
	      putch(c);
	      if (c==13) putch(10);
	    }
      } while (!done && !serror);

      /* Hibakezel�s */
      switch (serror)
      {
	  case NOERROR: /* Nincs hiba */
			cprintf("\n\rViszl�t!\n\r");
			closeserial();
			return (0);

	  case BUFOVFL: textcolor(LIGHTRED);
			cprintf("\n\rA puffer t�lcsordult!\n\r");
			closeserial();
			return (1);

	  default:      textcolor(LIGHTRED);
			cprintf("\n\rIsmeretlen hiba, serror = %d\n\r", serror);
			closeserial();
			return (1);
      }
  }
