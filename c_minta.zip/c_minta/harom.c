/* HAROM.C */

#include <stdlib.h>
#include <graphics.h>
#include <conio.h>
#include <time.h>
#include <dos.h>

#define MAX  3
#define N    3
#define M    25000

void main ()
{
  unsigned int x0, y0, l, p, x[MAX], y[MAX], c[MAX], i;
  int gdriver=DETECT, gmode;

  initgraph(&gdriver, &gmode, "");

  randomize ();
  x[0] =   getmaxx()/4;     y[0] =3*getmaxy()/4;
  x[1] = 3*getmaxx()/4;     y[1] =3*getmaxy()/4;
  x[2] =   getmaxx()/2;     y[2] =  getmaxy()/4;

  do
  {
    x0    = random ( getmaxx() );
    y0    = random ( getmaxy() );
    for (i=0; i<MAX; i++)
      c[i]  = 1 + random (getmaxcolor());

    for (l = 0; l < M && !kbhit(); l++)
    {
      p  = random ( N );
      x0 = (x0 + x[p]) >> 1;
      y0 = (y0 + y[p]) >> 1;
      if (l > 10)
	 putpixel (x0,y0,c[p]);
    }
 }

  while (!kbhit());
  closegraph();
  restorecrtmode();
}
