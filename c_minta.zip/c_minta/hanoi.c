#include <stdio.h>

void Honnan_Hova_Mozgatas(char, char);
void Hanoi(int, char, char, char);

main()
{
  int  korongszam;

  printf("\nA korongok sz�ma : ");
  scanf("%d", &korongszam);
  printf("\n");
  Hanoi(korongszam, 'A', 'B', 'C');
}

void Hanoi(int n, char honnan, char mivel, char hova)
{
    if (n == 1)
       Honnan_Hova_Mozgatas(honnan, hova);
    else {
	Hanoi(n-1, honnan, hova, mivel);
	Honnan_Hova_Mozgatas(honnan, hova);
	Hanoi(n-1, mivel, honnan, hova);
     }
} /* Hanoi */

void Honnan_Hova_Mozgatas(char innen, char ide)
{
    printf("Tedd a korongot a(z)\t%3c\t", innen);
    printf(" r�dr�l a(z) \t%3c\t r�dra.\n", ide);
}  /* Honnan_Hova_Mozgatas */;



