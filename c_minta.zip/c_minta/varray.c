/* Virtu�lis t�mb�t kezel� f�ggv�nyek */

#include "varray.h"
#define header 7

/*****************
   init_varray
 *****************/

 int init_varray(char * filename, int rec_size, char filchar)
 {
  long size;
  FILE *f;
  f=fopen(filename,"wb");
  if (f!=NULL) {
     size=0;
     fwrite(&size,4,1,f);      /*   a t�mb m�rete  */
     fwrite(&rec_size,2,1,f);  /* az elemek m�rete */
     fwrite(&filchar,1,1,f);   /* a felt�lt� karakter */
                               /* t�rol�sa a file fejl�c�ben */
     fclose(f);
     return(1);
  }
  else
    return(NULL);
}


/*****************
   open_varray
 *****************/

VACB * open_varray(char * filename, int buffer_size)
{
  VACB * varray;
  char * buf_ptr;
  int i;
  char filchar;

  /* helyfoglal�s a VACB sz�m�ra */

  varray=(VACB *) malloc(sizeof(VACB));
  if (varray==NULL) return (NULL);

  /* a varray megnyit�sa */

  varray->file=fopen(filename,"r+b");
  if (varray->file == NULL) {
     free(varray);
     return(NULL);
  }

 /* a VACB felt�lt�se a file header-b�l */

 fread(&varray->size,4,1,varray->file);
 fread(&varray->elsize,2,1,varray->file);
 fread(&filchar,1,1,varray->file);
 varray->buf_elsize=varray->elsize+4;

 /* puffer allok�l�sa */

 varray->buffer=(char *)malloc(varray->buf_elsize*(buffer_size+1));
 if (varray->buffer == NULL) {
    fclose(varray->file);
    free(varray);
    return(NULL);
 }
 varray->buf_size=buffer_size;

 /* egy filchar-ral felt�lt�tt �res rekord defini�l�sa */

 buf_ptr=varray->buffer+varray->buf_elsize*varray->buf_size;
 varray->blank_rec=buf_ptr+4;
 for (i=0; i<varray->buf_elsize;i++)
     *buf_ptr++=filchar;

/* a puffer elemeinek rekord index�nek negativra �ll�t�sa */
 buf_ptr=varray->buffer;
 for (i=0; i<varray->buf_size;i++) {
     *((long *)buf_ptr)=-1L;
     buf_ptr+=varray->buf_elsize;
 }
 return(varray);
}




/*****************
   close_varray
 *****************/

void close_varray(VACB * varray)
{
  char * buf_ptr;
  int i;
  long rec_index,file_offset;

  buf_ptr=varray->buffer;

  /* a pufferek ki�r�t�se */

  for (i=0; i< varray->buf_size; i++) {
      /* az indexek ellen�rz�se */
      rec_index=*((long *)buf_ptr);
      if (rec_index>=0) {
         file_offset=header+rec_index*varray->elsize;
         fseek(varray->file,file_offset,0);
         fwrite(buf_ptr+4, varray->elsize,1,varray->file);
      };
      buf_ptr+=varray->buf_elsize;
  };
  free(varray->buffer);
  fclose(varray->file);
  free(varray);
 }


 /****************
    access_v_rec
  ****************/

 void *access_v_rec(VACB * varray,long index)
 {
   char *buf_ptr;
   int buf_index;
   long rec_index, temp_index;

   /* a hivatkozott elem c�m�nek sz�m�t�sa a pufferben */

   buf_index = index % varray->buf_size;
   buf_ptr = varray->buffer + buf_index * varray->buf_elsize;
   rec_index = *(long *)buf_ptr;

   /* ha megvan az elem visszadja a puffer beli c�m�t */

   if (rec_index == index) return(buf_ptr + 4);

   /* ha nincs, akkor a file-t kiterjeszti */

   if (index >= varray->size) {
      fseek(varray->file,0,2);
      for (temp_index = varray->size; temp_index++ <= index; )
             fwrite(varray->blank_rec, varray->elsize, 1, varray->file);
      varray->size = index + 1;
      fseek(varray->file,0,0);
      fwrite(&varray->size, 4, 1, varray->file);
   };

   /* a puffer tartalm�nak felfriss�t�se */

   if (rec_index >= 0) {
      fseek(varray->file, rec_index * varray->elsize + header, 0);
      fwrite(buf_ptr +4, varray->elsize, 1, varray->file);
   };

   fseek(varray->file, index * varray->elsize + header, 0);
   fread(buf_ptr + 4, varray->elsize, 1, varray->file);
   *((long *)buf_ptr) = index;

   /* az elem pufferbeli c�m�nek visszad�sa */

   return(buf_ptr + 4);
 }




