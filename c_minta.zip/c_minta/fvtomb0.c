/* FVTOMB0.C */

#include <stdio.h>

void p0(char *);
void p1(char *);
void q0(char *);
void ures(char *);

/* A feldolgozand� programr�szlet */
char *prog[]={ "P0 100,300",
	       "P1 Hello",
	       "P2 100,LEFT",
	       "P0 200,500",
	       "Q1 500",
	       "P1 Bye",
	       "Q0 "};
main()
{
   void (* fvt[26][10]) (char *);
   int i, j, n;


   /* Inicializ�l�s:  ures */
  for (i = 0; i < 26; i++ )
      for (j = 0; j < 10; j++ )
	  fvt[i][j] = ures;

  fvt['P'-'A']['0'-'0'] = p0;
  fvt['P'-'A']['1'-'0'] = p1;
  fvt['Q'-'A']['0'-'0'] = q0;

  /* A program feldolgoz�sa */
  n=sizeof(prog)/sizeof(prog[0]);
  for ( i = 0; i < n; i++ )
     (* fvt[ prog[i][0]-'A' ][ prog[i][1]-'0' ]) (&prog[i][3]);
}

/* A parancsf�ggv�nyek defin�ci�ja */
void ures (char * p)
{
  printf("**** �rv�nytelen parancs ****\n");
}

void p0 (char * p)
{
  int a,b;
  sscanf(p, "%d,%d", &a, &b);
  printf("%d + %d = %d\n", a, b, a+b);
}

void p1 (char * p)
{
  printf("%s\n", p);
}

void q0 (char * p)
{
  printf("--- A feldolgoz�s v�ge ---\n");
}
