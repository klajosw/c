/* OLVAS.C */
#include <stdio.h>
main()
{
 int a,b;
 float x;
 char nev[21],ch;

 scanf("%d %d",&a, &b);
 scanf("%s",nev);
 scanf("%f %d",&x, &a);
 scanf("%c",&ch);
 ch = getch();
}