/* CIKLUS1.C */
#include <stdio.h>
main()
{
  int ch;
  while ((ch = getch()) !='q')
    putchar(ch);

}