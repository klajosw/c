
#include <stdio.h>

main()
{
  int i,j;

  for (i = 1; i<10; i++)
  {
     printf("\n");
     for (j=0;;j++) 
     {
        if (i == j) break;
        printf("%3d", i);
     }
  }
  printf("\n");
}


