#include<stdio.h>;
#include<alloc.h>;
#include<stdlib.h>;
#include<conio.h>;
void fileir();
void fileolvas(int *);

main()
{
 char foly;
 clrscr();
 printf("Akarsz negypolusokat beolvasni? (y) ");   scanf("%c%c",&foly);
			 if (foly=='y') fileir();
 int *t;  
 t=(int*)malloc(8*sizeof(int));
 if (t==NULL) exit(-1);
 printf("\nelotte: %d\n",*t);
 fileolvas(t);     
//	tomb[0]=*t;  
//	&tomb[0]=t;
	printf("\nutana: %d\n",*t);

 for(int i=0;i<8;i++) printf("\n%d",t[i]);
 free (t);
}



void fileir()
	{ 
		int A1,B1,C1,D1,A2,B2,C2,D2;
		FILE *fp;
		fp=fopen("kapuk.dat","wt");
		clrscr();
		printf("Az elso kapu:\n");
		printf("\nA1= ");   scanf("%d",&A1);
		printf("\nB1= ");   scanf("%d",&B1);
		printf("\nC1= ");   scanf("%d",&C1);
		printf("\nD1= ");   scanf("%d",&D1);
		printf("\nA masodik kapu:\n");
		printf("\nA2= ");   scanf("%d",&A2);
		printf("\nB2= ");   scanf("%d",&B2);
		printf("\nC2= ");   scanf("%d",&C2);
		printf("\nD2= ");   scanf("%d",&D2);
	 fprintf(fp,"%4d\n%4d\n%4d\n%4d\n%4d\n%4d\n%4d\n%4d\n",A1,B1,C1,D1,A2,B2,C2,D2);
	 fflush(fp);  fclose(fp);
	 }  

void fileolvas(int *tm)      /* a tombmutatot allitja az adott ertekre */
 {
	 FILE *fpo;                /* file pointer */
	 if (!(fpo=fopen("kapuk.dat","r")))
			{ fprintf(stderr,"Sikertelen file megnyitas!\n"); exit(-1);	 }
	 fflush(fpo);
	 for (int j=0;j<8;j++)	 fscanf(fpo,"%d\n",tm+j); 
	 fclose(fpo);
//	 tm=&tomb[0];
//	 for (int k=0;k<8;k++)	{ printf("%d;",*(tm+k)); }
//	 return (tm);
 }