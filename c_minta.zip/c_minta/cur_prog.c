/*  CUR_PROG.C  */
#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>
#include <dos.h>
#include <string.h>

void adat_ki(int w, int x,int y,int maxy);
void delcursor(void **p, int h,int v,int h1);
void putcursor(void **p, int h,int v,int h1,int vonal,int color);
void draw_cursor(int x1,int y1,int x2,int y2,int dx,int maxx,int maxy);

void frame(int x1,int y1,int x2,int y2,int dx,int maxx,int maxy);
void frame_ini(int *x1,int *y1,int *x2,int *y2,int *dx, int maxx,int maxy);
void rajzol(int y1, int y2,int xk,int xv,int dx,int color);
void EGA_color(void);

int g_color[8];

char   *napok[]={
	       "  ",
	       "Vasarnap",
	       "Hetfo",
	       "Kedd","Szerda","Csutortok","Pentek","Szombat"
	       };
char    *honap[] = {
	      "janu�r","febru�r",
	      "m�rcius","�prilis","m�jus","j�nius","j�lius",
	      "augusztus","szeptember","okt�ber","november",
	      "december"
	    };


/* long     ora,perc,mp,szmp,ev,hons,nap,szam; */
long  szam;
char     oras[5],percs[5],evs[5],naps[5];
struct date d;
struct time t;
void    *CursorP;
int      yy [651];
int      mm;

void main()
{
int      mx,my;
int      x1,y1,x2,y2;
int      cursor_dx;
int      Hibakod, gd, gm;

    gd = DETECT;
    initgraph(&gd, &gm,"");
    Hibakod = graphresult();
    if (Hibakod)
    {
      clrscr();
      cprintf("Grafikus hiba: %s", grapherrormsg(Hibakod));
      exit(1);
    }
    switch(gd)
    {
     case 3:
     case 9:
	     EGA_color();
	     gm = 1;
	     mx = getmaxx();
	     my = getmaxy();
	     break;
	}
   frame_ini(&x1,&y1,&x2,&y2,&cursor_dx,mx,my);
   frame(x1,y1,x2,y2,cursor_dx,mx,my);
   draw_cursor(x1,y1,x2,y2,cursor_dx,mx,my);
}

void EGA_color()
{
    g_color[1] = WHITE;       /* inform�ci�   */
    g_color[2] = BROWN;       /* keret        */
    g_color[3] = LIGHTGREEN;  /* g�rbe rajza  */
    g_color[4] = YELLOW;      /* g�rbe adatai */
    g_color[5] = LIGHTRED;
}

void frame_ini(int *x1,int *y1,int *x2,int *y2,int *dx, int maxx,int maxy)
{
 int  fx1,fx2,fy1,fy2;
   fx1 = 60;      /*  x koordinata kezd�pontja */
   fx2 = 50;
   fy1 = 40;      /*  y koordin�ta kezd�pontja */
   fy2 = 30;      /*  az als� sz�veg hossza    */
   /*  x1,y1,x2,y2  a k�perny�ablak a rajzol�s sz�m�ra  */
   *x1 = fx1;
   *y1 = fy1;
   *x2 = maxx-fx2;
   *y2 = maxy-fy2;
   *dx = 20;       /* a kurzor x ir�ny� mozg�s�nak �rt�ke */
}

void rajzol(int y1, int y2,
	   int xk,int xv,int dx,int color)
{
 int ys1,ys2;
 int  i,x;
    setcolor(color);
    x = xk+1;
    i = 1;
    yy[1] = random(y2-y1-5);
    while (x < xv-dx)
    {
	yy[i+1] = random(y2-y1-5);
	ys1 = y2 - yy[i];
	ys2 = y2 - yy[i+1];
        line(x,ys1,x+dx,ys2);
	x = x+dx;
	i = i+1;
    }
}

void frame(int x1,int y1,int x2,int y2,int dx,int maxx,int maxy)
{
char buff[200];

    setfillstyle(SOLID_FILL,BLACK);
    setcolor(g_color[5]);
    outtextxy((getmaxx()-88)/2, 0, "Cursor demo");
    setcolor(g_color[1]);
    outtextxy(60, maxy-10, " -> jobbra   <- balra   Esc - exit");
    setviewport(0,0,maxx-1,maxy-1,1);
    setcolor(g_color[1]);
    getdate(&d);
    sprintf(evs,"%d",d.da_year);
    sprintf(naps,"%d",d.da_day);
    strcpy(buff,"D�tum: ");
    strcat(buff,evs);
    strcat(buff,". ");
    strcat(buff,honap[d.da_mon]);
    strcat(buff," ");
    strcat(buff,naps);
    strcat(buff,".");

    outtextxy(x1,y1-10,buff);
    outtextxy(x1+200,y1-10,napok[szam]);
    gettime(&t);

    sprintf(oras,"%d",t.ti_hour);
    sprintf(percs,"%d",t.ti_min);
    strcpy(buff,"Id�: ");
    strcat(buff,oras);
    strcat(buff,":");
    strcat(buff,percs);
    outtextxy(x1+280,y1-10,buff);

    setcolor(g_color[2]);
    rectangle(x1, y1, x2, y2);
    rajzol(y1,y2,x1+1,x2,dx,g_color[3]);  /* adatok �br�zol�sa */
}

void adat_ki(int w, int x,int y,int maxy)
{
char sz[200];
char c[5];
int   k,i;

     setfillstyle(EMPTY_FILL,BLACK);
     bar(x+2,y, x+12, y+80);

     if (maxy < 300){
	settextstyle(SMALL_FONT,HORIZ_DIR,1);
	setusercharsize(14, 12, 14, 17);
	outtextxy(x+5,y-20,"Y");
	sprintf(sz,"%d",w);
	k = strlen(sz);
	for(i = 0; i<k; i++)
	{ c[0]=sz[i];
	  c[1]=0;
	  outtextxy(x+3,y+10+i*6,c);
	}
	settextstyle(DEFAULT_FONT,HORIZ_DIR,1);
      }
      else
      {
	outtextxy(x+3,y-10,"Y");
	sprintf(sz,"%d",w);
	k = strlen(sz);
	for(i = 0; i<k; i++)
	{ c[0]=sz[i];
	  c[1]=0;
	  outtextxy(x+3,y+2+i*8,c);
	}
      }
}


void draw_cursor(int x1,int y1,int x2,int y2,int dx,
		int maxx,int maxy)
{
  int  h1;
  int  j;
  int  Key;
  int  cursor_color;

  int      CurX, CurY;
    cursor_color = g_color[4]; /* cursor szin�nek be�llit�sa   */
    setviewport(0,0, maxx-1, maxy-1, 1);
    j = 1;   /* j adattomb indexe, az elso adat :  yy[1] */
    CurX  = x1+1;
    CurY = y1+(y2-y1-2)/2;
    h1 = (y2-y1-2) / 2;

    putcursor(&CursorP, CurX, CurY, h1,0,cursor_color);
    adat_ki(yy[j],x2,y1,maxy);

  do
  {
    Key = getch();
    if ( Key == 0)  Key = getch();
    switch (Key)
    {
	 case 75 :
		 if (CurX >= x1+dx)
		   {
		     delcursor(&CursorP, CurX, CurY,h1);
		     CurX  = CurX - dx;
		     putcursor(&CursorP, CurX, CurY,h1,1,cursor_color);
                     setcolor(g_color[4]);
		     j = j-1;
		     adat_ki(yy[j],x2,y1,maxy);
		   }
		 break;
	 case  77:
		   if (CurX < x2-dx)
		   {
		     delcursor(&CursorP, CurX, CurY,h1);
		     CurX = CurX + dx;
		     putcursor(&CursorP, CurX, CurY,h1,0,cursor_color);
                     setcolor(g_color[1]);
		     j = j+1;
		     adat_ki(yy[j],x2,y1,maxy);
		   }
		   break;
    }
  }
  while (Key != 27);  /* Esc karaktert var  */

  delcursor(&CursorP, CurX, CurY,h1);

  closegraph();
}



void putcursor(void **p, int h,int v,int h1,int vonal,int color)
 /* kiteszi a kurzort */
 {
 /*  vonal = 1  a kurzor teljes vonal     */
 /*  vonal = 0  a kurzor szaggatott vonal */
  unsigned s;

  s = imagesize(h-5,v-h1,h+5,v+h1);
  *p = malloc(s);
  if( *p == NULL) exit(1);
  getimage(h-5,v-h1,h+5,v+h1,*p);
  setcolor(color);
  if (vonal==1)
		 setlinestyle(SOLID_LINE,0,NORM_WIDTH);
             else
		 setlinestyle(DASHED_LINE,0,NORM_WIDTH);
  line(h-5,v,h+5,v);
  line(h,v-h1,h,v+h1);
}

void delcursor(void **p, int h,int v,int h1)
/* torli a kurzort */
{

  putimage(h-5,v-h1,*p,COPY_PUT);
  if (*p ) free(*p);
  *p=NULL;
}

