/* LJUMP.C  longjump p�lda*/

#include <stdio.h>
#include <setjmp.h>
#include <stdlib.h>

void sub1(jmp_buf);
void sub2(jmp_buf);

int main(void)
{

   int value;
   jmp_buf jumper;

   value = setjmp(jumper);

   switch (value)
   {
   case 1 :
     {
      printf("Visszateres a SUB1 eljarasbol!\n");
      sub2(jumper);
      exit(value);
    }
   case 2 :
     {
      printf("Visszateres a SUB2 eljarasbol!\n");
      exit(value);
    }
   default:
    {
      printf("Az eljaras meghivasa: \n");
      sub1(jumper);
    }
  }

   return 0;
}

void sub1(jmp_buf jumper)
{
   longjmp(jumper,1);
}

void sub2(jmp_buf jumper)
{
   longjmp(jumper,2);
}



/*
Az eljaras meghivasa:
Visszateres a SUB1 eljarasbol!
Visszateres a SUB2 eljarasbol!
*/