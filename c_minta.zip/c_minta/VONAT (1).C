/*
 *
 *
 *                     AT-system with one train
 *
 *                2U feeding module only at one end
 *
 *
 *
 *  Szegedi Csaba
 *  1999.05.16.
 *
 * gcc -Wall -lm ats.c -o ats
 *
 */
 

#include <stdio.h>
#include <math.h>


#define abs(x)		( (x) > 0 ? (x) : -(x) )


char *prgname;

typedef struct
{
  double re;
  double im;
} complex;

typedef struct
{
  complex a;
  complex b;
  complex c;
  complex d;
} two_port;

typedef struct
{
  double abs;
  double deg;
} euler;


double deg2rad (double d)
{
  return d / 180.0 * M_PI;
}

double rad2deg (double d)
{
  return d / M_PI * 180.0;
}

void euler2complex (euler *e, complex *c)
{
  c->re = e->abs * cos ( deg2rad (e->deg) );
  c->im = e->abs * sin ( deg2rad (e->deg) );
  return;
}
       

void complex_multi (complex *c1, complex *c2, complex *cr)
{
  cr->re = c1->re * c2->re - c1->im * c2->im;
  cr->im = c1->im * c2->re + c1->re * c2->im;
  return;
}

 
void complex_add (complex *c1, complex *c2, complex *cr)
{
  cr->re = c1->re + c2->re;
  cr->im = c1->im + c2->im;
  return;
}

void complex_divi (complex *c1, complex *c2, complex *cr)
{
  cr->re = (c1->re * c2->re + c1->im * c2->im) / (c2->re * c2->re + c2->im * c2->im);
  cr->im = (c1->im * c2->re - c1->re * c2->im) / (c2->re * c2->re + c2->im * c2->im);
  return;
}

void complex_replus (complex *c1, complex *c2, complex *cr)
{
  complex tmp1, tmp2;
  complex_multi (c1, c2, &tmp1);
  complex_add (c1, c2, &tmp2);
  complex_divi (&tmp1, &tmp2, cr);
  return;
}
  

  
void matrix_add (two_port *t1, two_port *t2, two_port *tr)
{
  complex_add (&t1->a, &t2->a, &tr->a);
  complex_add (&t1->b, &t2->b, &tr->b);
  complex_add (&t1->c, &t2->c, &tr->c);
  complex_add (&t1->d, &t2->d, &tr->d);
  return;
}
  

void matrix_multi (two_port *t1, two_port *t2, two_port *tr)
{
  two_port tmp1, tmp2;
  
  complex_multi (&t1->a, &t2->a, &tmp1.a);
  complex_multi (&t1->b, &t2->c, &tmp2.a);
  
  complex_multi (&t1->a, &t2->b, &tmp1.b);
  complex_multi (&t1->b, &t2->d, &tmp2.b);
  
  complex_multi (&t1->c, &t2->a, &tmp1.c);
  complex_multi (&t1->d, &t2->c, &tmp2.c);
  
  complex_multi (&t1->c, &t2->b, &tmp1.d);
  complex_multi (&t1->d, &t2->d, &tmp2.d);

  matrix_add (&tmp1, &tmp2, tr);
  
  return;
}
  
  
void matrix_copy (two_port *t1, two_port *t2)
{
  t2->a.re = t1->a.re;
  t2->a.im = t1->a.im;
  t2->b.re = t1->b.re;
  t2->b.im = t1->b.im;
  t2->c.re = t1->c.re;
  t2->c.im = t1->c.im;
  t2->d.re = t1->d.re;
  t2->d.im = t1->d.im;
  return;
}  
  
     

int main (int argc, char **argv)
{

/* The System */
  double   Usabs = 27.5; 		/* kV */
  complex    Zm1 = { 0.0, 0.0 };	/* ohm */
  complex    Zt1 = { 0.531, 10.86 };	/* ohm */
  complex   Zat0 = { 0.680, 0.906 };	/* ohm */
  complex   Zat1 = { 1e+15, 0.000 };	/* ohm */
  complex    Zv0 = { 0.242, 0.737 };	/* ohm */
  complex    Zv1 = { 0.195, 0.412 };	/* ohm */
  int          N = 8;			/* number of ATs */
  double   l [8] = { 0.0, 0.0, 23.1, 7.15, 26.9, 16.1, 18.95, 19.45 }; /* km */

/* Locomotion */
  double    Ploc = 3600;		/* kW */
  double   cosfi = 0.8;
  double locstep = 0.1;			/* km */

/* Load flow */
  double epsilon = 0.0001;
  


  int i;
  double sum, Sloc, Uloc, Uloc_prev, Iloc_abs, Iloc_ang, E1abs, E1ang; 
  double Zabs, Zang, Isabs, Isang, Usang, length, locloc;
  complex c1, c2, Yat0, Yat1, Ileft0, Ileft1, Iright0, Iright1;
  complex Zleft0, Zright0, Zleft1, Zright1, Z0, Z1, E1, Z, I;
  complex U0, U1, Is, Us, Zloc0, Zloc1;
  two_port t1, t2, tleft1, tright1, tleft0, tright0;
  
  prgname = argv[0];

  for (i = 0, length = 0.0; i < N; i++) length += l[i];
  
  c1.re = 1.0, c1.im = 0.0;
  complex_divi (&c1, &Zat0, &Yat0);
  complex_divi (&c1, &Zat1, &Yat1);

  printf ("   Loco       Voltage of loco        Current of loco\n"
          "   [km]        [kV]     [deg]        [kA]      [deg]\n");
  
  for (locloc = 0.0; locloc < length; locloc += locstep)
  {
  
    tleft1.a.re = 1.0, tleft1.a.im = 0.0;
    tleft1.b.re = Zm1.re, tleft1.b.im = Zm1.im;
    tleft1.c.re = 0.0, tleft1.c.im = 0.0;
    tleft1.d.re = 1.0, tleft1.d.im = 0.0;
               
    t1.a.re = 1.0, t1.a.im = 0.0;
    t1.b.re = Zt1.re, t1.b.im = Zt1.im;
    t1.c.re = 0.0, t1.c.im = 0.0;
    t1.d.re = 1.0, t1.d.im = 0.0;
  
    matrix_multi (&tleft1, &t1, &t2);
    matrix_copy (&t2, &tleft1);
  
    tleft0.a.re = 1.0, tleft0.a.im = 0.0;
    tleft0.b.re = 0.0, tleft0.b.im = 0.0;
    tleft0.c.re = 0.0, tleft0.c.im = 0.0;
    tleft0.d.re = 1.0, tleft0.d.im = 0.0;
               
    
    /* Multiplication of two ports on the left */
  
    for (i = 0, sum = 0.0; i < N && sum + l[i] <= locloc; i++)
    {
      /* Positive sequence */
      t1.a.re = 1.0, t1.a.im = 0.0;
      t1.b.re = Zv1.re * l[i], t1.b.im = Zv1.im * l[i];
      t1.c.re = 0.0, t1.c.im = 0.0;
      t1.d.re = 1.0, t1.d.im = 0.0;
  
      matrix_multi (&tleft1, &t1, &t2);
      matrix_copy (&t2, &tleft1);
  
      t1.a.re = 1.0, t1.a.im = 0.0;
      t1.b.re = 0.0, t1.b.im = 0.0;
      t1.c.re = Yat1.re, t1.c.im = Yat1.im;
      t1.d.re = 1.0, t1.d.im = 0.0;
  
      matrix_multi (&tleft1, &t1, &t2);
      matrix_copy (&t2, &tleft1);
  
      /* Zero sequence */
      t1.a.re = 1.0, t1.a.im = 0.0;
      t1.b.re = Zv0.re * l[i], t1.b.im = Zv0.im * l[i];
      t1.c.re = 0.0, t1.c.im = 0.0;
      t1.d.re = 1.0, t1.d.im = 0.0;
  
      matrix_multi (&tleft0, &t1, &t2);
      matrix_copy (&t2, &tleft0);
  
      t1.a.re = 1.0, t1.a.im = 0.0;
      t1.b.re = 0.0, t1.b.im = 0.0;
      t1.c.re = Yat0.re, t1.c.im = Yat0.im;
      t1.d.re = 1.0, t1.d.im = 0.0;
  
      matrix_multi (&tleft0, &t1, &t2);
      matrix_copy (&t2, &tleft0);
  
      sum += l[i];
    }
  
    /* Two ports in the section of the loco */
  
    /* Positive sequence */
    t1.a.re = 1.0, t1.a.im = 0.0;
    t1.b.re = Zv1.re * (locloc - sum), t1.b.im = Zv1.im * (locloc - sum);
    t1.c.re = 0.0, t1.c.im = 0.0;
    t1.d.re = 1.0, t1.d.im = 0.0;
  
    matrix_multi (&tleft1, &t1, &t2);
    matrix_copy (&t2, &tleft1);
  
    tright1.a.re = 1.0, tright1.a.im = 0.0;
    tright1.b.re = Zv1.re * (l[i] - (locloc - sum)), 
      tright1.b.im = Zv1.im * (l[i] - (locloc - sum));
    tright1.c.re = 0.0, tright1.c.im = 0.0;
    tright1.d.re = 1.0, tright1.d.im = 0.0;
               
    t1.a.re = 1.0, t1.a.im = 0.0;
    t1.b.re = 0.0, t1.b.im = 0.0;
    t1.c.re = Yat1.re, t1.c.im = Yat1.im;
    t1.d.re = 1.0, t1.d.im = 0.0;
  
    matrix_multi (&tright1, &t1, &t2);
    matrix_copy (&t2, &tright1);
  
    /* Zero sequence */
    t1.a.re = 1.0, t1.a.im = 0.0;
    t1.b.re = Zv0.re * (locloc - sum), t1.b.im = Zv0.im * (locloc - sum);
    t1.c.re = 0.0, t1.c.im = 0.0;
    t1.d.re = 1.0, t1.d.im = 0.0;
  
    matrix_multi (&tleft0, &t1, &t2);
    matrix_copy (&t2, &tleft0);
  
    tright0.a.re = 1.0, tright0.a.im = 0.0;
    tright0.b.re = Zv0.re * (l[i] - (locloc - sum)), 
      tright0.b.im = Zv0.im * (l[i] - (locloc - sum));
    tright0.c.re = 0.0, tright0.c.im = 0.0;
    tright0.d.re = 1.0, tright0.d.im = 0.0;
               
    t1.a.re = 1.0, t1.a.im = 0.0;
    t1.b.re = 0.0, t1.b.im = 0.0;
    t1.c.re = Yat0.re, t1.c.im = Yat0.im;
    t1.d.re = 1.0, t1.d.im = 0.0;
  
    matrix_multi (&tright0, &t1, &t2);
    matrix_copy (&t2, &tright0);
  
    i++;
  
    /* Multiplication of two ports on the right */
  
    for (; i < N; i++)
    {
      /* Positive sequence */
      t1.a.re = 1.0, t1.a.im = 0.0;
      t1.b.re = Zv1.re * l[i], t1.b.im = Zv1.im * l[i];
      t1.c.re = 0.0, t1.c.im = 0.0;
      t1.d.re = 1.0, t1.d.im = 0.0;
  
      matrix_multi (&tright1, &t1, &t2);
      matrix_copy (&t2, &tright1);
  
      t1.a.re = 1.0, t1.a.im = 0.0;
      t1.b.re = 0.0, t1.b.im = 0.0;
      t1.c.re = Yat1.re, t1.c.im = Yat1.im;
      t1.d.re = 1.0, t1.d.im = 0.0;
  
      matrix_multi (&tright1, &t1, &t2);
      matrix_copy (&t2, &tright1);
  
      /* Zero sequence */
      t1.a.re = 1.0, t1.a.im = 0.0;
      t1.b.re = Zv0.re * l[i], t1.b.im = Zv0.im * l[i];
      t1.c.re = 0.0, t1.c.im = 0.0;
      t1.d.re = 1.0, t1.d.im = 0.0;
  
      matrix_multi (&tright0, &t1, &t2);
      matrix_copy (&t2, &tright0);
  
      t1.a.re = 1.0, t1.a.im = 0.0;
      t1.b.re = 0.0, t1.b.im = 0.0;
      t1.c.re = Yat0.re, t1.c.im = Yat0.im;
      t1.d.re = 1.0, t1.d.im = 0.0;
  
      matrix_multi (&tright0, &t1, &t2);
      matrix_copy (&t2, &tright0);
    }
  
    complex_divi (&tleft1.b, &tleft1.a, &Zleft1);
    complex_divi (&tright1.a, &tright1.c, &Zright1);
    complex_divi (&tleft0.d, &tleft0.c, &Zleft0);
    complex_divi (&tright0.a, &tright0.c, &Zright0);
     
    complex_replus (&Zleft1, &Zright1, &Z1);   
    complex_replus (&Zleft0, &Zright0, &Z0);
    
    complex_add (&Z1, &Z0, &Z);
  
    complex_add (&Zleft1, &Zright1, &c1);
    complex_divi (&Zright1, &c1, &E1);
    E1.re *= Usabs;
    E1.im *= Usabs;
    complex_divi (&E1, &tleft1.a, &c1);
    E1.re = c1.re, E1.im = c1.im;
    E1abs = hypot (E1.re, E1.im);
  
    Zabs = hypot (Z.re, Z.im);
    Zang = atan (Z.im / Z.re);
    Sloc = Ploc / cosfi;  
    Uloc_prev = 0;
    Iloc_abs = 0;
    Iloc_ang = -acos (cosfi);
  
  /*  printf ("E1abs=%f, Zabs=%f\n",E1abs,Zabs); */
  
    for (i = 1; i < 1e+06 ; i++)
    {
      E1ang = asin (Iloc_abs / 2 * Zabs * sin (Iloc_ang + Zang) / E1abs);
      E1.re = E1abs * cos (E1ang);
      E1.im = E1abs * sin (E1ang);
      Uloc = E1.re - Iloc_abs / 2 * Zabs * cos (Iloc_ang + Zang);
  /*    printf ("%s: #%d  Uloc=%f Iloc_abs=%f E1ang=%f\n", prgname, i, Uloc, Iloc_abs, rad2deg(E1ang)); */
      if (abs (Uloc - Uloc_prev) / Usabs < epsilon) break;
      Iloc_abs = Sloc / Uloc / 1000;
      Uloc_prev = Uloc;
    }
    
/*    printf ("%s: locloc=%6.2f #%d Uloc=%.3f Iloc_abs=%.3f E1ang=%.2f\n", prgname, locloc, i, Uloc, Iloc_abs, rad2deg(E1ang)); */

/*    printf ("%6.2f km   %.3f kV   %.3f kA\n", locloc, Uloc, Iloc_abs); */
  
    /* Voltage and current at the source */
    
    I.re = Iloc_abs / 2 * cos (Iloc_ang);
    I.im = Iloc_abs / 2 * sin (Iloc_ang);
  
    c1.re = -I.re, c1.im = -I.im;
    complex_multi (&c1, &Z0, &U0);
    
    complex_multi (&I, &Z1, &c1);
    c1.re *= -1, c1.im *= -1;
    complex_add (&E1, &c1, &U1);
    
    complex_divi (&U0, &I, &Zloc0);
    complex_divi (&U1, &I, &Zloc1);
    
    complex_divi (&U1, &Zright1, &Iright1);
    c1.re = -Iright1.re, c1.im = -Iright1.re;
    complex_add (&I, &c1, &Ileft1);
    
    complex_multi (&tleft1.a, &U1, &c1);
    complex_multi (&tleft1.b, &Ileft1, &c2);
    complex_add (&c1, &c2, &Us);
    
    complex_multi (&tleft1.c, &U1, &c1);
    complex_multi (&tleft1.d, &Ileft1, &c2);
    complex_add (&c1, &c2, &Is);
  
    /* Rotating vectors so voltage of source will be only real */
    
    Usang = atan (Us.im / Us.re);
    Usabs = hypot (Us.re, Us.im); 

    printf ("%7.3f      %6.4f   %6.4f      %6.4f   %6.4f\n", locloc, Uloc, rad2deg (-Usang), Iloc_abs, rad2deg (-Usang + Iloc_ang) );
  
    Us.re = Usabs, Us.im = 0;
    
    Isang = atan (Is.im / Is.re);
    Isabs = hypot (Is.re, Is.im);
  
    Is.re = Isabs * cos (Isang - Usang), Is.im = Isabs * sin (Isang - Usang);
       
  /*
    printf ("Us.re=%f Us.im=%f Is.re=%f Is.im=%f\n",Us.re,Us.im,Is.re,Is.im);
  */  
  
  }
  return 0;
}

