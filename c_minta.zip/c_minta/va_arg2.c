#include <stdarg.h>
#include <stdio.h>

/* A f�ggv�nyek protot�pusa */
int osszeg(int, ...);
double atlag (int, ...);

main()
{
 int s;
 double a;

 /* A f�ggv�nyek megh�v�sa */
 s=osszeg(1, 2, 3, 4, 5, 0);

 a=atlag(4, 10.20, 20.30, 30.40, 40.50);

}


 /* A f�ggv�nyek defin�ci�ja*/

int osszeg(int elso, ...)
{
  va_list  ap;
  int      s = elso, ertek;

  va_start( ap, elso);     /* Az els� argumentum �tl�p�se */

  while (ertek = va_arg(ap, int))  /* Az int argumentumok */
	s+= ertek;

  va_end(ap);

  return s;
}

double atlag(int n, ...)
{
  va_list  ap;
  double   s = 0;
  int      i;

  va_start(ap, n);      /* Az els� argumentum �tl�p�se */

  for (i=0; i<n; i++)
       s += va_arg(ap,double);  /* A double argumentumok */

  va_end(ap);
  return s / n;
}
