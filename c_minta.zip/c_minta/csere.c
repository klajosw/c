/* CSERE.C */
#include <stdio.h>

void csere(double *a, double *b);

main()
{
 double a,b;
  a = 2.5; b= 4.8;
  printf("a = %4.2lf b = %4.2lf \n",a,b);
  csere(&a, &b);
  printf("A csere ut�n :\n");
  printf("a= %4.2f b= %4.2f\n",a,b);
}

void csere(double *a, double *b)
{
 double t;
   t= *a;
   *a = *b;
   *b = t;
}

