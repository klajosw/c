/* PALETTAD.C */
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>

void main()
{
 int  Gd, Gm, Hibakod;
 struct palettetype P;
   Gd = DETECT;
   initgraph(&Gd, &Gm, "");
   Hibakod = graphresult();
   if (Hibakod != grOk)
   {
      clrscr();
      cprintf("Grafikus hiba: %s", grapherrormsg(Hibakod));
      exit(1);
   }
   P. size = 4;
   P.colors[0] =3;   /* black -> cyan    */
   P.colors[1] =5;   /* blue  -> magenta */
   P.colors[2] =1;   /* green -> blue    */
   P.colors[3] =2;   /* cyan  -> green   */
   setallpalette(&P);

   outtextxy(240,20,"Paletta �tdefini�l�s ");

   setfillstyle(SOLID_FILL, BLUE); /* cyan lesz a t�lt�szin */
   bar(100,100,200,130);
   outtextxy(100,150, "blue -> magenta");
   setfillstyle(SOLID_FILL, GREEN); /* magenta lesz a t�lt�szin */
   bar(240,100,340,130);

   outtextxy(240,150, "green -> blue");
   setfillstyle(SOLID_FILL ,CYAN);  /* green lesz a t�lt�szin */
   bar(380,100,480,130);
   outtextxy(380,150,"cyan -> green");

   outtextxy(240,170,"h�tt�r: black -> cyan");
   outtextxy(380,190,"Nyomj Enter-t!");

   getch();
  closegraph();
 }
