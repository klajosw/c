/* PELDA1.C */
#include <stdio.h>

int i,j,k;
int max(int a, int b)
{
  if (a > b) return a;
  else return b;
} /* max f�ggv�ny v�ge */

void csere(int *a, int *b)
{
  int temp;
  temp= *a; *a= *b; *b= temp;
} /* csere f�ggv�ny v�ge */

main()
{
  i= 12; j= 20;
  printf("Csere el�tt: i= %2d  j= %2d\n",i,j);
  csere(&i,&j);
  printf("Csere ut�n : i= %2d  j= %2d\n",i,j);
  k= max(i,j);
  printf(" Max. �rt�k = %2d\n",k);
  return;
} /* main f�ggv�ny v�ge */

