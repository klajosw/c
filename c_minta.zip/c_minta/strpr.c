/* STRPR.C */
#include <stdio.h>
#include <stdlib.h>
typedef char* StrPtr;
main()
{
  StrPtr Ptr;
  Ptr = (StrPtr)malloc(80*sizeof(char));
  strcpy(Ptr,"Ez egy teszt.");
  printf("Ptr = %s\n",Ptr);
  free(Ptr);
}