/* REPOLV.C */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <conio.h>

typedef char nev[21];
typedef nev *nevmut;
nevmut  nevek;

typedef struct szemely{
		       char nev[21];
		       int  utlevelsz;
		       int  sz_datum;
		       char r_datum[9];
		       int  km;
		       struct szemely *kov;
		     } UTAS;

void kiir(char fnev[]);
void maxkm(UTAS *d);
void minev(UTAS *d);
int hasonlit(const void *a, const void *b);
void ut10000(UTAS *d);

main()
{
char fnev[13];
char nev[21];
int utlevelsz, szd, km;
char rd[9];
UTAS *uj, *utolso, *elso;
FILE *finp;
    elso = NULL;
    printf("File neve: "); scanf("%s",fnev);
    finp = fopen(fnev, "r");
   if( finp == NULL) { printf("File nem l�tezik !\n");
		       exit(1);
		     }
   while (EOF != fscanf(finp,"%s %d %d %s %d\n",nev,&utlevelsz,&szd,rd,&km))
   {
     printf("%s %d %d %s %d\n",nev, utlevelsz,szd,rd,km);
     uj = (UTAS*)malloc(sizeof(UTAS));
     if ( uj == NULL)
	 {
	   printf("Kev�s a mem�ria!\n"); exit(1);
	 }
     strcpy(uj->nev,nev);
     uj->utlevelsz = utlevelsz;
     uj->sz_datum = szd;
     strcpy(uj->r_datum,rd);
     uj->km = km;
     uj->kov = NULL;
     if (elso == NULL) { elso = uj; utolso = uj; }
       else utolso->kov = uj;
       utolso = uj;
   }
   utolso->kov = NULL;
   fclose(finp);
   getch();
   maxkm(elso);
   getch();
   minev(elso);
   getch();
   ut10000(elso);
   getch();
}


void maxkm(UTAS *d)
{
UTAS *p, *maxp;
int  km;
  p = d;
  km = 0;
  maxp = p;
  while( p != NULL )
  {
    if (km < p->km) {  km = p->km; maxp = p; }
    p = p->kov;
  }
  printf("\nA legmesszebbre utaz�:\n");
  printf("Neve:  %s\n",maxp->nev);
  printf("Km  :  %d\n",maxp->km);
  return;
}

void minev(UTAS *d)
{
struct date ma;
UTAS *p, *minp;
int  ev;
  getdate(&ma);
  p = d;
  ev= 0;
  minp = p;
  while( p != NULL )
  {
    if (ev < p->sz_datum) {  ev = p->sz_datum; minp = p; }
    p = p->kov;
  }
    printf("\nA legfiatalabb utaz�:\n");
    printf("Neve         : %s\n",minp->nev);
    printf("Sz�let�si �ve: %d\n",minp->sz_datum);
    printf("Kora         : %d\n",ma.da_year-minp->sz_datum);
  return;
}
int hasonlit(const void *a, const void *b)
{
  return strcmp((char*)a, (char*)b);
}

void ut10000(UTAS *d)
{
UTAS *p;
int  km, db, i, j;
UTAS *u_elso, *u_utolso;
  p = d;
  u_elso = NULL;
  km = 10000;
  db = 0;
  printf("\nA 10000 km-n�l messzebbre utaz�k:\n");
  while( p != NULL)
  {
    if (p->km > km) {
		      db++;
		      if(u_elso == NULL){  u_elso = p; u_utolso = p; }
			 else u_utolso->kov = p;
		      u_utolso = p;
		    }
    p = p->kov;
  }
  u_utolso->kov = NULL;
  nevek = (nevmut)malloc(db*sizeof(nev));
  p = u_elso;
  i = 0;
  while( p != NULL)
  {
    strcpy(nevek[i] ,p->nev);
    i++;
    p = p->kov;
  }
  qsort(nevek,db, sizeof(nev), hasonlit);
  for( i = 0; i< db; i++)
  {
    p = d;
    j = -1;
    while( p != NULL)
   {
     if(strcmp(nevek[i] ,p->nev) == 0) { j = i; break; }
     p = p->kov;
   }
   if(j != -1)
   {
     printf("\nN�v  : %s\n",nevek[j]);
     printf("�tlev�lsz�m: %d\n",p->utlevelsz);
     printf("km         : %d\n",p->km);
   }
  }
  if(!db)
   printf("Nincs ilyen utas!\n");
  return;
}