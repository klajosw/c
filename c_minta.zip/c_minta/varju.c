#include<stdio.h>;
#include<alloc.h>;
#include<stdlib.h>;
#include<conio.h>;
void fileir();
//int aram(float, float, float *);
float deltaU(float, float, float*);
int *fileolvas();

main()
{
 int U,P,U0,*pdU,temp;
 char foly;
 clrscr();
 printf("Akarsz negypolusokat beolvasni? (y) ");   scanf("%c%c",&foly);
			 if (foly=='y') fileir();
 U0=26000;  P=2000000;
 int *tomb;
 tomb=(int*)malloc(sizeof(int));
 tomb=fileolvas(); 
 for(int i=0;i<8;i++) printf("\n%d",tomb[i]);
 *pdU=0;

/* temp=deltaU(P,U0,pdU);
 printf("\nA feszultsegeses: %f",temp);
 */
// free(tomb);
}

void fileir()
	{ 
		int A1,B1,C1,D1,A2,B2,C2,D2;
		FILE *fp;
		fp=fopen("kapuk.dat","wt");
		clrscr();
		printf("Az elso kapu:\n");
		printf("\nA1= ");   scanf("%d",&A1);
		printf("\nB1= ");   scanf("%d",&B1);
		printf("\nC1= ");   scanf("%d",&C1);
		printf("\nD1= ");   scanf("%d",&D1);
		printf("\nA masodik kapu:\n");
		printf("\nA2= ");   scanf("%d",&A2);
		printf("\nB2= ");   scanf("%d",&B2);
		printf("\nC2= ");   scanf("%d",&C2);
		printf("\nD2= ");   scanf("%d",&D2);
	 fprintf(fp,"%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n",A1,B1,C1,D1,A2,B2,C2,D2);
	 fflush(fp);  fclose(fp);
	 }  

int* fileolvas()
 {
	 int tomb[8];
	 int a;
	 FILE *fpo;
	 if (!(fpo=fopen("kapuk.dat","rt")))
			{ fprintf(stderr,"Sikertelen file megnyitas!\n"); exit(-1);	 }
	 fflush(fpo);
	 for (int j=0;j<8;j++)	{ fscanf(fpo,"%d",&a); tomb[j]=a; }
	 fclose(fpo);
	 return (tomb);
 }



//float aram(float P, float U0, float *pdU)
//	 { return P/(U0 - *pdU); }


float deltaU(float P, float U0, float *pdU)
{
	 float A1,B1,C1,D1,A2,B2,C2,D2;
	// float elozodU;
	// float dU=(*pdU);



/*	 float tomb[];
	 FILE *fp;
	 fp=fopen("kapuk.dat","rt");
	 for (int j=1;j<9;j++) { fscanf(fp,"%f",&tomb[j]); }
	 fclose(fp);
	 printf("\n\nAz elemek:"); for (int k=1;k<9;k++) { printf("%f ",tomb[k]); }
	 A1=tomb[1]; B1=tomb[2]; C1=tomb[3]; D1=tomb[4];
	 A2=tomb[5]; B2=tomb[6]; C2=tomb[7]; D2=tomb[8];
 */


 /*	 FILE *fpp;
	 fpp=fopen("kapuk.dat","r");
	 fscanf(fpp,"%f",&A1);  printf("\n%f",A1);
	 fscanf(fpp,"%f",&B1);  printf("\n%f",A1);
	 fscanf(fpp,"%f",&C1);  printf("\n%f",A1);
	 fscanf(fpp,"%f",&D1);  printf("\n%f",A1);
	 fscanf(fpp,"%f",&A2);
	 fscanf(fpp,"%f",&B2);
	 fscanf(fpp,"%f",&C2);
	 fscanf(fpp,"%f",&D2);
	fclose(fpp);
	

	 float I=aram(P,U0,pdU);
	 float elozodU = *pdU;
	 *pdU= I*A1+I*C2;                              /* ez kamu */
	 if ( (*pdU-elozodU) > 1.0) deltaU(P,U0,pdU);
	 return (*pdU);  
	 */
}

