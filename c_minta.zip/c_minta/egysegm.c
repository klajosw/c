/* EGYSEGM.C */
#include <stdio.h>

main()
{
 int a[5][5];
 int i,j;
 for(i = 0; i < 5; i++)
   for ( j = 0; j < 5; j++)
   {
     if ( i == j ) a[i][j] = 1;
     else a[i][j] = 0;
   }
 printf("  Egys�gm�trix\n\n");
 for ( i = 0; i < 5; i++)
 {
   for ( j = 0; j < 5; j++)
     printf("  %d",a[i][j]);
  printf("\n");
 }
}
