/* ORA.C */

#include <conio.h>
#include <graphics.h>
#include <math.h>
#include <dos.h>
#include <stdio.h>

double aspect=1.0;
double     pi=3.14159265;

/* A k�ppontar�ny korrekci�ja */
int ar(int y)
{
    return aspect*y;
}

/* A k�ppontar�ny be�ll�t�sa */

void setaspect(void)
{
    int d,m;
    getaspectratio(&d,&m);
    aspect=1.0*d/m;
}

/* Vonalh�z�s korrekci�val */
void linex(unsigned x1, unsigned y1,  unsigned x2,  unsigned y2)
{
  line(x1,ar(y1),x2,ar(y2));
}

void main()
{
 double   pi30=pi/30;
 int gd, gm, d, xc, yc;
 int r, i;
 int oldsec=-1;
 struct time time;
 char tp[6];

   detectgraph(&gd,&gm);
   initgraph(&gd,&gm,"");


   setaspect();
   xc=getmaxx() / 2;
   yc=getmaxy() / 2;
   r =(xc+yc) / 4;
   d =(xc+yc) / 64;

   setbkcolor(BLUE);
   setcolor(YELLOW);

   /* A sz�mlap kirajzol�sa mutat�k n�lk�l */

   setlinestyle(SOLID_LINE,0,THICK_WIDTH);
   circle(xc,ar(yc),r);

   setlinestyle(SOLID_LINE,0,THICK_WIDTH);
   for (i=1; i<=12; i++)
    linex(xc+(r-4*d)*cos(i*pi/6),
	  yc+(r-4*d)*sin(i*pi/6),
	  xc+(r-d)*cos(i*pi/6),
	  yc+(r-d)*sin(i*pi/6));

   setlinestyle(SOLID_LINE,0,NORM_WIDTH);
   for (i=1; i<=60; i++)
    linex(xc+(r-2*d)*cos(i*pi30),
	  yc+(r-2*d)*sin(i*pi30),
	  xc+(r-d)*cos(i*pi30),
	  yc+(r-d)*sin(i*pi30));

   do {
    gettime(&time);
    if (oldsec==time.ti_sec) continue;

    /* A mutat�k t�rl�se */
    setcolor(BLUE);
    setfillstyle(SOLID_FILL,BLUE);
    fillellipse(xc,ar(yc),r-5*d+1,r-5*d+1);

    setcolor(YELLOW);

    /* A magymutat� */
    setlinestyle(SOLID_LINE,0,THICK_WIDTH);
    i=time.ti_min-15;
    linex(xc+(-d)*cos(i*pi30),
	     yc+(-d)*sin(i*pi30),
	     xc+(r-5*d)*cos(i*pi30),
	     yc+(r-5*d)*sin(i*pi30));

    /* A kismutat� */
    i=(time.ti_hour - 12) * 5 + (time.ti_min / 12) -15;
    linex(xc+(-d)*cos(i*pi30),
	     yc+(-d)*sin(i*pi30),
	     xc+(r-10*d)*cos(i*pi30),
	     yc+(r-10*d)*sin(i*pi30));

    /* A m�sodperc mutat� */
    setlinestyle(SOLID_LINE,0,NORM_WIDTH);
    i=time.ti_sec-15;
    linex(xc+(-d)*cos(i*pi30),
	     yc+(-d)*sin(i*pi30),
	     xc+(r-5*d)*cos(i*pi30),
	     yc+(r-5*d)*sin(i*pi30));

    /* Az id� kijelz�se sz�mokkal */
    setfillstyle(SOLID_FILL,YELLOW);
    bar(xc-5*d,ar(yc+7*d),xc+5*d,ar(yc+9*d));

    setcolor(BLUE);
    settextstyle(SMALL_FONT, HORIZ_DIR, ar(6));
    sprintf(tp,"%02d:%02d",time.ti_hour,time.ti_min);
    outtextxy(xc-4*d,ar(yc+7*d),tp);
    settextstyle(SMALL_FONT, HORIZ_DIR, ar(5));
    sprintf(tp,"%02d",time.ti_sec);
    outtextxy(xc+3*d,ar(yc+7*d),tp);

    oldsec=time.ti_sec;
   } while(!kbhit());

  getch();
  closegraph();
}
