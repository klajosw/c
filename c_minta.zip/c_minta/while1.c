
#include <stdio.h>

main()
{
  long sum;
  int  n = 1994;

  printf("Az els� %d eg�sz ", n);
  sum=0;
  while (n>0) {
     sum += n;
     n--;
  }
  printf("�sszege: %ld\n", sum);
}

