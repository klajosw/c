/* TORZIT.C */
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>

void main()
{
 int Gd, Gm, Hibakod, r = 60, Xasp, Yasp;
    Gd = DETECT;
    initgraph(&Gd, &Gm,"");
    Hibakod = graphresult();
    if (Hibakod)
    {
       clrscr();
       cprintf("Grafikus hiba: %s",grapherrormsg(Hibakod));
       exit(1);
    }
    getaspectratio(&Xasp,&Yasp);
    if (Xasp == Yasp ) Yasp = 3*Xasp;
    while (Xasp < Yasp)
    {
      setaspectratio(Xasp,Yasp);
      circle(getmaxx() / 2,getmaxy() / 2, r);
      Xasp += 10;
    }
    settextjustify(CENTER_TEXT, CENTER_TEXT);
    outtextxy(getmaxx() / 2,getmaxy() / 2,"Siker�lt!");
      getch();
    closegraph();
 }
