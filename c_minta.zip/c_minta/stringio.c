#include <stdio.h>

main()
{
   char adat[3][16] = { "12.64","3.7344","2333.23"};
   double e;
   int i;

   for (i=0; i<3; i++) {
       sscanf(adat[i],"%lf",&e);
       e +=0.5;
       sprintf(adat[i], "%ld", (long)e);
   }

   for (i=0; i<3; i++)
       printf("%d. \t %s\n",i ,adat[i]);




}