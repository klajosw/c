#include <stdio.h>

void kiir(char*, int*, double*);

main()
{
  char    c = 'A';
  int     i = 123;
  double pi = 3.14159265;

  printf("A h�v�s el�tt:\t\tc=%c i=%d pi=%lf\n", c, i, pi);

  kiir(&c, &i, &pi);             /* a f�ggv�nyh�v�s */

  printf("A h�v�s ut�n :\t\tc=%c i=%d pi=%lf\n", c, i, pi);
}

void kiir(char * ch, int * n, double * d)
{
  printf("A f�ggv�nyen bel�l:\tc=%c i=%d pi=%lf\n", *ch, *n, *d);
  (*ch)++;
   (*n)++;
   (*d)--;
  printf("A f�ggv�nyen bel�l:\tc=%c i=%d pi=%lf\n", *ch, *n, *d);
}
