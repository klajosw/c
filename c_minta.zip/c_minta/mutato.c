/* MUTATO.C */
#include <alloc.h>
typedef struct ns {
		    int data;
		    struct ns *next;
		  } node;
main()
{
 int *intptr;
 int (*buff1)[11];
 int *buff2[21];

 node *phead;
 node head;
 int  i;

   intptr = malloc(sizeof(int));
   buff1 = malloc(sizeof(int)*11);
   for (i = 0; i<21; i++)
     buff2[i] = malloc(sizeof(int));
   phead = malloc(sizeof(node));

   *intptr = 32;
   (*buff1)[5] = 12;
   *buff2[3] = 10;
   head.next = NULL;
   head.data = 21;

   phead->next = NULL;
   phead->data = 21;

   free(intptr);
   free(buff1);
   for(i = 0; i<21; i++)
     free(buff2[i]);
   free(phead);
}
