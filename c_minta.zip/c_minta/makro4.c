#include <stdio.h>

#define str(x) printf("\a\n" #x "\n");
#define display(n,f) \
		 printf("A v�ltoz�: "#n"=%"#f"\n",n)
main()
{
   int     a = 13;
   char   *p = "Hello C";
   double pi = 3.1425;

   str(Most kezdodik);
   display(a,5d);
   display(p,s);
   display(pi,9.6lf);
   str(Vege);
}