/*  V_FEKETE.C */
/* EGA �s EGAVGA */
#include <graphics.h>
#include <conio.h>
#include <stdlib.h>

void main()
{
 int   Gd, Gm,m ,x, y, Hibakod;
 void  *p;
   Gd = EGA;
   Gm = EGAHI;
   initgraph(&Gd,&Gm,"");
   Hibakod = graphresult();
   if(Hibakod)
   {
     clrscr();
     cprintf("Grafikus hiba: %s",grapherrormsg(Hibakod));
     exit(1);
   }
   if (graphresult()) exit(1);
     bar(0,0,getmaxx(),getmaxy());
     m =imagesize(10,20,40,60);
     p = malloc(m);
     getimage(10,20,40,60,p);
     setcolor(BLACK);
     outtextxy(250,150,"Nyomj Enter-t");
   getch();
   x = 50; y = 100;
   setcolor(WHITE);
   cleardevice();

     outtextxy(220,20,"Getimage Putimage teszt ");
     putimage(x,y,p,COPY_PUT);
     putimage(x+10,y+10,p,COPY_PUT);
     rectangle(x,y,x+30,y+40);
     outtextxy(x,y+70,"COPY_PUT");
     rectangle(x+10,y+10,x+40,y+50);
     outtextxy(x,y+80,"COPY_PUT");

   x = 150; y = 100;
     putimage(x,y,p,COPY_PUT);
     putimage(x+10,y+10,p,XOR_PUT);
     rectangle(x,y,x+30,y+40);
     outtextxy(x,y+70,"COPY_PUT");
     rectangle(x+10,y+10,x+40,y+50);
     outtextxy(x,y+80,"XOR_PUT");

   x = 250; y = 100;
     putimage(x,y,p,COPY_PUT);
     putimage(x+10,y+10,p,OR_PUT);
     rectangle(x,y,x+30,y+40);
     outtextxy(x,y+70,"COPY_PUT");
     rectangle(x+10,y+10,x+40,y+50);
     outtextxy(x,y+80,"OR_PUT");

   x = 350; y = 100;
     putimage(x,y,p,COPY_PUT);
     putimage(x+10,y+10,p,AND_PUT);
     rectangle(x,y,x+30,y+40);
     outtextxy(x,y+70,"COPY_PUT");
     rectangle(x+10,y+10,x+40,y+50);
     outtextxy(x,y+80,"AND_PUT");

   x = 450; y = 100;
     putimage(x,y,p,COPY_PUT);
     putimage(x+10,y+10,p,NOT_PUT);
     rectangle(x,y,x+30,y+40);
     outtextxy(x,y+70,"COPY_PUT");
     rectangle(x+10,y+10,x+40,y+50);
     outtextxy(x,y+80,"NOT_PUT");
   getch();

   closegraph();
}
