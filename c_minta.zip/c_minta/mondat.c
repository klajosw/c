/* MONDAT.C */
#include <stdio.h>

main()
{
 char mondat[80];
 int  i, sor;
  printf("\nA mondat\n:"); gets(mondat);
  sor = 0;
  printf("\nA mondat szavai:\n");
  for(i = 0; mondat[i] != '\0'; i++)
  {
    if( mondat[i] == ' '&& !sor) { sor = 1; printf("\n"); }
    else if ( mondat[i] != ',' && mondat[i] != '.')
      { sor = 0; printf("%c",mondat[i]); }
  }
}
