#include <stdio.h>

unsigned long fakt(int);


main()
{
 int i ;

 for (i=0; i<13; i++)
    printf("%d  \t  %lu\n",i, fakt(10) );
}

unsigned long fakt(int n)
{
 unsigned long f=1;

 for ( ; n > 0 ; n--) f*=n;
 return f;
}