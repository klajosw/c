/*************************************/
/*            GRINPUT.C              */
/* Sz�veges input grafikus k�perny�n */
/*************************************/

  #define BE 1
  #define KI 0
  #include <graphics.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <conio.h>
  #include <dos.h>

  void Kurzor(int);
  void UjSor(int);
  void SzovegInput(char *);


int main(void)
  {
     char nevstr[80],korstr[80];
     int kor, xp, yp, cnt;

     /* a grafika automatikus felder�t�s */
     int gdriver = DETECT, gmode, errorcode;

     initgraph(&gdriver, &gmode, "");

     /* hibaellen�rz�s */
     errorcode = graphresult();
     if (errorcode != grOk)
     {
	printf("Grafika hiba: %s\n", grapherrormsg(errorcode));
	printf("B�rmely billenty�re kil�p ...");
	getch();
	return 1;
     }

     setbkcolor(BLUE);  /* a h�tt�r sz�ne  */
     setcolor(YELLOW);  /* az el�t�r sz�ne */

     /* a v�zszintes sz�veg�r�nyt kell be�ll�tani! */
     settextstyle(TRIPLEX_FONT,HORIZ_DIR,0);

     /* a kezdeti k�perny�poz�ci� */
     moveto(50,10);
     outtext("Kerem a nevet     : ");
     SzovegInput(nevstr);
     UjSor(50);

     /* numerikus input megval�s�t�sa */
     setcolor(LIGHTRED);
     outtext("Kerem az eletkorat : ");
     SzovegInput(korstr);
     /* konvert�l�s sz�mm� */
     kor=atoi(korstr);
     UjSor(0);
     UjSor(0);
     setcolor(WHITE);

     outtext("Kedves ");
     outtext(nevstr);
     outtext(" !");

     kor++;
     /* Az eletkor sztringbe �r�sa */
     sprintf(korstr,"%3d",kor);
     UjSor(0);
     outtext("On a kovetkezo evben ");
     outtext(korstr);
     outtext(" eves lesz.");
     UjSor(0);
     UjSor(100);


     xp=getx();
     yp=gety();
     cnt=-1;
     do {
       if (cnt)
	{
	 cnt+=1;
	 setcolor(LIGHTGREEN);
	}
       else
	{
	 cnt-=1;
	 setcolor(getbkcolor());
	}
       moveto(xp,yp);
       outtext("Barmely billentyure kilep ...");
       delay(250);
     } while (!kbhit());
     getch();
     closegraph();
     return 0;
}

  /*********************************************************/
  /* UjSor: az �jsor funkci� megval�s�t�sa grafikus m�dban */
  /* a v�zszintes poz�ci� megad�s�val                      */
  /*********************************************************/
  void UjSor(int xpos)
  {
      moveto(xpos,gety()+textheight("A"));
  }

  /***********************************************************/
  /* SzovegInput: a argumentum�ban megadott pufferbe bet�lti */
  /* az input sort, az Enter lenyom�sa ut�n                  */
  /***********************************************************/
  void SzovegInput(char *inputString)
  {
      /* az aktu�lis poz�ci� jelz�se a sz�vegsorban */
     int stridx=0;

     /* a karakterek k�perny�poz�ci�j�t t�rol� t�mb */
     int chxpos[255];

     /* az aktu�lis karaktert karakterk�nt, illetve */
     /* sztringk�nt t�rol� v�ltoz�k. */
     char inchr, instr[2]="";

     int oldcolor;

     /* a sz�veg kezd�poz�ci�ja */
     chxpos[0]=getx();
     do
     {
	Kurzor(BE);
	/* karakter beolvas�sa */
	inchr=getch();
	Kurzor(KI);
	/* a speci�lis billenty�k hat�s�nak kik�sz�b�l�se */
	if (inchr==0) getch();
	else
	switch (inchr)
	 {
	    case 8 : /* backspace - visszat�rl�s*/
		oldcolor=getcolor();
		--stridx;
		if (stridx<0) stridx=0;
		/* a r�gi x �s az aktu�lis y poz�ci� */
		moveto(chxpos[stridx],gety());
		/* a karakter t�rl�se a h�tt�rsz�nnel t�rt�n� vissza�r�ssal. */
		setcolor(getbkcolor());
		instr[0]=inputString[stridx];
		outtext(instr);
		/* vissza�ll�s */
		moveto(chxpos[stridx],gety());
		setcolor(oldcolor);
		break;

	    default:
		/* a karakter t�rol�sa a sztringben �s ki�r�sa a k�perny�re */
		inputString[stridx]=inchr;
		instr[0]=inchr;
		outtext(instr);
		/* poz�cion�l�s a k�vetkez� helyre */
		++stridx;
		/* a v�zszintes poz�ci� elt�rol�sa */
		chxpos[stridx]=getx();
		break;
	 }
     /* az input v�g�nek figyel�se (ENTER) */
     } while(inchr!=13);

     /* a sztrinv�ge karakter elhelyez�se */
     inputString[stridx]=0;
  }

  /******************************************/
  /* Kurzor: sz�vegkurzor az inputsorban.   */
  /* BE - van / KI - nincs                  */
  /******************************************/
  void Kurzor(int on)
  {
      int xcurpos,oldcolor;
      /* a kurzor al�h�z�s (_) karakter */
      char alahuzas[2] = "_";

      /* kikapcsol�s a hatt�rsz�nnel val� �r�ssal t�rt�nik */
      if (!on) {
	  oldcolor=getcolor();
	  setcolor(getbkcolor());
      }

      xcurpos=getx();
      outtext(alahuzas);
      moveto(xcurpos,gety());
      if (!on) setcolor(oldcolor);
  }







