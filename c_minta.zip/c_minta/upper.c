#include <stdio.h>
#include <string.h>
#include <ctype.h>

main()
{
 char s[80];
 int  i;

 printf("K�rek egy sz�veget: ");
 gets(s);

 for (i = strlen(s)-1; i >= 0; i--)
     printf("%c", toupper(s[i]) );
 printf("\n");
}


