
#include <stdio.h>
#include <stdlib.h>
#define NELEM1 50
#define NELEM2 100

main()
{
  double *pv1[NELEM1], *pv2[NELEM1];
  int i , j;

  /* Helyfoglal�s ellen�rz�ssel */
  for (i = 0; i < NELEM1; i++) {
      pv1[i] = (double *) calloc( NELEM2, sizeof(double));
      pv2[i] = (double *) calloc( NELEM2, sizeof(double));
      if (!pv1[i] || !pv2[i]) {
          printf("\a\nNincs el�g mem�ria!\n");
          return -1;
      }
  }
  /* Az 1. m�trix felt�lt�se v�letlen sz�mokkal */
  for (i = 0; i < NELEM1; i++)
    for (j = 0; j < NELEM2; j++)
        *(pv1[i] + j) = random(10000)*1.234;

  /* Az 1. m�trix 10-szeres�nek m�sol�sa a 2. m�trixba */
  for (i = 0; i < NELEM1; i++)
    for (j = 0; j < NELEM2; j++)
        pv2[i][j] = *( *(pv1+i) + j) * 10.0;
  /* A lefoglalt ter�letek felszabad�t�sa */
  for (i = 0; i < NELEM1; i++) {
      free(pv1[i]);
      free(pv2[i]);
  }
}

