/* NEVSOR.C */
#include <stdio.h>
#include <string.h>

main()
{
int  n, i, j;
char nev[10][30], nevs[30];

 printf("\nA nevek sz�ma: ");  scanf("%d",&n);
 for( i = 0; i < n; i++)
 {
   printf("%d. n�v :",i+1); scanf("%s",nev[i]);
 }
 for(i = 0; i < n; i++)
   for(j = 0; j < n; j++)
    {
      if (strcmp(nev[i], nev[j]) < 0)
	 {
	   strcpy(nevs, nev[i]);
	   strcpy(nev[i],nev[j]);
	   strcpy(nev[j], nevs);
	 }
    }
 printf("\nA sorbarendezett nevek\n");
 for(i = 0; i < n; i++)
   printf("%s\n",nev[i]);

 }
