
#include <stdio.h>

main()
{
  int n;

  printf("K�rek egy eg�sz sz�mot: ");
  scanf("%d", &n);
  if (n % 2 == 0)
     printf("A sz�m p�ros!\n");
  else
     printf("A sz�m p�ratlan!\n");
}

