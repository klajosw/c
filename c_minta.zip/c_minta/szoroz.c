/* SZOROZ.C */
#include <stdio.h>

main()
{
int  x[10];
int  i;
  printf("A vektor elemei\n");
  for(i = 0; i < 10; i++)
  {
    printf(" %d. elem = ",i); scanf("%d",&x[i]);
  }
  printf("A vektor m�dositott elemei\n");
  for( i = 0; i < 10; i++)
  {
    if( i % 2 == 0) x[i] *= 12;
    else x[i] *= 3;
    printf("%d. elem = %d \n",i,x[i]);
  }
 }
