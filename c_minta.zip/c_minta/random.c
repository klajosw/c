/*
**   File:             random.c
**
**   Pseudo v�letlensz�mok sorozat�nak el��ll�t�sa.
**   set_random - a kiindul�si �rt�k be�ll�t�sa
**   random     - a k�vetkez� v�letlensz�m lek�rdez�se
*/

/* konstansok */
#define SZORZO  97
#define OSZTO  256
#define NOVELES 59

			     /*                      */

/* A kiindul�si �rt�k be�ll�t�sa */
void set_random(unsigned int init)
{
  pseudo = init;
}

unsigned int random(unsigned int init)
{
  /* statikus lok�lis v�ltoz� defini�l�sa 0 kezd��rt�kkel */
  static unsigned int pseudo;

  if (!init)  /* Ha az init nem 0 */
     pseudo = init;
  else
     pseudo = (SZORZO * pseudo + NOVELES) % OSZTO;
  return pseudo;
}