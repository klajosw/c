struct datum{
			 int ho;
			 int nap;
			 void beall(int h, int n);
			 void beall2(char* d);
			 void beall3();
			 void beall