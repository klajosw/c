#include <stdio.H>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define KSZAM 100

struct book {
	       char  nev [20];
	       char  cim [40];
	       int   ev;
	       float ar;
	     };
main()
{
   struct book   talalat[KSZAM];
   struct book * plib[KSZAM];
   int i, db;

  /* Helyfoglal�s ellen�rz�ssel */
  for (i = 0; i < KSZAM; i++) {
      plib[i] = (struct book *) malloc(sizeof(struct book));
      if (!plib[i]) {
	 printf("\a\nNincs el�g mem�ria!\n");
	 return -1;
      }
   }

  /* A k�nyvek v�letlenszer� felt�lt�se */
  randomize();
  for (i = 0; i < KSZAM; i++) {
      sprintf(plib[i]->nev,"%03d Anonymous", i);
      sprintf(plib[i]->cim,"Nothing %03d", i);
      plib[i]->ev = 1900+random(100);
      plib[i]->ar = random(1000) * 1.5;
 }

  /* A keresett k�tetek kiv�logat�sa */
  db = -1;  /* Nincs tal�lat */
  for (i = 0; i < KSZAM; i++)
      if (plib[i]->ev >=1968 && plib[i]->ev <= 1989)
	 talalat[++db] = *plib[i];

  /* A keres�s eredm�ny�nek kijelz�se */
 if (db != -1) {
   printf("A tal�latok sz�ma: %d \n\n", db+1);
   for (i=0; i<=db; i++)
   printf("%-20s %-40s %5d %10.2f\n",talalat[i].nev,
				     talalat[i].cim,
				     talalat[i].ev,
				     talalat[i].ar  );
 }
 else
   printf("Nincs a felt�telnek megfelel� k�nyv!\n");

  /* A lefoglalt ter�letek felszabad�t�sa */
  for (i = 0; i < KSZAM; i++)
      free(plib[i]);
}
