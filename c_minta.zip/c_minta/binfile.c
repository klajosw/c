#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	char nev[30];
	int kor;
	} RECORD;

RECORD rt[11], re;

main()
{
    FILE * bf;
    int cnt;

    /* A 0. �s az 10. elem felt�lt�se */
    strcpy(rt[0].nev, "AT&T Bell Lab.");
    rt[0].kor = 25;

    strcpy(rt[10].nev, "K&R - AT&T Bell Lab.");
    rt[10].kor = 35;

    /* rekordt�mb ki�r�sa bin�ris file-ba */
    bf = fopen("ADAT.DAT", "w+b");
    if (bf==NULL) {
       fprintf(stderr, "Sikertelen file-nyit�si kis�rlet!\n");
       exit(-1);
    }
    cnt = fwrite(rt,sizeof(RECORD),11, bf);

    /* Visszapozicion�l�s a file elej�re */
    rewind(bf);

    /* A 0. rekord visszaolvas�sa */
    cnt = fread(&re,sizeof(RECORD),1, bf);
    if (cnt!=1) {
       fprintf(stderr, "File olvas�si hiba!\n");
       exit(-1);
    }

    /* pozicion�l�s a 10. rekordra */
    fseek(bf, 10 * sizeof(RECORD), SEEK_SET);

    /* Az 10. rekord visszaolvas�sa */
    cnt = fread(&re,sizeof(RECORD),1, bf);
    if (cnt!=1) {
       fprintf(stderr, "File olvas�si hiba!\n");
       exit(-1);
    }

    fclose(bf);
}