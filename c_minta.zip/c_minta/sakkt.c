/* SAKKT.C */
#include <stdio.h>
#include <stdlib.h>

typedef int sakk[8][8];

main()
{
 int i,j,k;
 sakk *sakktabla;
 sakktabla = (sakk*)calloc(1,sizeof(sakk));
 if(!sakktabla) {
    printf("\a\nNincs el�g mem�ria!\n");
    return -1;
 }
 k = 1;
 /* fekete = 1, feh�r = 0 */
 for(i = 0; i < 8; i++)
 { if(k ) k = 0;
   else k = 1;
   for( j = 0; j <8; j++)
   {
     (*sakktabla)[i][j] = k;
     if ( k ) k = 0;
     else k = 1;
   }
 }
 printf("\n    Sakkt�bla\n");
 for( i = 0; i < 8; i++)
 {
   for( j = 0; j < 8; j++)
   printf(" %d",(*sakktabla)[i][j]);
  printf("\n");
 }
}
