
#include <stdio.h>
#include <conio.h>

#define ESC 27
main()
{
  char ch;
  printf("K�rek egy karaktert: ");
  ch=getch();
  if (ch == ESC)
     printf("\aEsc\n");
}

