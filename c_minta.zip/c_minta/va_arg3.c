#include <stdarg.h>
#include <stdio.h>

/* A f�ggv�nyek protot�pusa */
void hibauzenet(char * formatum, ...);

main()
{
 hibauzenet(NULL);
 hibauzenet("Csak sz�veg!\n");
 hibauzenet("Az x �rt�ke %d\n",123);
 hibauzenet("S�r�lt �llom�ny: %s\n", "ADATOK.DAT");
}


 /* A hibauzenet f�ggv�ny defin�ci�ja*/

void hibauzenet(char * formatum, ...)
{
  va_list  pfmt;

  if (formatum != NULL) {  /* Ha van �zenet */
      va_start( pfmt, formatum);  /* Az els� argumentum �tl�p�se */

      printf("\n\a***HIBA***\t");
      vprintf(formatum, pfmt);

      va_end(pfmt);
  }
}
