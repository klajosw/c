/* OSZTO.C */
#include <stdio.h>

main()
{
 int i1, i2, k;
 printf("\nOszthat�s�g meg�llapit�sa\n");
 printf("Az els� sz�m  : "); scanf("%d",&i1);
 printf("A m�sodik sz�m: "); scanf("%d",&i2);
 k = i2 % i1;
 if ( k ){
   printf("A %d sz�m nem oszt�ja a %d sz�mnak\n",i1,i2);
   printf("A h�nyados: %d\n", i2/i1);
   printf("A marad�k : %d\n", k);
   }
 else
  printf("%d sz�m oszt�ja a %d sz�mnak: %d\n",i1,i2,i2/i1);

}
