/* INVERZ.C */

/*  Inverz m�trix sz�mit�sa LU dekompozici�val */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#define MAXELEM 20
typedef double tomb[MAXELEM+1][MAXELEM+2];
typedef double vekt[MAXELEM+1];

void olvas(tomb a, tomb e, int n);
void eredmeny(tomb a, tomb e, int d, int n);
void matrixkiir(tomb a, int n);
void sorcsere(tomb a, tomb e, int xm, int k, int n);
void foelem(tomb a, tomb e, int n, int k, int *d);
void dekompf(tomb a, tomb e, int n,int *d);
void yvektor(vekt y,tomb a, int n);
void xvektor(vekt x, vekt y, tomb a, int n);
void inverz(tomb a, tomb e, int n);
double det(tomb a, int n, int d);

void main()
{
int  n, d=1;
tomb a, e;
   _fpreset();
   printf("\nM�trix invert�l�sa LU dekompozici�val\n");
   printf("   r�szleges f�elemkiv�laszt�ssal \n\n");
   do {
       printf("\nElemek sz�ma [max. 20]: ");
       scanf("%d",&n);
   }while ( n > MAXELEM);

   olvas(a,e,n);
   printf("\nA m�trix \n\n");
   matrixkiir(a,n);
   dekompf(a,e,n,&d);
   eredmeny(a,e,d,n);
}

void olvas(tomb a,tomb e, int n)
{
 int i, j;

  printf("\n");
  for ( i = 1; i <= n; i++ )
  {
    for ( j = 1; j <= n; j++ )
    {
      printf("a[%d,%d]= ",i,j); scanf("%lf",&a[i][j]);
      if ( i == j )
      {
	e[i][j] = 1.0;
      }
      else
      {
	e[i][j] = 0.0;
      }
    }
    printf("\n");
  }

}
/* Az eredm�nyek kiirat�sa */
void eredmeny(tomb a, tomb e, int d, int n)
{

   printf("\nAz inverz m�trix:\n\n");
   inverz(a,e,n);

   printf("\nA determin�ns: %e\n",det(a,n,d));
}

void matrixkiir(tomb a, int n)
{
  int i,j;
  for ( i=1; i<=n; i++ )
  {
    for ( j=1; j<=n; j++)
    {
      printf("%13.4e",a[i][j]);
    }
    printf("\n");
  }
}

/* A m�trix sorainak felcser�l�se  */
void sorcsere(tomb a,tomb e,int xm,int k,int n)
{
  int i;
  double c;
  for ( i = 1; i <= n; i++ )
  {
    c=a[xm][i]; a[xm][i]=a[k][i]; a[k][i]=c;
    c=e[xm][i]; e[xm][i]=e[k][i]; e[k][i]=c;
  }
}

/* A f�elem kiv�laszt�sa */
void foelem(tomb a,tomb e,int n,int k, int *d)
{
  int i,xm;
  double am;
  am=a[k][k]; xm=k;
  for ( i = k; i <= n; i++ )
  {
    if (fabs(am) < fabs(a[i][k]))
    {
      am=a[i][k]; xm=i;
      sorcsere(a,e,xm,k,n);
      *d=*d *(-1);
    }
  }
}

/* dekompozici� v�grehajt�sa f�elem kiv�laszt�s�val */
void dekompf(tomb a,tomb e,int n, int *d)
{
 int i,j,k;

   *d = 1;
   for ( k = 1; k < n; k++ )
   {
      foelem(a,e,n,k,d);
      printf("\n%d. iter�cio Oszt: %13.4e\n\n",k,a[k][k]);
      for ( i = k+1; i <= n; i++ )
      {
	 a[i][k]=a[i][k]/a[k][k];
	 for ( j = k+1; j <= n; j++ )
	 {
	   a[i][j]=a[i][j]-a[i][k]*a[k][j];
	 }
      }
      matrixkiir(a,n);
   }
}

/*  Ly = b egyenlet megold�sa */
void yvektor(vekt y,tomb a,int n)
{
  int j,k;
  y[1]=a[1][n+1];
  for ( k = 2; k <= n; k++)
  {
    y[k]=0;
    for ( j = 1; j <= k-1; j++)
    {
      y[k]=y[k]-a[k][j]*y[j];
    }
    y[k]=y[k]+a[k][n+1];
  }
}

/*  U x = y egyenlet megold�sa */
void xvektor(vekt x,vekt y,tomb a,int n)
{
  int j,k;
    x[n]=y[n]/a[n][n];
    for ( k = n-1; k >= 1; k--)
    {
      x[k]=0;
      for ( j = k+1; j <= n; j++ )
      {
	x[k]=x[k]-a[k][j]*x[j];
      }
      x[k]=(y[k]+x[k])/a[k][k];
    }
}

/* A m�trix inverz�nek kisz�mit�sa */
void inverz(tomb a,tomb e, int n)
{
 int i,j;
 vekt x, y;
  for ( j = 1; j <= n; j++ )
  {
    for ( i = 1; i <= n; i++ )
    {
      a[i][n+1]=e[i][j];
    }
    yvektor(y,a,n);
    xvektor(x,y,a,n);
    for ( i = 1; i <= n; i++ )
    {
      e[i][j]=x[i];
    }
  }
  matrixkiir(e,n);
}

/* A determin�ns kisz�mit�sa */
double det(tomb a,int n, int d)
{
  int k;
  double c;
  c=a[1][1];
  for ( k = 2; k <= n; k++ )
  {
    c=c*a[k][k];
  }
  return (d * c);
}




