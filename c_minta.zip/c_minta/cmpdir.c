  /*-------------------------------------------------------------*
			      CMPDIR.C

     A p�ldaprogram k�t alk�nyvt�r tartalm�t hasonl�tja �ssze.

     Haszn�lata: CMPDIR dir1 dir2 /kapcsolo

     Alaphelyzetben a k�perny�n jelen�ti meg az azonos nev� file-ok
     k�z�tt fenn�ll� viszony, de a /k kapcsol� megad�sa ut�n az
     azonos �llom�nyok kit�rl�dnek a dir1 k�nyvt�rb�l.

   *-------------------------------------------------------------*/

#include <dos.h>
#include <stdio.h>
#include <io.h>
#include <dir.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>

#define SLEN  255
#define NELEM 256
#define PSIZE 0x4000U

typedef char string[SLEN+1];

typedef struct {
		 char name[13];
		 long fsize;
		 char res;
	       } finfo;

finfo tdir[NELEM];

char * rpuf1, * rpuf2;
char * fpuf1, * fpuf2;

/*************************/
/* Kil�p�s hiba�zenettel */
/*************************/
void error(char * msg)
{
  printf("\08");
  printf(msg);
  exit(0);
}

/********************************************/
/* A forr�sk�nyvt�r tartalm�nak felolvas�sa */
/********************************************/
void  getdircont(int * cnt, string dir)
{
  string adir;
  int adrive;
  string cdrive,cdir, cname, cext;
  struct ffblk  dirinfo;
  int ok;

  *cnt=-1;

  /* Az aktu�lis k�nyvt�r lek�rdez�se */
  getcwd(adir,SLEN);
  adrive=getdisk();

  fnsplit(dir,cdrive,cdir, cname, cext);
  setdisk(toupper(cdrive[0])-'A');
  if (chdir(dir)) error("Hib�s I/O m�velet!\n");

  ok=findfirst("*.*", &dirinfo, 0);
  while (!ok && *cnt<NELEM-1)
  {
    if (dirinfo.ff_name[0]==0) break;
    (*cnt)++;
    strcpy(tdir[*cnt].name,dirinfo.ff_name);
    tdir[*cnt].fsize=dirinfo.ff_fsize;
    ok=findnext(&dirinfo);
  }
  setdisk(adrive);
  chdir(adir);
}


/*********************/
/* A z�r� / lev�tele */
/*********************/
char * nobs(string dir)
{
  if (dir[strlen(dir)-1]=='\\') dir[strlen(dir)-1]=0;
  return dir;
}

/*****************************/
/* K�t file �sszehasonl�t�sa */
/*****************************/
char cmpfile(string fn1,long fs1, string fn2)
{
  FILE *f1, *f2;
  long fs2;
  int  ok=1;
  int rin;

  f2 = fopen(fn2, "rb");
  if (f2==NULL) return '0';

  f1 = fopen(fn1, "rb");

  fs2=filelength(fileno(f2));
  if (fs1!=fs2)
    {
     fclose(f1);
     fclose(f2);
     if (fs1<fs2)
       return '<';
     else
       return '>';
    }

 setvbuf(f1, fpuf1, _IOFBF, PSIZE/2);
 setvbuf(f2, fpuf2, _IOFBF, PSIZE/2);

 while (!feof(f1))
  {
    rin=fread(rpuf1,1,PSIZE,f1);
    fread(rpuf2,1,PSIZE,f2);
    if (memcmp(rpuf1,rpuf2,rin)) ok=0;
  }

 fclose(f1);
 fclose(f2);

 if (ok)
   return '=';
 else
   return '!';
}

/*********************************/
/* K�t k�nyvt�r �sszehasonl�t�sa */
/*********************************/
void cmpdir(int cnt, string dir1, string dir2)
{
  int i;
  string f1,f2,res;

  for (i=0; i<=cnt; i++)
   {
    strcpy(f1,dir1);
    strcat(f1,"\\");
    strcat(f1,tdir[i].name);

    strcpy(f2,dir2);
    strcat(f2,"\\");
    strcat(f2,tdir[i].name);
    tdir[i].res=cmpfile(f1,tdir[i].fsize,f2);
    switch (tdir[i].res)
     {
      case '0' : strcpy(res," ->"); break;
      case '=' : strcpy(res," =="); break;
      case '!' : strcpy(res," !="); break;
      case '<' : strcpy(res," < "); break;
      case '>' : strcpy(res," > "); break;
     }
    printf("%-35s%-7s %-35s\n",f1,res,f2);
   }
}

void main(int argc, char **argv)
{
 string sor;
 string dir1, dir2;
 int    cnt1;
 int    i;

  if (argc<3)
     {
       printf("\nUse: CMPDIR dir1 dir2 [/par]\n");
       exit(-1);
     }

  clrscr();

  rpuf1=(char *) malloc(PSIZE);
  if (!rpuf1) error("Kev�s a mem�ria!\n");
  rpuf2=(char *) malloc(PSIZE);
  if (!rpuf2) error("Kev�s a mem�ria!\n");

  fpuf1=(char *) malloc(PSIZE/2);
  if (!fpuf1) error("Kev�s a mem�ria!\n");
  fpuf2=(char *) malloc(PSIZE/2);
  if (!fpuf2) error("Kev�s a mem�ria!\n");

  strcpy(dir1,nobs(argv[1]));
  strcpy(dir2,nobs(argv[2]));

  getdircont(&cnt1,dir1);

  if (cnt1==-1) error("�res k�nyvt�r!\n");

  cmpdir(cnt1,dir1,dir2);

  free(rpuf1);
  free(rpuf2);

  free(fpuf1);
  free(fpuf2);

  /* A param�terek feldolgoz�sa */
  if (argc==4)
  switch (toupper(argv[3][1]))
   {
     case 'K':
	clrscr();
	for (i=0; i<=cnt1; i++)
	  if (tdir[i].res=='=')
	     {
	       strcpy(sor,dir1);
	       strcat(sor,"\\");
	       strcat(sor,tdir[i].name);
	       unlink(sor);
	       printf("%-35s � \n",sor);
	     }
    }
}
