/* Virtualis tomb header file */
#include <alloc.h>
#include <stdio.h>

/* Virtu�lis t�mb vez�rl� blokk - VACB */
typedef struct {
        FILE *file     ; /* mutat� a FILE strukt�r�ra */
        long size      ; /* az elemek sz�ma a file-ban */
        int elsize     ; /* az elemek m�rete byte-ban */
        char *buffer   ; /* a puffer helye */
        int buf_elsize ; /* az elemek m�rete a pufferben */
        int buf_size   ; /* az elemek sz�ma a pufferben */
        char * blank_rec ; /* mutat� az inicializ�ci�s rekordra */
                           /* sz�ks�ges a file b�v�t�s�hez! */
 } VACB;

 /* A t�mbkezel� f�ggv�nyek protot�pusa */

 int    init_varray(char * , int, char);
 VACB * open_varray(char *, int);
 void  close_varray(VACB *);
 void * access_varray(VACB *,long);
 void *access_v_rec(VACB * varray,long index);
                            
