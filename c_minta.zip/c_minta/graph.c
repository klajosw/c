#include<graphics.h>
#include<conio.h>
#include<dos.h>
#include<math.h>
void main()
{
   int gdriver=0,gmode;
   double c,k,a,b,r=50.0;
   initgraph(&gdriver,&gmode,"c:\\tuc\\bgi");
   setcolor(15);
   a=getmaxx()/2;
   b=getmaxy()/2;
	 for (c=0;c<=3.1415;c+=0.1)
    {
			setcolor(WHITE);
			line(a+r*sin(c),b-r*cos(c),a+r*cos(c),b+r*sin(c));
			line(a+r*cos(c),b+r*sin(c),a-r*sin(c),b+r*cos(c));
			line(a-r*sin(c),b+r*cos(c),a-r*cos(c),b-r*sin(c));
			line(a-r*cos(c),b-r*sin(c),a+r*sin(c),b-r*cos(c));
			delay(2);
			setcolor(BLACK);
			line(a+r*sin(c),b-r*cos(c),a+r*cos(c),b+r*sin(c));
			line(a+r*cos(c),b+r*sin(c),a-r*sin(c),b+r*cos(c));
			line(a-r*sin(c),b+r*cos(c),a-r*cos(c),b-r*sin(c));
			line(a-r*cos(c),b-r*sin(c),a+r*sin(c),b-r*cos(c));
		
    }
      getch();

   
   closegraph();
}