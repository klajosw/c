/* SZINES.C */
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>

void main()
{
  int                Gd, Gm, Hibakod;
  char               color;
  struct palettetype palette;
  Gd = DETECT;

  initgraph(&Gd, &Gm, "");
  Hibakod= graphresult();
  if (Hibakod)
  {
    clrscr();
    cprintf("Grafikus hiba: %s",grapherrormsg(Hibakod));
    exit(1);
  }
  getpalette(&palette);
  if(palette.size != 1)
  {
    for (color = 0; color<= palette.size; color++)
    {
      setcolor(color);
      line(0, color*10, 100, color*10);
    }
  }
  else
   line(0,0,100,0);
   getch();
  /* grafika lez�r�sa */
  closegraph();
}