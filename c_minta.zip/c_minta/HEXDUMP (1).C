/*--------------------------------------------------*/
/*                 HEXDUMP.C                        */
/*                                                  */
/*       Adott file tartalm�nak megjelen�t�se       */
/*              hexadecim�lis form�ban              */
/*--------------------------------------------------*/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <mem.h>

#define WAIT { while(kbhit()==0); if (getch()==0x1B) exit(1);}

#define REC_SIZE 256

typedef unsigned char  byte;

dump_rec(int file_rec, int  count);


byte   file_buf[REC_SIZE];
long   file_ptr=0L;
FILE   *dfile;


/*---------------------*/
/*   A main f�ggv�ny   */
/*---------------------*/
main(argc,argv)

   int   argc;
   char  *argv[];

{
  int  status=0;
  int  file_rec=0;

  if (argc != 2)
     {
       fprintf(stderr,"\nHaszn�lat: HEXDUMP file-n�v\n");
       return(1);
     }

  if ((dfile=fopen(argv[1],"rb")) == NULL)
     {
       fprintf(stderr,"\nHEXDUMP: nem tal�lom : %s \n",argv[1]);
       return(1);
     }

  while ((status=fread(file_buf,1,REC_SIZE,dfile)) != 0)
     {
       printf("\n\nA file : %s ",argv[1]);
       printf("\n");
       dump_rec(++file_rec,status);
       printf("\n");
       WAIT;
       file_ptr+=REC_SIZE;
    }
  fclose(dfile);
  return(0);

}

/*-----------------------------------*/
/*   Egy rekord kiirasa (128 byte)   */
/*-----------------------------------*/
dump_rec(int file_rec, int  count)
{
   int offs;
   int j,maxj;
   byte c;
   char line[81];

   printf("\n\nRecord %04X\n",file_rec);

   printf("\n       0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F");

   for (offs=0; offs<count; offs+=16)
    {
	   setmem(line,80,' ');
	   line[80]='\0';

	   maxj=(count-offs <16) ? count-offs : 16;

	   sprintf(line,"\n%04lX  ",file_ptr+offs);

	   for(j=0; j<maxj; j++)
	     {
		 sprintf(line+6+j*3," %02X",file_buf[offs+j]);
		 c=file_buf[offs+j];
		 sprintf(line+58+j,"%c",(c<32 ? '.': c));
	     }

      for(j=0;j<=79;line[j++]=(line[j] ? line[j] : 32));

      printf("%s",line);
      }


  for(j=0; j<(REC_SIZE-count)/16+1 ;j++)
    printf("\n");

}
