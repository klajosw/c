/*  GRVALTAS.C */
/* Grafika �s sz�veges m�d v�lt�sa */
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>

void main()
{
 int Gd,Gm, Hibakod;
   Gd = DETECT;
   initgraph(&Gd,&Gm,"");
   Hibakod = graphresult();
   if (Hibakod)
   {
     clrscr();
	   cprintf("Grafikus hiba: %s",grapherrormsg(Hibakod));
     exit(1);
   }
   rectangle(20,20,290,100);
   outtextxy(25,30,"<RETURN> kil�p�nk a grafik�b�l.");
     getch();
   restorecrtmode();
   gotoxy(10,10);
   cputs(" Sz�veges m�dban vagyunk!");
   gotoxy(10,12);
   cputs("<RETURN> hat�s�ra visszat�r�nk grafikus m�dba.");
     getch();
   setgraphmode(getgraphmode());
   rectangle(20,20,290,100);
   outtextxy(25,30,"Grafikus m�dban vagyunk");
   outtextxy(25,30+textheight("H"),"<RETURN> lez�rjuk a grafik�t");
     getch();
   closegraph();
}