
#include <stdio.h>

main()
{
  char valasz;

  printf("A v�lasz [I/N]?");
  valasz=getchar();              /* karakter input */

  switch (valasz)
  {
    case 'i':  case 'I':         /* Igen ?   */
       printf("A v�lasz IGEN.\n");
       break;

    case 'n':                    /* Nem ?   */
    case 'N':
       printf("A v�lasz NEM.\n");
       break;

    default:
       {
	  printf("Hib�s v�lasz!\n");
       }
  }
}

