/* RAJZ1.C */
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>

void main()
{
 int Gd, Gm, Hibakod;
 int Hsz [] = { 80, 240,
		240, 240,
		270, 270,
		80, 240};
 int Hsz1[] = { 300, 240,
		360, 240,
		360, 310,
		300, 240};

 struct arccoordstype ivkoord;

   Gd = EGA;
   Gm = EGAHI;
   initgraph(&Gd, &Gm,"");
   Hibakod = graphresult();
   if (Hibakod != grOk)
   {
      clrscr();
      cprintf("Grafikus hiba: %s", grapherrormsg(Hibakod));
      exit(1);
   }
   setbkcolor(WHITE);
   setcolor(RED);

   arc(50,100,0,120,50);
   setfillstyle(LTBKSLASH_FILL,4);
   bar(120,20,150,100);
   bar3d(160,30,180,100,10,0);
   setfillstyle(LINE_FILL,1);
   bar3d(160,30,200,100,10,1);
   circle(250,50,30);
   rectangle(300,40,320,100);
   ellipse(400,60,0,360,50,30);
   setfillstyle(SLASH_FILL,5);
   fillellipse(520,60,20,40);
   circle(600,50,30);
   moveto(50,120);
   setcolor(WHITE);
   lineto(100,120);
   linerel(0,20); linerel(30,0);
   moverel(30,0); lineto(160,120); linerel(30,20);
   setcolor(BLUE);
   line(220,140,270,140);
   setlinestyle(CENTER_LINE,0,1);
   line(220,130,270,130);
   setlinestyle(DOTTED_LINE,0,1);
   line(290,140,340,140);
   setlinestyle(DASHED_LINE,0,1);
   line(290,130,340,130);
   setlinestyle(SOLID_LINE,0,3);
   line(360,140,410,140);

   setlinestyle(SOLID_LINE,0,1);
   setcolor(RED);
   setfillstyle(SLASH_FILL,14);
   pieslice(80,200,90,360,30);
   setfillstyle(XHATCH_FILL,5);
   pieslice(80,200,20,75,30);

   sector(150,200,0,120,50,30);

   drawpoly(4,Hsz);
   setfillstyle(WIDE_DOT_FILL,4);
   fillpoly(4,Hsz1);

   arc(250, 200, 0,120,30);
   getarccoords(&ivkoord);
   line(ivkoord.xstart,ivkoord.ystart,ivkoord.xend,ivkoord.yend);
   getch();
   closegraph();
}
