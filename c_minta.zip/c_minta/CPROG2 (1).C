
int sum(int x, int y)              /* A sum f�ggv�ny defin�ci�ja */
{
  int z;                           /* Lok�lis defin�ci�k �s      */
				   /* deklar�ci�k                */

  z=x+y;                           /* Utas�t�sok */
  return z;
}

