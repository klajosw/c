/********************************************************************
**  DBase file rekordjainak listzazasa
**
**  Hasznalata:  DBFLIST dbasefile-nev
********************************************************************/

#include <stdio.h>
#include <alloc.h>
#include <mem.h>

#include <string.h>
#include <stdlib.h>
#include "dbf.c"

/************************************************/
/* DBASE datum konvertalasa MM/DD/YY formatumra */
/************************************************/
void fdate(char *buff)
{
        int day;
        int mon;
        int yr;
        if (buff[0]==' ')
                {
                buff[0]='\0';
                strcat(buff,"  /  /  ");
                }
        else
                {
                sscanf(buff,"%4d%02d%02d",&yr,&mon,&day);
                sprintf(buff,"%02d/%02d/%d",mon,day,yr-1900);
                }
}


main(int argc,char **argv)
{
        int errornum;
        long rec;
        int fld;
        struct DBF *d;
        static char buff[255];

        if(argc != 2)
        {
                printf("\nHasznalat: DBFLIST file-nev\n");
                exit(1);
        }
        /* helyfoglalas a DBF struktura szamara */
        d = (struct DBF *)malloc(sizeof(struct DBF));

        strcpy(d->filename,argv[1]);

        if(!strchr(d->filename,'.'))
                strcat(d->filename,".DBF");

        if((errornum = d_open(d))!=0)                                                                                            /* open file                                                   */
        {
        printf("File nyitasi hiba: ");
        switch (errornum)
        {
                case OUT_OF_MEM:
                        printf("Nincs eleg memoria\n");
                        break;
                case NO_FILE:
                        printf("A %s file nem talalhato.\n",d->filename);
                        break;
                case BAD_FORMAT:
                        printf("A %s file nem DBF file.\n",d->filename);
                        break;
        }
        free(d);
        exit(1);
        }

        for(rec=1;rec<=d->records;rec++)
        {
                printf("\n%-5u",rec);
                d_getrec(d,(long)rec);
                for(fld=1;fld<=d->num_fields;fld++)
                {
                        if(d_getfld(d,fld,buff) == 'D')
                                fdate(buff);
                        printf(" %s",buff);
                }
        }

        d_close(d);
        free(d);
}

