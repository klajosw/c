/* KALEID.C */

#include <stdlib.h>
#include <graphics.h>
#include <conio.h>
#include <time.h>
#include <dos.h>
#include <string.h>

#define MAXOBJ  150

typedef void (*RajzoloFv) ( int x1, int y1, int x2, int y2 );

struct {
     int x1,y1,x2,y2;
     RajzoloFv fv;
       } Alakzat [MAXOBJ];

char * FvNevek[] = {  " �tl�",      " t�glalap",  " v-bet�",
		      " h�romsz�g", " csokor",    " kereszt",
		      " plusz",     " csillag",   " z-bet�",
		      " rombusz",   " sugarak" };

char * Szinek[]   = { "Fekete",   "K�k",    "Z�ld",   "Ci�n",
		      "Piros",    "Lila",   "Barna",  "V.sz�rke",
		      "S.sz�rke", "V.k�k",  "V.z�ld", "V.ci�n",
		      "V.piros",  "V.lila", "S�rga",  "Feh�r"};


void fNameOut(int fdx,int cdx)
{
  char p[80];
  int c=getcolor();

  strcpy(p,Szinek[cdx]);
  strcat(p,FvNevek[fdx]);

  setfillstyle(SOLID_FILL,0);
  bar(0,getmaxy()-10,getmaxx()/2,getmaxy());
  setcolor(WHITE);
  outtextxy(0,getmaxy()-10,p);
  setcolor(c);
}

void Ures ()
{
}


void Atlo ( int x1, int y1, int x2, int y2 )
{
  moveto ( x1, y1 );
  lineto ( x2, y2 );
}


void Teglalap ( int x1, int y1, int x2, int y2 )
{
  moveto ( x1, y1 );
  lineto ( x2, y1 );
  lineto ( x2, y2 );
  lineto ( x1, y2 );
  lineto ( x1, y1 );
}


void V_betu ( int x1, int y1, int x2, int y2 )
{
  moveto ( x1, y1 );
  lineto ( (x1+x2)/2, y2 );
  lineto ( x2, y1 );
}


void Haromszog ( int x1, int y1, int x2, int y2 )
{
  moveto ( x1, y1 );
  lineto ( (x1+x2)/2, y2 );
  lineto ( x2, y1 );
  lineto ( x1, y1 );
}


void Csokor ( int x1, int y1, int x2, int y2 )
{
  moveto ( x1, y1 );
  lineto ( x1, y2 );
  lineto ( x2, y1 );
  lineto ( x2, y2 );
  lineto ( x1, y1 );
}


void Kereszt ( int x1, int y1, int x2, int y2 )
{
  moveto ( x1, y1 );
  lineto ( x2, y2 );
  moveto ( x1, y2 );
  lineto ( x2, y1 );
}


void Plusz ( int x1, int y1, int x2, int y2 )
{
  int x, y;

  x = (x1+x2)/2;
  y = (y1+y2)/2;
  moveto ( x1, y );
  lineto ( x2, y );
  moveto ( x, y1 );
  lineto ( x, y2 );
}


void Csillag ( int x1, int y1, int x2, int y2 )
{
  int x, y;

  x = (x1+x2)/2;
  y = (y1+2*y2)/3;
  moveto ( x1, y1);
  lineto ( x , y2 );
  lineto ( x2, y1 );
  lineto ( x1, y  );
  lineto ( x2, y );
  lineto ( x1, y1 );
}


void Z_Betu ( int x1, int y1, int x2, int y2 )
{
  int x, x0;

  x  = (2*x1+x2)/3;
  x0 = (x1+2*x2)/3;
  moveto ( x1, y1);
  lineto ( x , y2 );
  lineto ( x0, y1 );
  lineto ( x2, y2 );
}


void Rombusz ( int x1, int y1, int x2, int y2 )
{
  int x, y;
  x = (x1+x2)/2;
  y = (y1+y2)/2;
  moveto ( x1, y  );
  lineto ( x , y2 );
  lineto ( x2, y  );
  lineto ( x , y1 );
  lineto ( x1, y  );
}


void Sugarak ( int x1, int y1, int x2, int y2 )
{
  moveto ( x2, (y1+y2)/2 );
  lineto ( x1, y1 );
  lineto ( (x1+x2)/2 , y2 );
  moveto ( x1, y1 );
  lineto ( x2, y2 );
}


#define  Keret(c,v,m)  c+=v; if ( c<0 || m<=c ) { v=-v; c+=v; }


void main ()
{
  char q=0;
  int i, c, p, fidx;
  int x1, y1, x2, y2, vx1, vy1, vx2, vy2;
  RajzoloFv f, RFv[] = { Atlo,   Teglalap, V_betu, Haromszog,
			 Csokor, Kereszt,  Plusz,  Csillag,
			 Z_Betu, Rombusz,  Sugarak };
  int gdriver = DETECT, gmode;
  int maxx, maxy, maxc;

  initgraph(&gdriver, &gmode, "");

  /* A kezdeti �rt�kek be�ll�t�sa */
  randomize ();
  maxc=getmaxcolor();
  maxx=getmaxx();
  maxy=getmaxy()-textheight("A")-1;

  setcolor ( getmaxcolor());

  for ( i = 0; i < MAXOBJ; ++i )   Alakzat[i].fv = Ures;

  x1   = random(maxx);
  y1   = random(maxy);
  x2   = random(maxx);
  y2   = random(maxy);
  vx1  =  3;
  vy1  =  2;
  vx2  = -2;
  vy2  =  3;
  c    =  YELLOW;
  f    =  Atlo;
  fidx = 0;

  setcolor(c);
  fNameOut(fidx,c);

  /* A Rajzol�s ind�t�sa  - ESC lenyom�s�ig */
  /* + sz�nv�lt�s
     - alakzat  cser�je    */

  for ( p = 0; q != 27; p = (p+1) % MAXOBJ )
  {
    if ( ! random(1500) )
       {
	  fidx = random ( sizeof(RFv)/sizeof(RajzoloFv) );
	  f    = RFv [ fidx];
	  fNameOut(fidx,c);
       }
    if ( ! random( 300) )
       {
	 c = 1 + random (maxc);
	 fNameOut(fidx,c);
       }

    if ( ! random( 500) ) vx1 = 1 + random ( maxx / 100 );
    if ( ! random( 500) ) vy1 = 1 + random ( maxy / 100 );
    if ( ! random( 500) ) vx2 = 1 + random ( maxx / 100 );
    if ( ! random( 500) ) vy2 = 1 + random ( maxy / 100 );

    Keret ( x1, vx1, maxx);
    Keret ( y1, vy1, maxy);
    Keret ( x2, vx2, maxx);
    Keret ( y2, vy2, maxy);

    setcolor ( 0 );
    Alakzat[p].fv ( Alakzat[p].x1,  Alakzat[p].y1,
		    Alakzat[p].x2,  Alakzat[p].y2 );
    setcolor ( c );
    f ( x1, y1, x2, y2 );

    Alakzat[p].fv = f;
    Alakzat[p].x1 = x1;
    Alakzat[p].y1 = y1;
    Alakzat[p].x2 = x2;
    Alakzat[p].y2 = y2;


    if (kbhit())
    {
      q = getch();
      switch ( q )
      {
	case '+': c = 1 + random (maxc);
		  fNameOut(fidx,c);
                  break;
	case '-':
		  fidx=random ( sizeof(RFv)/sizeof(RajzoloFv) );
		  f = RFv [ fidx];
		  fNameOut(fidx,c);
                  break;
      }

    }
    delay ( 5 );
 }
 closegraph();
}
