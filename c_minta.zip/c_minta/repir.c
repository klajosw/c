/* REPIR.C */
#include <stdio.h>
#include <stdlib.h>

typedef struct szemely{
		       char nev[21];
		       int  utlevelsz;
		       int  sz_datum;
		       char r_datum[9];
		       int  km;
		       struct szemely *kov;
		     } UTAS;
UTAS sz, *psz;
void kiir(char fnev[]);

main()
{
char nev[21];
int utlevelsz,sz_datum, km;
char r_datum[9];
char fnev[13];
int  n, i;
FILE *f;

    printf("File neve: "); scanf("%s",fnev);
    f = fopen(fnev,"w");
    printf("Az utasok sz�ma: "); scanf("%d",&n);
    for (i = 1; i <= n; i++)
    {
      printf("\nVezet�k neve : "); scanf("%s",nev);
      printf("�tlev�l sz�ma: "); scanf("%d",&utlevelsz);
      printf("sz�let�si d�tuma (�v sz�ma): "); scanf("%d",&sz_datum);
      printf("utaz�s id�pontja (ee/hh/nn): "); scanf("%s",r_datum);
      printf("�t hossza km-ben           : "); scanf("%d",&km);
      fprintf(f,"%s %d %d %s %d\n",nev,utlevelsz, sz_datum,r_datum,km);
    }
     fclose(f);
     kiir(fnev);
}

void kiir(char fnev[])
{
FILE *folv;
char nev[21];
int  utlevel, szd, km;
char rd[9];
  folv = fopen(fnev, "r");

  if( folv == NULL) { printf("File nem l�tezik !\n");
		    exit(1);
		  }
  while (EOF != fscanf(folv,"%s %d %d %s %d",nev,&utlevel,&szd,rd,&km))
  {
    printf("%s %d %d %s %d \n",nev,utlevel,szd,rd,km);
  }
 return;
}
