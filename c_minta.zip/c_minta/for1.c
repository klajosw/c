
#include <stdio.h>

main()
{
  long sum;
  int  i,n = 1994;

  for (i=1, sum=0 ; i<=n ; i++)
      sum += i;
  printf("Az els� %d eg�sz �sszege: %ld\n", n, sum);
}

