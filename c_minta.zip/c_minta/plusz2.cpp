 #include <stdio.h>
 #include <conio.h>           //clrscr    (main)
 #include <string.h>          //strcmp    (datumbeall2)
 #include <dos.h>             //getdate   (datumbeall3)
 #include <time.h>            //time,localtime  (datumbeall4)
 #include <alloc.h>           //malloc          (main)

//-------------------------struktura--------------------------------------------

 struct datum {
  int ho;
  int nap;
   void datumbeall(int a, int b) {
				  ho=a;
				  nap=b;
				 };

  void datumbeall2(char *d) {
		    if (strcmp(d,"karacsony")==0)  { ho=12; nap=25; }
		    if (*d=='h')                   { ho=4;  nap=12; }
		    if (strcmp(d,"szulinap")==0)   { ho=5;  nap=8; }
			    };

  void datumbeall3() 	{              //mai datum a gepidobol
		struct date *dat; dat=(struct date *)malloc(sizeof(struct date));
		getdate( dat);
		ho=dat->da_mon;  nap=dat->da_day;
		};

  void datumbeall4() 	{              //mai datum a gepidobol
		time_t t=time(NULL);
		struct tm* tmm;
		tmm=localtime(&t);
		ho=(tmm->tm_mon)+1;  nap=tmm->tm_mday;
		}  ;

  void datumkiir() {
		      printf("Megegyszer:%d.%d",ho,nap);
		     };

  int datumkul(datum datum2)               //datum2-tol maig
	{
		int enap,eho,eredm;
		enap=(nap-datum2.nap);  	eho=(ho-datum2.ho);
		if (enap<0)  {enap+=30; --eho;}
		if (eho<0)    eho+=12;    eredm=(eho*30+enap);
		return(eredm);
	}


  };
//---------------struktura vege-----------------------------------------------

  main()
  { clrscr();
  datum ma,holnap;
  ma.nap=7;                   printf("\n%d  %d\n",ma.ho,ma.nap);
  ma.datumbeall(3,12);        printf("\n%d  %d\n",ma.ho,ma.nap);
  holnap.datumbeall2("szulinap"); printf("\n%d  %d\n",holnap.ho,holnap.nap);
  ma.datumbeall3();           printf("\n%d  %d\n",ma.ho,ma.nap);
  ma.datumbeall4();           printf("\n%d  %d\n",ma.ho,ma.nap);
  ma.datumkiir();
  int i=holnap.datumkul(ma); printf("\nkulonbseg: %d\n",i);  //matol holnapig
  delay(1000);
  }










