/* SORREND.C */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int hasonlit(const void *a, const void *b);
void beolvas(void);
void kiir(void);

typedef char sor[81];
typedef sor *sormut;
sormut  lines;
int     n;

main(void)
{
 beolvas();
 qsort(lines, n, sizeof(sor), hasonlit);
 kiir();
}

int hasonlit(const void *a, const void *b)
{
  return strcmp((char*)a, (char *)b);
}

void beolvas(void)
{ /* ellen�rz�s n�lk�l */
  FILE *finp;
  int  i;
  char utolso[81];

   printf("N = "); scanf("%d",&n);
   finp = fopen("bemeno.txt", "r");
   lines = (sormut)malloc(n*sizeof(sor));

   for(i = 0; i < n; i++)
   {
     if(NULL == fgets(lines[i],80,finp))
     {
	n = i - 1;
	continue;
     }
     lines[i][strlen(lines[i])-1] = '\0';
   }
   if(NULL != fgets(utolso, 80, finp))
      printf("\nA file-ban van m�g adat!\n");
   fclose(finp);
 }

void kiir(void)
{
  FILE *fout;
  int  i;

  fout = fopen("kimeno.txt","w");
  for(i = 0; i < n; i++)
  {
    fprintf(fout,"%s\n",lines[i]);
  }
  free(lines);
  fclose(fout);
 }



