
#include <stdio.h>

typedef int vektor8[8];

vektor8 a = {1, 2, 3, 4, 5, 0, 1, 3};
vektor8 b = {4, 3, 2, 1, 0, 5, 4, 2};

main()
{
 vektor8 c, d;
 int i;

 for (i = 0; i < 8; i++)   /* Az elemek �sszegz�se    */
     c[i] = a[i] + b[i];

 for (i = 0; i < 8; i++)   /* A c vektor m�sol�sa d-be */
     d[i] = c[i];

 printf("\nd = ( ");       /* A d vektor ki�r�sa       */
 for (i = 0; i < 8; i++)
     printf(i < 8-1 ? "%d, " : "%d ", d[i]);
 printf(")\n");
}



