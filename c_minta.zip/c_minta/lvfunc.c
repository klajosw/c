#include <stdio.h>

int * kozvetit( int * p)
{
   return p;
}

main()
{
  int a=4730;

  printf("A h�v�s el�tt:a=%d\n", a);

  *kozvetit(&a) += 13;

  printf("A h�v�s el�tt:a=%d\n", a);
}

