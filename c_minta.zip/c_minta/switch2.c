#include <stdio.h>

main()
{
  int num, fakt=1;

  printf("K�rek egy eg�sz sz�mot (0 - 7) : ");
  scanf("%d", &num);

  switch (num)
  {
    default:
       printf("Hib�s sz�m: %d\n", num);
       break;
    case 7:   fakt *=7;
    case 6:   fakt *=6;
    case 5:   fakt *=5;
    case 4:   fakt *=4;
    case 3:   fakt *=3;
    case 2:   fakt *=2;
    case 0:
    case 1:
	  printf("%d! = %d\n", num, fakt);
	  break;
  }
}

