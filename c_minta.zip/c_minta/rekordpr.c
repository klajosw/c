/* REKORDPR.C */
#include <string.h>
struct tanulo {
		char veznev[26];
		char knev[21];
		int kora;
		double magassaga;
		int jegyei[5];
	       } fiu;
main()
{
 strcpy(fiu.veznev,"Kiss");
 strcpy(fiu.knev,"Viktor");
 fiu.kora = 12;
 fiu.magassaga = 158.5;
 fiu.jegyei[1] = 5;
 fiu.jegyei[2] = 4;
}