/* GRAFIKA2.C */
#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>

void main()
{
 int   Gd, Gm, Hibakod;
 char  Utvonal[20];
   Gd = DETECT;
   clrscr();
   cputs("K�rem az �tvonalat: "); gets(Utvonal);
   initgraph(&Gd, &Gm, Utvonal);
   Hibakod = graphresult();
   if (Hibakod)
   {
     clrscr();
     cprintf("Grafikus hiba: %s ",
	      grapherrormsg(Hibakod));
     exit(1);
   }
   /* rajzol�s */
   rectangle(100,100,60,40);
   getch();
   closegraph();
}

