 #include <stdio.h>
 #include <conio.h>           //clrscr    (main)
 #include <string.h>          //strcmp    (datumbeall2)
 #include <dos.h>             //getdate   (datumbeall3)
 #include <time.h>            //time,localtime  (datumbeall4)
 #include <alloc.h>           //malloc          (main)
  main()
  {


 struct datum {
  int ho;
  int nap;
  void datumbeall(int a, int b) {
				  ho=a;
				  nap=b;
				 };

/*  void datumbeall2(char *d) {
		    if (strcmp(d,"karacsony")==0)  { dp->ho=12; dp->nap=25; }
		    if (*d=='h')                   { dp->ho=4;  dp->nap=12; }
		    if (strcmp(d,"szulinap")==0)   { dp->ho=5;  dp->nap=8; }
			    };

  void datumbeall3() 	{
		struct date *dat;
		getdate( dat);
		dp->ho=dat->da_mon;  dp->nap=dat->da_day;
		};
  void datumbeall4() 	{
		time_t t=time(NULL);
		struct tm* tmm;
		tmm=localtime(&t);
		dp->ho=(tmm->tm_mon)+1;  dp->nap=tmm->tm_mday;
		}  ;

  void datumkiir()	{
	 printf("Megegyszer:%d.%d",dp->ho,dp->nap);
	}          ;

  int datumkul(struct datum *dp1, struct datum *dp2)	{
	 printf("Megegyszer:%d.%d",dp->ho,dp->nap);
	};   */
  };              //struktura vege


  struct datum ma;
   ma.nap=26;
  ma.datumbeall=(3,26);

  }










