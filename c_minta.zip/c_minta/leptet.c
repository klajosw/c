#include <stdio.h>

main()
{
	int i,j,k;

	i=3; j=1; k=2;               /*  i  j  k  */
	k=i+++j;
	printf("%d %d %d\n",i,j,k);  /*  4  1  4  */

	i=3; j=1; k=2;
	k= ++i+j++;
	printf("%d %d %d\n",i,j,k);  /*  4  2  5  */

	i=3; j=1; k=2;
	k= --i-j--;
	printf("%d %d %d\n",i,j,k);  /*  2  0  1  */

	i=3; j=1; k=2;
	k= i---j;
	printf("%d %d %d\n",i,j,k);  /*  2  1  2  */

	i=3; j=1; k=2;
	k= -i+++j;
	printf("%d %d %d\n",i,j,k);  /*  4  1 -2  */

	i=3; j=1; k=2;
	k= ++i-j++;
	printf("%d %d %d\n",i,j,k);  /*  4  2  3  */

	i=3; j=1; k=2;
	k= +i+-j;
	printf("%d %d %d\n",i,j,k);  /*  3  1  2  */

	i=3; j=1; k=2;
	k= -i--+j;
	printf("%d %d %d\n",i,j,k);  /*  2  1 -2  */

	i=3; j=1; k=2;
	k= i--+--j;
	printf("%d %d %d\n",i,j,k);  /*  2  0  3  */

	i=3; j=1; k=2;
	k+=++i+--j;
	printf("%d %d %d\n",i,j,k);  /*  4  0  6  */

	i=3; j=1; k=2;
	k+=-i+++j;
	printf("%d %d %d\n",i,j,k);  /*  4  1  0  */
}

