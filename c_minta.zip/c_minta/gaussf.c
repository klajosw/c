/*  GAUSSF.C  */
/* f�elemkiv�laszt�ssal Gauss elimin�ci� */
#include <stdio.h>
#include <stdlib.h>
#include <alloc.h>
#include <math.h>
#include <float.h>
#define MAXNUM   10

typedef double tomb[MAXNUM+1][MAXNUM+2];

int gaussf(tomb a, int n);
void olvas(tomb a,int n);
void kiir(tomb a, int n);
void gyokkiir(tomb a, int n);

void main()
{
  tomb a;
  int n, hiba;
   _fpreset();
    printf("  Line�ris egyenletrendszer megold�sa\n");
    printf("    Gauss m�dszer: f�elemkiv�laszt�s\n\n");
    do
    {
       printf("Elemek szama [max.10]: "); scanf("%d",&n);
    }
    while (n > 10);
    olvas(a,n);
    printf("\nAz n+1 oszloppal kib�vitett m�trix\n\n");
    kiir(a,n);
    hiba = gaussf(a,n);
    if(hiba)
     {
       printf("Az egyenlet nem olhat� meg\n");
       exit(1);
     }
    else
     {
       printf("\nA m�dositott m�trix\n");
       kiir(a,n);
       gyokkiir(a,n);
     }
}

int gaussf(tomb a, int n)
{
  int i,j,k;
  double t, eps, max;
     eps = 0.000001;

     for(k = 1; k <= n; k++)
     {
       /* 2. betold�s  */
       max = 0.0; j = k;
       for (i = k;  i <= n; i++)
       {
	 if( fabs(a[i][k]) > max)
	 {
	    max = fabs(a[i][k]);
	    j = i;
	 }
       }
       if( j != k)
       {
	 /* Ha nem a f��tl�beli elem volt a legnagyobb */
	 /* az egyenleteket felcser�lj�k. */
	 for( i = k; i <= n+1; i++)
	 {
	   t = a[k][i];
	   a[k][i] = a[j][i];
	   a[j][i] = t;
	 }
       }

       t = a[k][k];
       if( fabs(t) > eps)
       {
	 printf("\nOszt: %d. oszlop max. elem�vel: %6.2lf\n\n",k,a[k][k]);
	 t = 1.0/t;
	 for( i = k; i <= n+1; i++)
	   a[k][i] = t*a[k][i];

	 if (k != n )
	 {
	 printf("%d. iter�ci�\n",k);
	   for( i = k+1; i <= n; i++)
	   {
	     t = a[i][k];
	     for(j = k; j <= n+1; j++)
	       a[i][j] = a[i][j] - a[k][j] * t;
	   }
	 }

	 kiir(a,n);
       }
       else return 1;
     }

     for(i = n; i >= 1; i--)
     {
	t = a[i][n+1];
	for( k = i+1; k <= n; k++)
	   t = t - a[i][k] * a[k][n+1];
	a[i][n+1] = t/a[i][i];
     }
  return 0;
}

void gyokkiir(tomb a, int n)
{
int i;
   printf("\nAz egyenlet gy�kei\n\n");
   for(i = 1; i <= n; i++)
     printf("x%d = %lf\n",i,a[i][n+1]);
}

void olvas(tomb a, int n)
{
 int i,j;
  printf("\n");
  for(i = 1; i <= n; i++)
  {
   for(j = 1; j <= n; j++)
   {
    printf("a[%d,%d] = ",i,j); scanf("%lf",&a[i][j]);
   }
    printf("Jobb oldal:\n");
    printf("b[%d] = ",i); scanf("%lf",&a[i][n+1]);
    printf("\n");
  }
}

void kiir(tomb a, int n)
{
 int i,j;
  if(n > 8)
  {
    for(i = 1; i <= n; i++)
    {
      for(j = 1; j <= n; j++)
      {
	printf("a[%d, %d] = %lf \n",i,j,a[i][j]);
      }
      printf("b[%d] = %lf\n",i,a[i][n+1]);
    }
  }
  else
  {
    for(i = 1; i <= n; i++)
    {
      for(j = 1; j <= n+1; j++)
      {
	printf("%6.2lf  ",a[i][j]);
      }
      printf("\n");
    }
  }
}

