/* FELT2.C */
#include <stdio.h>

main()
{
 int pont;
  printf("\n0 �s 100 k�z�tti pontok oszt�lyzata");
  printf("\nAz el�rt pontsz�m     : "); scanf("%d",&pont);
  printf("A dolgozat oszt�lyzata: ");
  if(pont == 0) printf("�rv�nytelen\n");
    else if (pont < 50) printf("el�gtelen\n");
    else if (pont < 60) printf("el�gs�ges\n");
    else if (pont < 70) printf("k�zepes\n");
    else if (pont < 89) printf("j�\n");
    else printf("jeles\n");
}
