/*  GAUSST.C  */
/* teljes f�elemkiv�lszt�ssal Gauss elimin�ci� */
#include <stdio.h>
#include <stdlib.h>
#include <alloc.h>
#include <math.h>
#include <float.h>
#define MAXNUM   10

typedef double tomb[MAXNUM+1][MAXNUM+2];
typedef double vekt[MAXNUM+1];
typedef int vekti[MAXNUM+1];

int gausst(tomb a, int n);
void olvas(tomb a,int n);
void kiir(tomb a, int n);
void gyokkiir(tomb a, int n);

void main()
{
  tomb a;
  int n, hiba;
   _fpreset();
    printf("  Line�ris egyenletrendszer megold�sa\n");
    printf("Gauss m�dszer: teljes f�elemkiv�laszt�s\n\n");
    do
    {
      printf("Elemek sz�ma [max.10]: "); scanf("%d",&n);
    }
    while ( n > 10);
    olvas(a,n);
    printf("\nAz n+1 oszloppal kib�vitett m�trix\n\n");
    kiir(a,n);
    hiba = gausst(a,n);
    if( hiba)
    {
       printf("\nAz egyenlet nem oldhat� meg\n");
       exit(1);
    }
    else
    {
       printf("\nAz m�dositott m�trix\n");
       kiir(a,n);
       gyokkiir(a,n);
    }
}

int gausst(tomb a, int n)
{
  int i,j,k,s,m;
  double t, eps, max, oszt;
  vekti sor;
  vekt x;
     eps = 0.000001;

     /* 1. betold�s */
     for(i = 1; i <= n; i++)
       sor[i] = i;

     /* egyenlet sorrendje azonos a sorindex-szel */
     for(k = 1; k <= n; k++)
     {

      /* 2. betold�s */
       max = 0.0; s = k; m = k;
       for(i = k; i <= n; i++)
	 for(j = k; j <= n; j++)
	  if( fabs(a[i][j]) > max)
	  {
	    oszt = a[i][j];
	    max = fabs(oszt);
	    s = i; m= j;
	  }

      if( s != k)
       {
	/* Ha nem a f��tl�beli elem a legnagyobb */
	 for( i = k; i <= n+1; i++)
	 {
	   t = a[k][i];
	   a[k][i] = a[s][i];
	   a[s][i] = t;
	 }
       }
       if (m != k)
       {
       /* Egyenletek sorrendj�nek vizsg�lata */
	 for( i = 1; i <= n; i++)
	 {
	   t = a[i][k];
	   a[i][k] = a[i][m];
	   a[i][m] = t;
	 }
	 i = sor[k];
	 sor[k] = sor[m];
	 sor[m] = i;
      }
       t = a[k][k];
       if( fabs(t) > eps)
       {
	 printf("\nOszt: [%d,%d] index� |max. elemmel|: %6.2lf\n\n",
		s,m,oszt);
	 t = 1.0/t;
	 for( i = k; i <= n+1; i++)
	   a[k][i] = t*a[k][i];

	 if (k != n )
	 {
	   printf("%d. iter�ci� \n",k);
	   for( i = k+1; i <= n; i++)
	   {
	     t = a[i][k];
	     for(j = k; j <= n+1; j++)
	       a[i][j] = a[i][j] - a[k][j] * t;
	   }
	 }
       kiir(a,n);
       }
       else return 1;
     }

     for(i = n; i >= 1; i--)
     {
	t = a[i][n+1];
	for( k = i+1; k <= n; k++)
	   t = t - a[i][k] * a[k][n+1];
	a[i][n+1] = t/a[i][i];
     }
    /* 3. betold�s */
    for(i = 1; i <= n; i++)
      x[sor[i]] = a[i][n+1];
    for( i = 1; i <= n; i++)
      a[i][n+1] = x[i];
  return 0;
}

void gyokkiir(tomb a, int n)
{
int i;
   printf("\nAz egyenlet gy�kei\n\n");
   for(i = 1; i <= n; i++)
     printf("x%d = %lf\n",i,a[i][n+1]);
}

void olvas(tomb a, int n)
{
 int i,j;
  printf("\n");
  for(i = 1; i <= n; i++)
  {
   for(j = 1; j <= n; j++)
   {
    printf("a[%d,%d] = ",i,j); scanf("%lf",&a[i][j]);
   }
    printf("Jobb oldal:\n");
    printf("b[%d] = ",i); scanf("%lf",&a[i][n+1]);
    printf("\n");
  }
}

void kiir(tomb a, int n)
{
 int i,j;
  if (n > 8)
  {
   for(i = 1; i <= n; i++)
   {
     for(j = 1; j <= n; j++)
     {
       printf("a[%d, %d] = %lf \n",i,j,a[i][j]);
     }
     printf("b[%d] = %lf\n",i,a[i][n+1]);
   }
  }
  else
  {
   for(i = 1; i <= n; i++)
   {
     for(j = 1; j <= n+1; j++)
     {
       printf("%6.2lf  ",a[i][j]);
     }
     printf("\n");
   }
  }
}