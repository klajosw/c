/* VAVEVI.C */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
int in(char);

void main()
{
char eredeti[255],uj[255],kar;
int i,j;
  printf("\nK�rek egy mondatot �kezetek n�lk�l!\n");
  gets(eredeti);
  j=-1;
  for(i=0; i<strlen(eredeti); i++)
  {
    j++;
    kar=toupper(eredeti[i]);
    uj[j]=kar;
    if( in(kar) )
		{
		  uj[++j]='V';
		  uj[++j]=kar;

		 }
   }
  uj[++j]='\0';
  printf("%s",uj);
 }
 int in(char c)
 {
 char s[5];
 int i;
      strcpy(s,"AEIOU");
      i=0;
      do
       {
	if(c == s[i]) return(1);
	i++;
	} while (i <= 4);
   return(0);
 }
