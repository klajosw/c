
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

main()
{
  int szam, tipp, lepes = 0;

  randomize();
  szam = rand() % 101;
  printf("Gondoltam egy sz�mot 0 �s 100 k�z�tt...\n");

  do {
     printf("Tipp: ");
     scanf("%d", &tipp);
     if (tipp == szam)
        printf("\nKital�lta, a gondolt sz�m %d !\n", szam);
     else if (tipp > szam)
        printf("..Nem tal�lt, t�l nagy!\n");
     else
        printf("..Nem tal�lt, t�l kicsi!\n");
     lepes++;
  } while (tipp != szam);

  printf("Gratul�lok, %d l�p�sben siker�lt!\n", lepes);
}

