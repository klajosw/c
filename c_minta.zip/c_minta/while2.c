
#include <stdio.h>
#define IGEN 1
#define NEM  0

main()
{
  int ch, sor, szo, szoban=NEM;
  long karakter;

  karakter = szo = sor = 0;
  /* karakterek olvas�sa a Ctlr+Z �s Enter lenyom�s�ig */
  while ((ch = getchar()) != EOF)
  {
     karakter++;
     switch (ch)
     {
       case '\n' :      /* �j sor karakter */
           sor++;
       case ' '  :      /* sz�elv�laszt� karakterek */
       case '\t' :
       case ','  :
          szoban = NEM;
          break;
       default:        /* sz�t alkot� karakterek */
          if (!szoban) {
             szoban = IGEN;
             szo++;
          }
          break;
     }
  }
  printf("Statisztika: %d sor, %d sz� %ld karakter\n",
          sor, szo, karakter);
}

