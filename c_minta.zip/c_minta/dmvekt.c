#include <stdio.h>
#include <stdlib.h>
#define NELEM1 50
#define NELEM2 100

main()
{
  double *pd1, *pd2;
  int i , j;

  /* Helyfoglal�s ellen�rz�ssel */
  pd1 = (double *) calloc(NELEM1 * NELEM2, sizeof(double));
  pd2 = (double *) calloc(NELEM1 * NELEM2, sizeof(double));

  if (!pd1 || !pd2) {
     printf("\a\nNincs el�g mem�ria!\n");
     return -1;
  }

  /* Az 1. m�trix felt�lt�se v�letlen sz�mokkal */
  for (i = 0; i < NELEM1; i++)
    for (j = 0; j < NELEM2; j++)
         pd1[ i*NELEM2 + j] = random(10000)*1.234;

  /* Az 1. m�trix 10-szeres�nek m�sol�sa a 2. m�trixba */
  for (i = 0; i < NELEM1; i++)
    for (j = 0; j < NELEM2; j++)
        pd2[ i*NELEM2 + j] = pd1[ i*NELEM2 + j] * 10.0;

  /* A lefoglalt ter�letek felszabad�t�sa */
  free(pd1);
  free(pd2);
}


