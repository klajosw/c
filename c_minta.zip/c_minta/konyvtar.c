#include<stdio.h>

void main()
{
	int k;
           
	 struct konyv
	 {
		 char   szerzo[40];
		 char   cim[40];
		 int    ev;
		 int ar;
	 };
	 struct konyv konyvtar[4];
	 for(k=0;k<=3;k++)
	 {
		 printf("adja meg a %d.konyv szerzojet\n",k);
		 scanf("%s",&konyvtar[k].szerzo);
		 printf("adja meg a %d.konyv cimet\n",k );
		 scanf("%s",konyvtar[k].cim);
		 printf("adja meg a %d.konyv evet\n",k);
		 scanf("%d",&konyvtar[k].ev);
		 printf("adja meg a %d.konyv arat\n",k);
		 scanf("%d",&konyvtar[k].ar);
	 }
	 for(k=0;k<=3;k++)
	 {
		 if(konyvtar[k].ev<=1990 && 1980<=konyvtar[k].ev)
		 {
			 printf("a %d.konyv 1980-1990 kozott irodott,szerzoje:%s\n",k,konyvtar[k].szerzo);
		 }
	 }
 }

