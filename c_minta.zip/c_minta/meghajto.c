/* MEGHAJTO.C */
#include <conio.h>
#include <graphics.h>
#include <string.h>
#include <stdlib.h>

void main()
{
  int  Gd,Gm,Hibakod;
  char *meghajtonev;
  char buff[80];
    Gd =DETECT;
    initgraph(&Gd,&Gm,"");
    Hibakod = graphresult();
    if (Hibakod)
    {
      clrscr();
      cprintf("Grafikus hiba: %s",grapherrormsg(Hibakod));
      exit(1);
    }
    meghajtonev = getdrivername();
    strcpy(buff,"Meghajt� neve: ");
    strcat(buff,meghajtonev);
    outtextxy(100,100,buff);
    getch();
    closegraph();
 }
