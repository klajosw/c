/*------------------------------------------------------*/
/*                      GRMOUSE.C                       */
/*						        */
/*       Eg�rkezel�s grafikus Turbo C programokb�l      */
/*       Bal gomb : pontot rajzol                       */
/*       Jobb gomb: kil�p                               */
/*------------------------------------------------------*/


#include <dos.h>
#include <graphics.h>

enum boolean { false, true };

typedef unsigned int word;

/* Az eg�r kurzor�nak defin�ci�ja (ny�l) */
struct graphcursor {
	 word screenmask[16], cursormask[16];
	 word hotx, hoty;
       } gcursor = {
	       {   0x1fff, 0x0fff, 0x07ff, 0x03ff,
		   0x01ff, 0x00ff, 0x007f, 0x003f,
		   0x001f, 0x003f, 0x01ff, 0x01ff,
		   0xe0ff, 0xf0ff, 0xf8ff, 0xf8ff
	       },
	       {   0x0000, 0x4000, 0x6000, 0x7000,
		   0x7800, 0x7c00, 0x7e00, 0x7f00,
		   0x7f80, 0x7c00, 0x4c00, 0x0600,
		   0x0600, 0x0300, 0x0300, 0x0000
		},
	       1, 1
	     };

/* Az eg�rkezel� f�ggv�nyek protot�pusa */
void cmouse(word *fnum, word *arg1, word *arg2, word *arg3);
enum boolean mouseinit(void);
void showcursor(void);
void hidecursor(void);
void mousepos(word *x, word *y, word *b);
void setmouse(word x, word y);
void mbuttom(void);
void mousegen(struct graphcursor *mask);

/*-----------------*/
/* A main f�ggv�ny */
/*-----------------*/
main()
{
 int gd=DETECT, gm;
 word mx, my, mb;

 initgraph(&gd, &gm, "");

/* Hercules k�rtya eset�n elv�gzend� l�p�s */
 if (gd==HERCMONO) *(char far *)MK_FP(0,0x0449)=6;

 /* Ha van eg�r */
 if (mouseinit()) {
   mousegen(&gcursor);  /* A kurzor be�ll�t�sa   */
   setmouse(0,0);       /* Az eg�r pozicion�l�sa */
   showcursor();        /* Az eg�s megjelen�t�se */

   do {
      /* Az eg�r poz�ci�j�nak �s a gombok �llapot�nak lek�rdez�se */
      mousepos(&mx, &my, &mb);

      /* Ha a bal gombot megnyomt�k */
      if (mb & 1) {
	 hidecursor(); /* Az eg�s elt�ntet�se */
	 putpixel(mx,my,WHITE);
	 showcursor();
      }
  }

  /* Ha a jobb gombot megnyomt�k */
  while (!(mb & 2));
  hidecursor();
 }
 closegraph();
 restorecrtmode();
}


/*---------------------*/
/* �ltal�nos eg�rh�v�s */
/*---------------------*/
void cmouse(word *fnum, word *arg1, word *arg2, word *arg3)
{
 struct REGPACK r;
 r.r_ax=*fnum;
 r.r_bx=*arg1;
 r.r_cx=*arg2;
 r.r_dx=*arg3;
 intr(0x33,&r);
 *fnum=r.r_ax;
 *arg1=r.r_bx;
 *arg2=r.r_cx;
 *arg3=r.r_dx;
}

/*------------------------*/
/* Az eg�r inicializ�l�sa */
/*------------------------*/
enum boolean mouseinit(void)
{
  word fnum=0, arg1, arg2, arg3;
  cmouse(&fnum, &arg1, &arg2,  &arg3);
  return fnum==0xffff ? true : false;
}

/*----------------------------*/
/* Az eg�rkurzor bekapcsol�sa */
/*----------------------------*/
void showcursor(void)
{
  word fnum=1, arg1, arg2, arg3;
  cmouse(&fnum, &arg1, &arg2,  &arg3);
}

/*----------------------------*/
/* Az eg�rkurzor kikapcsol�sa */
/*----------------------------*/
void hidecursor(void)
{
  word fnum=2, arg1, arg2, arg3;
  cmouse(&fnum, &arg1, &arg2,  &arg3);
}

/*----------------------------------------------------------*/
/* Az eg�r poz�ci�j�nak �s a gombok �llapot�nak lek�rdez�se */
/*----------------------------------------------------------*/
void mousepos(word *x, word *y, word *b)
{
  word fnum=3, arg1, arg2, arg3;
  cmouse(&fnum, &arg1, &arg2,  &arg3);
  *x=arg2; *y=arg3; *b=arg1;
}

/*---------------------------------*/
/* Az eg�r poz�ci�j�nak be�ll�t�sa */
/*---------------------------------*/
void setmouse(word x, word y)
{
 word fnum=4, arg1, arg2=x, arg3=y;
 cmouse(&fnum, &arg1, &arg2,  &arg3);
}

/*------------------------------*/
/* Az eg�r alakj�nak be�ll�t�sa */
/*------------------------------*/
void mousegen(struct graphcursor *mask)
{
 struct REGPACK r;
 r.r_ax=9;
 r.r_bx=mask->hotx;
 r.r_cx=mask->hoty;
 r.r_es= FP_SEG(mask);
 r.r_dx= FP_OFF(mask);
 intr(0x33, &r);
}



