/*-----------------------------------------------------------*/
/*                         BINTREE.C                         */
/*                                                           */
/* A program bin�ris fa seg�ts�g�vel sorba rendezi a bevitt  */
/* eg�sz sz�mokat                                            */
/*-----------------------------------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <alloc.h>
#include <process.h>

/* A csom�pontok t�pusa */
struct telem
   {
    struct telem   *bal;
    int    szam;
    struct telem   *jobb;
   };

struct telem     *szulo, *gyermek;
struct telem     *elso_elem;

/*------------------------------------*/
/* A glob�lis v�ltoz�k inicializ�l�sa */
/*------------------------------------*/
inicializalas(void)
{
   elso_elem = NULL;
   szulo     = NULL;
   gyermek   = NULL;
}

/*------------------------------------*/
/* �j elem l�trehoz�sa                */
/*------------------------------------*/
ujelem(int num)
{
   gyermek = (struct telem *) malloc(sizeof(struct telem));
   gyermek->szam = num;
   gyermek->bal   = NULL;
   gyermek->jobb  = NULL;
}

/*------------------------------------*/
/* Az �j elem be�p�t�se a f�ba        */
/*------------------------------------*/
kovetkezo_elem(struct telem *elem, int num)
{
  /* Ha els� elem */
  if (elso_elem == NULL)
     {
        ujelem(num);
	elso_elem = gyermek;
     }

  /* Az elem helye az num �rt�ke alapj�n ker�l kijel�l�sre */
  if (elem->szam > num)
     {
        if (elem->bal == NULL)
           {
              ujelem(num);
              elem->bal = gyermek;
           }
        else {
              elem = elem->bal;
	      kovetkezo_elem(elem, num);
             }
     }
     else if (elem->jobb == NULL)
              {
                 ujelem(num);
                 elem->jobb = gyermek;
              }
          else {
                 elem = elem->jobb;
		 kovetkezo_elem(elem, num);
               }
}

/*------------------------------------*/
/* A fa strukt�ra bej�r�sa            */
/*------------------------------------*/
bejar(struct telem *elem)
{
   struct telem     *b, *j;

   b = elem->bal;
   if (b != NULL) bejar(b);
   if (elem->szam != -1) printf("%d\n",elem->szam);
   j = elem->jobb;
   if (j != NULL) bejar(j);
}

/*------------------------------------*/
/* A main f�ggv�ny                    */
/*------------------------------------*/

main()
{
   int szam = 0;

   clrscr();
   inicializalas();
   while (szam != -1)
     {
       printf("K�rek egy eg�sz sz�mot (kil�p: -1) ");
       scanf("%d",&szam);
       kovetkezo_elem(elso_elem, szam);
      }

   printf("\n");
   printf("Az elemek rendezett list�ja:\n");
   bejar(elso_elem);
   printf("\n");
   printf("B�rmely billenty�re kil�p...");
   getch();
}

