#include <stdio.h>
typedef struct asd{ float v;
								 float k;
							 } komplex ;
void add(komplex, komplex,komplex*);        // pointerrel adja at a parametert
komplex kiv(komplex,komplex);               // return-nel adja at
void szor(komplex,komplex);                 // printf a fugvenyben
main()
{
int valaszt;
 komplex a,b,c;
 printf("\n\n\n\n\n\n\n\n              -----------KOMPLEX ALGEBRA-----------------\n");
 printf("\nElso operandus(a+jb): --valos:    ");      scanf("%f",&a.v);
 printf("                      --kepzetes: ");      scanf("%f",&a.k);
 printf("\nMasodik operandus(a+jb): --valos:    ");   scanf("%f",&b.v);  
 printf("                          --kepzetes: ");   scanf("%f",&b.k);
 printf("\n  1:osszeadas\n  2:kivonas\n  3:szorzas      melyiket valasztod? ");
 scanf("%d",&valaszt);
 switch(valaszt){
								 case 1: add(a,b,&c); printf(" (%.3f+j*%.3f) + (%.3f+j*%.3f) = %.3f+j*%.3f ",a.v,a.k,b.v,b.k,c.v,c.k);  break;
								 case 2:              printf(" (%.3f+j*%.3f) - (%.3f+j*%.3f) = %.3f+j*%.3f ",a.v,a.k,b.v,b.k,kiv(a,b).v,kiv(a,b).k);  break;
								 case 3: szor(a,b); break;
								 }   
}

void add(komplex a,komplex b,komplex *c)     
	{ c->v=a.v+b.v;    c->k=a.k+b.k;} 


komplex kiv(komplex a,komplex b)
	{  komplex c;
		 c.v=a.v-b.v;   c.k=a.k-b.k;
		 return c;
	}

void szor(komplex a,komplex b)
	{  komplex c;
			c.v=a.v*b.v-a.k*b.k;
			c.k=a.v*b.k+a.k*b.v;
		 printf(" (%.3f+j*%.3f) * (%.3f+j*%.3f) = %.3f+j*%.3f ",a.v,a.k,b.v,b.k,c.v,c.k); 
	 }