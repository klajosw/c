/* SOR.C */
#include <stdio.h>
#include <conio.h>
#include <math.h>
double szamol1(int);
double szamol2(int);
double szamol3(int);
double szamol4(int);

main()
{
int n;
double a1,a2,a3,a4;

  printf("Ciklus demostr�ci�\n");
  printf("n = "); scanf("%d",&n);
  a1=szamol1(n);
  a2=szamol2(n);
  a3=szamol3(n);
  a4=szamol4(n);
  printf("\nFutt�si eredm�nyek: \n");
  printf(" a1 = %lf\n a2 = %e\n a3 = %10.3lf\n a4 = %10.3e\n",a1,a2,a3,a4);
}

double szamol1(int n)
{
double h;
     h=0.;
     printf("\nDo while ciklussal\n");
     do
     {
       h=h+1./(double)n;
       printf(" n: %d  h: %lf\n",n,h);
       n--;
     }
     while ( n>0 );
    printf("Nyomj Enter-t!\n"); getch();
 return(h);
}

double szamol2(int n)
{
double h;
     h=0.;
     printf("\nWhile ciklussal\n");
     while (n >0 )
     {
       h=h+1./(double)n;
       printf(" n: %d  h: %f\n",n,h);
       n--;
     }
    printf("Nyomj Enter-t!\n"); getch();
 return(h);
}

double szamol3(int n)
{
double h;
int i;
     h=0.;
     printf("\nN�vekv� for ciklussal\n");
     for( i=1;i<=n; i++)
     {
       h=h+1./(double)i;
       printf(" n: %d  h: %lf\n",i,h);
     }
    printf("Nyomj Enter-t!\n"); getch();
 return(h);
}

double szamol4(int n)
{
double h;
int i;
     h=0.;
     printf("\nCs�kken� for ciklussal\n");
     for( i=n;i>=1; i--)
     {
       h=h+1./(double)i;
       printf(" n: %d  h: %lf\n",i,h);
     }
     printf("Nyomj Enter-t!\n"); getch();
 return(h);
}

