/* STAT.C */
/* Az adatokat file-b�l olvassa. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
typedef struct xx
		{
		  char szo[21];
		  int gyak;
		  struct xx *elozo, *kovetkezo;
		} szolanc;

int szobeolv( char szo[], FILE *bemenet);
void gyakorisag(FILE *bemenet);

main()
{
  FILE *t;
  char fnev[13];

  printf("File neve: "); scanf("%s",fnev);
  t = fopen(fnev,"r");
  if( t == NULL) { printf("Hib�s a file n�v!\n"); exit(1); }
  gyakorisag(t);
  fclose(t);
}

int szobeolv( char szo[], FILE *bemenet)
{
int ch;
int i;

   for ( i = 0; i < 21; szo[i++] = '\0')
   ;
   i = 0;
   ch = fgetc(bemenet);
   while(( ch != EOF) && isspace(ch))
   {
     ch = fgetc(bemenet);   /* a sz�k�z karakter lenyel�se */
   }
   while((ch != EOF) && isalpha(ch))
   {
     szo[i++] = ch;
     ch = fgetc(bemenet);
   }
   return i;
 }

 void gyakorisag(FILE *bemenet)
 {
 char     buffer[21];
 szolanc  *futo, *uj;
 szolanc  *gyoker;
 int      ok;
 int      c;

    gyoker = (szolanc*) malloc(sizeof(szolanc));
    gyoker->kovetkezo = NULL;
    gyoker->elozo     = NULL;
    gyoker->gyak      = 1;
    gyoker->szo[0]    = '\0';

    if (!szobeolv(gyoker->szo, bemenet))
    {
       free(gyoker);
       printf("Nem volt sz� az EOF-ig!\n");
       return;
    }

    while (szobeolv(buffer, bemenet))
    {
       futo = gyoker;
       ok   = 0;
       while (!ok)
       {
	  c = strcmp(buffer, futo->szo);
	  if (c < 0) c = -1;
	  if (c > 0) c = 1;

	  switch(c)
	  {
	    case -1: /* �j sz�, a megl�v�k k�z� f�zz�k */
		     uj = (szolanc*)malloc(sizeof(szolanc));

		     strcpy(uj->szo, buffer);
		     uj->gyak = 1;
		     uj->kovetkezo = futo;
		     uj->elozo = futo->elozo;
		     if( uj->elozo != NULL)
			 uj->elozo->kovetkezo = uj;

		     if(futo == gyoker) gyoker = uj;
		     ok = 1;
		     break;
	   case 0: /* egyezett egy megl�v� sz�val*/
		     futo->gyak++;
		     ok = 1;
		     break;
	   case 1: /* �j sz�, de a v�g�re kell f�zni */
		    if(futo->kovetkezo != NULL)
		     {
			futo = futo->kovetkezo;
		     }
		    else
		     {
			uj = (szolanc*)malloc(sizeof(szolanc));
			uj->kovetkezo = NULL;
			uj->elozo     = futo;

			futo->kovetkezo = uj;

			strcpy(uj->szo, buffer);
			uj->gyak = 1;
			ok = 1;
		      }
		    break;
	}
     }
  }

  futo = gyoker;
  while(futo != NULL)
  {
     printf("Sz�: %20s gyakoris�g: %5d\n",futo->szo, futo->gyak);
    futo = futo->kovetkezo;
  }
  while(futo != NULL)
  {
    if(futo->elozo != NULL) free(futo->elozo);
     futo = futo->kovetkezo;
  }
}
