/*  TOMB2.C  */
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
typedef int f_i[50];

int beolvas_int( f_i);
void kiir_int(int, f_i);

void valogat(int, f_i, int*, int*);
void rendez(int, f_i);

main()
{
int n;
f_i z;
int paros, paratlan;
    n=beolvas_int(z);
    printf("\nBeolvasott adatok\n");
    kiir_int(n,z);
    valogat(n,z,&paros,&paratlan);
    printf("\nP�ros elemek sz�ma   : %d\n",paros);
    printf("P�ratlan elemek sz�ma: %d\n",paratlan);
    printf("\nN�vekv� sorrenben val� rendez�s\n");
    rendez(n,z);
    printf("\nRendezett adatok\n");
    kiir_int(n,z);
}

int beolvas_int(f_i q)
{
int i,n;
    printf("\nAz elemek sz�ma : "); scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
      printf(" %d. elem : ",i); scanf("%d",&q[i]);
    }
    return(n);
}

void kiir_int(int m, f_i q)
{
int i;
     for(i=1; i<=m; i++)
      printf(" %d. elem : %d\n",i,q[i]);
}

void valogat(int m, f_i q, int *paros, int *paratlan)
{
int i;
    *paros = 0; *paratlan = 0;
    for(i=1; i<=m; i++)
     if ((q[i] % 2)*2 == 0)  *paros+=1;
		   else   *paratlan+=1;
}

void rendez(int n, f_i q)
{
int i,j,x;
      for(i=1; i<=n-1; i++)
	for(j=i; j<=n; j++)
	  if(q[i] > q[j]) {
			   x=q[j];
			   q[j]=q[i];
			   q[i]=x;
			  }
 }
