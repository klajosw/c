#include<stdio.h>
void main()
{
	int elemek[40];
	char a;
	int k,l,m,x,h,y;
	k=-1;

	{
		 k++;
		 printf("irjon be egy szamot\n");
		 scanf("%d\n",&h);
		 elemek[k]=h;
		 printf("akarja e folytatni\n");
		 scanf("%[in]",a);
		 
	}
		while(a!='i')
	for(l=0;l<=k;l++)
	{
		for(m=0;m<=l;m++)
		{
			if(elemek[m]<=elemek[l])
			{
				x=elemek[m];
				y=elemek[l];
				elemek[l]=x;
				elemek[m]=y;
			}
		}
	}
	for(l=0;l<=k;l++)
	{
		printf("ime az elemek csokkeno sorrendben:%d\n",elemek[l]);
	}
}
