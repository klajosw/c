/*  BEKA.C  */
#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>

void make_image(char *);
void neg_image(char *, char *, int, int);

void main(void)
{
   /* az automatikus vez�rl� �s m�d detekt�l�s k�r�se */
   int gdriver = DETECT, gmode, errorcode;

   char *psave,*pwork, *ppict, *ppictnff;
   long imsize;
   int xunit,yunit,xact,yact,xold,yold;

   /* grafikus m�d detekt�l�sa */
   detectgraph(&gdriver, &gmode);

   if (gdriver!=VGA && gdriver!=EGA)
   {
      printf("\nCsak EGA vagy VGA grafikus k�rty�val rendelkez�\n");
      printf("          sz�m�t�g�pen futtathat�\n");
      getch();
      exit(1);             /* kil�p�s hibak�ddal */
   }

   /* grafikus m�d inicializ�l�sa */
   initgraph(&gdriver, &gmode, "c:\\tc");

   /* az inicializ�ci� sikeress�g�nek ellen�rz�se */
   errorcode = graphresult();

   if (errorcode != grOk)  /* ha hiva volt */
   {
      printf("Graphics error: %s\n", grapherrormsg(errorcode));
      getch();
      exit(1);             /* kil�p�s hibak�ddal */
   }

   setbkcolor(BLACK);
   setcolor(YELLOW);

   /* A h�tt�r el��ll�t�sa */

   xunit=getmaxx()/10;
   yunit=getmaxy()/4;
   setfillstyle(SLASH_FILL,LIGHTRED);
   bar(xunit,yunit,3*xunit, 3*yunit);

   setfillstyle(LINE_FILL,WHITE);
   bar(4*xunit,yunit,6*xunit, 3*yunit);

   setfillstyle(BKSLASH_FILL,LIGHTMAGENTA);
   bar(7*xunit,yunit,9*xunit, 3*yunit);

   settextjustify(CENTER_TEXT,CENTER_TEXT);
   settextstyle(TRIPLEX_FONT,HORIZ_DIR,5);
   outtextxy(5*xunit,yunit/2,"Turbo C 2.0 animacio");

   /* Az anim�ci� el�k�sz�t�se */

   imsize=imagesize(0,0,50,50);
   psave = (char*)malloc(imsize);
   pwork = (char*)malloc(imsize);
   ppict = (char*)malloc(imsize);
   ppictnff=(char*)malloc(imsize);

   if (psave==NULL||pwork==NULL||ppict==NULL||ppictnff==NULL)
      {
       closegraph();
       putchar('07');
       exit(-1);
      }

   /* Az anim�ci�s rajz el��ll�t�sa */
   make_image(ppict);

   /* Az anim�ci�s rajz feket-feh�r negat�vj�nak el��ll�t�sa */
   neg_image(ppict, ppictnff,50,50);

   do {
       yact=getmaxy()/2;
       for (xact=50; xact<=getmaxx()-50; xact+=25)
       {
	  getimage(xact,yact,xact+50,yact+50,psave);

	  /* Az eredm�ny k�p el��ll�t�sa, ha a k�p a h�tt�r el�tt van */
	  setactivepage(1);
	  setvisualpage(0);
	  putimage(50,50,psave,COPY_PUT);
	  putimage(50,50,ppictnff,AND_PUT);
	  putimage(50,50,ppict,XOR_PUT);
	  getimage(50,50,100,100,pwork);
	  setactivepage(0);
	  setvisualpage(0);
	  putimage(xact,yact,pwork,COPY_PUT);

	  delay(300);
	  putimage(xact,yact,psave,COPY_PUT);
	  if (kbhit()) break;
       }

       for (xact=getmaxx()-50; xact>=50; xact-=25)
       {
	  getimage(xact,yact,xact+50,yact+50,psave);

	  /* Az eredm�ny k�p el��ll�t�sa, ha a k�p a h�tt�r m�g�tt van */
	  neg_image(psave, pwork,50,50);
	  setactivepage(1);
	  setvisualpage(0);
	  putimage(50,50,ppict,COPY_PUT);
	  putimage(50,50,pwork,AND_PUT);
	  putimage(50,50,psave,XOR_PUT);
	  getimage(50,50,100,100,pwork);
	  setactivepage(0);
	  setvisualpage(0);
	  putimage(xact,yact,pwork,COPY_PUT);

	  delay(200);
	  putimage(xact,yact,psave,COPY_PUT);
	  if (kbhit()) break;
       }
    } while (!kbhit());

   free(psave);
   free(pwork);
   free(ppict);
   free(ppictnff);
   getch();
   closegraph();
}


/**********************************************************/
/* A anim�ci�s  �bra el��ll�t�sa a nem l�that� lapon (1). */
/*       ( VGA eset�n ez a lap nem teljes!)               */
/**********************************************************/

void make_image(char *pptr)
{
   /* a poz�tiv k�p  a rajz sz�nes, az alap fekete */
   setactivepage(1);
   setvisualpage(0);
   setfillstyle(SOLID_FILL,BLACK);
   bar(50,50,100,100);

   setcolor(GREEN);
   setfillstyle(SOLID_FILL,GREEN);
   fillellipse(75,75,25,20);

   setcolor(LIGHTGREEN);
   setfillstyle(SOLID_FILL,LIGHTGREEN);
   fillellipse(60,60,10,10);
   fillellipse(90,60,10,10);

   setcolor(BLUE);
   setfillstyle(SOLID_FILL,BLUE);
   fillellipse(64,61,5,8);
   fillellipse(94,61,5,8);


   setcolor(YELLOW);
   setfillstyle(SOLID_FILL,YELLOW);
   fillellipse(75,83,16,8);

   setcolor(GREEN);
   setfillstyle(SOLID_FILL,GREEN);
   fillellipse(75,79,16,5);

   getimage(50,50,100,100,pptr);
   setactivepage(0);
   setvisualpage(0);
}


/***********************************************/
/* A anim�ci�s  �bra fekete-feh�r negat�vj�nak */
/*     el��ll�t�sa a nem l�that� lapon (1).    */
/*       VGA eset�n ez a lap nem teljes!       */
/***********************************************/

void neg_image(char *scrptr, char * negptr, int xsize, int ysize)
{
   int i,j;
   /* a fekete-feh�r negat�v k�p a rajz fekete, az alap feh�r */
   setactivepage(1);
   setvisualpage(0);
   putimage(50,50,scrptr,NOT_PUT);
   for(i=50;i<=50+xsize;i++)
    for(j=50;j<=50+ysize;j++)
      if (getpixel(i,j)!=WHITE) putpixel(i,j,BLACK);
   getimage(50,50,50+xsize,50+ysize,negptr);
   setactivepage(0);
   setvisualpage(0);
}
