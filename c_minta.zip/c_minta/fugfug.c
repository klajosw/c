#include <stdio.h>

typedef float sqr(float a);
sqr negyz;
float pitagorasz(sqr*,float,float);
main()
{
 float a,b,c;
 printf("a,b");
 scanf("%f",&a);
 scanf("%f",&b);
 c=pitagorasz(negyz,a,b);
 printf("c:%f",c);
}
float negyz(float a)
{  
	return(a*a);
}
float pitagorasz(sqr*fvp,float a,float b)
{
 float c;
 c=(*fvp)(a)+(*fvp)(b);
 return(c);
} 
