/* DALLAM.C */
#include <stdio.h>
#include <dos.h>

void main()
{
 int i;
 /* Boci boci tarka:
		     cd cd gg
		     cd cd gg
		     c'hagf a
		     gfed cc
*/
 int dal[]    = {262, 330, 262, 330, 392, 392,
		 262, 330, 262, 330, 392, 392,
		 523, 494, 440, 392, 349, 440,
		 392, 349, 330, 294, 262, 262};
 int ritmus[] = {250, 250, 250, 250, 600, 600,
		 250, 250, 250, 250, 600, 600,
		 250, 250, 240, 250, 600, 600,
		 250, 250, 250, 250, 600, 600};
   printf("Boci boci tarka dallama\n");
   for(i = 0; i<24; i++)
   {
     sound(dal[i]); delay(ritmus[i]); nosound();
   }
}