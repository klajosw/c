#include <stdio.h>
#include <math.h>
#define PI 3.141592654
main()
{
int s[6]={1,2,4,-2,4,4};
float val[6],kep[6];
int i,k;
	 for(i=0;i <= 5;i++)
	 { val[i]=kep[i]=0;  
		 for(k=0;k <= 5;++k)
			{ val[i] += (1/6.)*s[k]*cos(i*PI/3*k);         
				kep[i] += (-1.0/6)*s[k]*sin(i*PI/3*k); }
		 printf("\nS%d= %f + j* %f",i,val[i],kep[i]);
	 }
}