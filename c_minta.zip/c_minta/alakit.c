/* ALAKIT.C */
#include <stdio.h>
main()
{
 char ch;
 int  i;
   printf("ch = ");
   scanf("%c",&ch);
   i = (int)ch;
   printf("%c %d",ch, i);
}
