/* JEGY.C */
#include <stdio.h>

main()
{
 int jegy;
  printf("\nK�rem az �rdemjegyet: "); scanf("%d",&jegy);
  printf("A vizsga eredm�nye  : ");
  switch( jegy)
  {
    case 1: printf("el�gtelen\n"); break;
    case 2: printf("el�gs�ges\n"); break;
    case 3: printf("k�zepes\n"); break;
    case 4: printf("j�\n"); break;
    case 5: printf("jeles\n"); break;
    default: printf("Hib�s az �rdemjegy!\n");
  }
}
