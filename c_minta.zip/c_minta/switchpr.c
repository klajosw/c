/* SWITCHPR.C */
#include <stdio.h>

main()
{
 enum napok {hetfo, kedd, szerda,csutortok, pentek, szombat, vasarnap};
 enum napok ma;

  ma = vasarnap;

  switch (ma)
  {
    case hetfo:
    case kedd:
    case szerda:
    case csutortok:
    case pentek: printf("Dolgozni megyek.\n"); break;
    case szombat:
    case vasarnap:
		if (ma == szombat) puts("Moziba megyek.\n");
		    else
		       puts("Ha meleg van, napozni fogok!");
		break;
    default :puts("hibas adat"); break;
  }

}