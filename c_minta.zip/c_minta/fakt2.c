#include <stdio.h>

typedef unsigned long faktfv(int n);  /* a faktfv t�pus */


faktfv fakt;  /* protot�pus */

main()
{
 int i ;

 for (i=0; i<13; i++)
    printf("%d  \t  %lu\n",i, fakt(i));
}


faktfv fakt
{
 unsigned long f=1;

 for ( ; n > 0 ; n--) f*=n;
 return f;
}