
#include <stdio.h>

#define PROMPT ':'

main()
{
  double a,b,e;
  char op;

  putchar(PROMPT);               /* a k�szenl�ti jel */
  scanf("%lf%c%lf", &a, &op, &b);/* a beolvas�s      */

  switch (op)
  {
    case '+' :                   /* �sszead�s ?      */
       e = a + b;
       break;
    case '-' :                   /* kivon�s ?        */
       e = a - b;
       break;
    case '*' :                   /* szorz�s ?        */
       e = a * b;
       break;
    case '/' :                   /* oszt�s ?         */
       e = a / b;
       break;
    default:
       {
         printf("Hib�s m�velet!\n");
         return -1;             /* kil�p�s a programb�l */
       }
  } /* A switch utas�t�s v�ge */

  printf("%.2lf %c %.2lf = %.3lf\n",a,op,b,e);
}

