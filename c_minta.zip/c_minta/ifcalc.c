
#include <stdio.h>
#include <stdlib.h>
#define PROMPT ':'

main()
{
  double a,b,e;
  char op;
  putchar(PROMPT);               /* a k�szenl�ti jel */
  scanf("%lf%c%lf", &a, &op, &b);/* a beolvas�s      */

  if (op == '+')                 /* �sszead�s ?      */
       e = a + b;
  else if (op == '-')            /* kivon�s ?        */
       e = a - b;
  else if (op == '*')            /* szorz�s ?        */
       e = a * b;
  else if (op == '/')            /* oszt�s ?         */
       e = a / b;
  else                           /* hib�s m�velet!   */
       {
         printf("Hib�s m�velet!\n");
         exit(-1);               /* kil�p�s a programb�l */
       }
  printf("%.2lf %c %.2lf = %.3lf\n",a,op,b,e);
}

