#include <stdio.h>;
float h6vany(float,int);
float s(int);
float y(int);

main()
{
 int k,i;
 float a,b;
 printf("Hany utemig szamoljam? "); scanf("%d",&i);
 printf("  k   s[k]   gerjesztett valasz         rendszeregyenlet\n");
 printf("                 alapjan                    alapjan\n");
 printf("---------------------------------------------------------------\n");
 for(k=0; k<i; k++) 
	 { a= 142.18*h6vany(0.6,k-6)+32.92*h6vany(-0.631,k-6) ;
		 b= 0.0032*h6vany(-1.1,k-6)+0.034;
		 if (k==0)       {printf("  %d   %.3f        -0.9                      %.3f\n", k, s(k),            y(k));}
		 if (k==1)       {printf("  %d   %.3f        3.6188                    %.3f\n", k, s(k),            y(k));}
		 if (k==2)       {printf("  %d   %.3f        3.4789                    %.3f\n", k, s(k),            y(k));}
		 if (k==3)      {printf("  %d   %.3f        8.6835                    %.3f\n", k, s(k),             y(k));}
		 if (k==4)       {printf("  %d   %.3f        4.7816                    %.3f\n", k, s(k),            y(k));}
		 if (k==5)       {printf("  %d   %.3f        10.8                      %.3f\n", k, s(k),            y(k));}
		 if (k >=6)      {printf("  %d   %.3f        %.3f                      %.3f\n", k, s(k), a-b,       y(k));}
   }
}

float h6vany(float a,int b)
  {
    float c;
    int i;
    if (b==0) {c=1;} else { for (i=c=1; i<=b; i++, c*=a); }
    return(c);
  }

float s(int k)
  {
		if (k<6 && k>=0) { return (2-3*h6vany(-1.1,k));}
			 else        { return 0;}
	 }

float y(int k)
  {
    if (k<0) { return(0);}
			else { return(0.9*s(k)+1.16*s(k-1)+0.707*s(k-2)-0.032*y(k-1)+0.378*y(k-2)); }   
	}