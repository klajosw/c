/*  NEMLIN.C  */
#include <stdio.h>
#include <math.h>

typedef double dfunc(double x);
typedef dfunc  *dfptr;

double fg(double x);
double dfg(double x);

int Felezo(double a, double b,
	   double eps,
	   double *gyok,
	   dfptr  f);

int NewtonR(double x0,
	   double eps,
	   double *gyok,
	   dfptr  f,        /* f�ggv�ny      */
	   dfptr  df);      /* �s deriv�ltja */

int NewtonRH(double c,double d,
	   double eps,
	   double *gyok,
	   dfptr  f,        /* f�ggv�ny      */
	   dfptr  df);      /* �s deriv�ltja */

int Szelo(double a,double b,
	   double eps,
	   double *gyok,
	   dfptr  f);

int Hur(double a,double b,
	   double eps,
	   double *gyok,
	   dfptr  f);

dfunc   fg;   /* Az f(x) = 0 nemline�ris egyenlet  */
dfunc   dfg;  /* f'(x) deriv�ltf�ggv�ny            */

void menu(double a, double b, double eps);

void main()
{

  double a, b, eps;
  double x0;
  double *gyok = &x0;

  int k, ok;

  char *szoveg[]= {"Nemline�ris egyenlet megold�s�nak m�dszerei",
		   "Intervallum felez� m�dszer       ",
		   "Hur m�dszer                      ",
		   "Newton_Raphson m�dszer           ",
		   "Newton-Raphson �s a H�r m�dszer  ",
		   "Szel� m�dszer                    "
		  };

  printf("\nNemline�ris egyenlet megold�sa\n");
  printf("\nIntervallum eleje : "); scanf("%lf",&a);
  printf("Intervallum v�ge  : "); scanf("%lf",&b);
  printf("Hibakorl�t        : "); scanf("%lf",&eps);
  puts("\n\nM�dszerek:\n");
  puts("1: Intervallum felez�s");
  puts("2: Hur m�dszer");
  puts("3: Newton-Raphson m�dszer");
  puts("4: Newton-Raphson �s a H�r m�dszer egy�tt");
  puts("5: Szel� m�dszer ");
  do
  {
    printf("\nM�dszer sz�ma : "); scanf("%d",&k);
  }while (k < 0 || k > 5);
  *gyok = 0.0;
  switch(k)
  {
   case 1: ok = Felezo(a, b, eps, gyok, fg);        break;
   case 2: ok = Hur(a, b,eps, gyok,fg);             break;
   case 3: ok = NewtonR(b, eps, gyok, fg, dfg);     break;
   case 4: ok = NewtonRH(a, b, eps, gyok, fg, dfg); break;
   case 5: ok = Szelo(a, b, eps, gyok, fg);         break;

  }
  if(ok){
	  printf("\n%s",szoveg[k]);
	  printf("\nA nemline�ris egyenlet gy�ke : %lf\n",*gyok);
	 }
    else{
	  printf("A m�dszer nem alkalmazhat�!\n");
	}
}

double fg(double x)
{
   return (x*x*x+x-0.7);
}

double dfg(double x)
{
  return (3*x*x+1);
}

int Felezo(double a,     /* intervallum eleje     */
	   double b,     /* intervallum v�ge      */
	   double eps,   /* hibakorl�t            */
	   double *gyok, /* gy�k -> eredm�ny      */
	   dfptr f)      /* az f(x) f�ggv�ny cime */
{
    double fa, fb, x, fx;

    fa = (*f)(a); fb = (*f)(b);
    *gyok = 0.0;

    if (fa * fb > 0.0) return 0;
    fx = fabs(fa);
    while (fx > eps)
    {
      x = (a+b)/2;
      fx = (*f)(x);
      if (fx * fa > 0.0) { a = x; fa = fx; } else b = x;
      fx = fabs(fx);
   }
   *gyok = x;
   return 1;
}

int NewtonR(double x0,  /* intervallum eleje �s v�ge  */
	   double eps,  /* hibakorl                   */
	   double *gyok,/* gy�k -> eredm�ny           */
	   dfptr  f,    /* az f(x)  f�ggv�ny cime     */
	   dfptr  df)   /* az f'(x) f�ggv�ny cime     */
{
    double xe, nevezo;

    xe = x0;
    do
    {
	    nevezo = (*df)(xe);
	    if (fabs(nevezo) < 1e-6) return 0;
     	xe = xe - (*f)(xe)/nevezo;
    }
    while(eps < fabs((*f)(xe)));

    *gyok = xe;
    return 1;
}

int NewtonRH(double c,double d,   /* intervallum eleje �s v�ge  */
	     double eps,          /* hibakorl�t                 */
	     double *gyok,        /* gy�k -> eredm�ny           */
	     dfptr  f,            /* az f(x)  f�ggv�ny cime     */
	     dfptr  df)           /* az f'(x) f�ggv�ny cime     */
{
   double ce, de, fce, fde, fdce;
   *gyok = 0.0;

   if (((*f)(d)*(*f)(c)) < 0.0)
   {
     ce = c;
     de = d;
     do
     {
    	 fce = (*f)(ce);
	     fde = (*f)(de);
	     fdce = (*df)(ce);
	     if (fabs(fde-fce) < 1e-6) return 0;
	     if (fabs(fdce) < 1e-6) return 0;
	     de = de - fde*(de-ce)/(fde-fce);
	     ce = ce -fce/fdce;
     }
     while(eps < fabs(de-ce));
     *gyok = de;
     return 1;
  } else return 0;
}

int Szelo(double a, double b,   /* intervallum eleje �s v�ge  */
	  double eps,           /* hibakorl�t                 */
	  double *gyok,         /* gy�k -> eredm�ny           */
	  dfptr  f)             /* az f(x) f�ggv�ny cime      */
{
   double xe, xe1, xe2;
   *gyok = 0.0;

   if(((*f)(a)*(*f)(b)) < 0)
   {
     xe = a;
     xe1 = b;
     do
     {
	     xe2 = xe1 - (*f)(xe1)*(xe1-xe)/((*f)(xe1)-(*f)(xe));
	     xe = xe1;
	     xe1 = xe2;
     }
     while(eps < fabs((*f)(xe2)));
     *gyok = xe2;
     return 1;
  } else return 0;
}

int Hur(double a,double b, /* intervallum eleje �s v�ge  */
	   double eps,     /* hibakorl�t                 */
	   double *gyok,   /* gy�k -> eredm�ny           */
	   dfptr  f)       /* az f(x) f�ggv�ny cime      */

{
 double x0, x1, x2, y0, y1;
   *gyok = 0.0;
   x0 = a;
   x1 = b;
   if(((*f)(x1)*(*f)(x0)) < 0)
   {
     do
     {
	     y0 = (*f)(x0);
	     y1 = (*f)(x1);
	     x2 = x1 - y1*(x1-x0)/(y1-y0);
	     if ((*f)(x2)*y1 > 0) x1 = x2;
	     else x0 = x2;
     }
     while(eps < fabs((*f)(x2)));
     *gyok = x2;
     return 1;
  } else return 0;
}
