/* PALETTA.C */

#include <conio.h>
#include <graphics.h>
#include <time.h>
#include <stdlib.h>
#include <dos.h>

#define MAXI 400

void forgatas(struct palettetype * pal)
{
   int d,i;

   d=pal->colors[1];
   for (i=2; i<pal->size; i++)
     pal->colors[i-1]=pal->colors[i];
   pal->colors[15]=d;
}

void main()
{
    int gd, gm, color, sangl, eangl, ti, i;
    int maxx2, maxy2;
    struct palettetype  pal,oldpal;

    detectgraph(&gd,&gm);
    if (gd!=EGA && gd!=VGA)
       {
	cputs("\a\nCsak EGA, vagy VGA grafik�val rendelkez� g�pen futtathat�!\n");
	exit(1);
       }

    initgraph(&gd,&gm,"");
    maxx2=getmaxx()/2;
    maxy2=getmaxy()/2;

    getpalette(&pal);
    oldpal=pal;
    randomize();

    circle(maxx2, maxy2, maxx2/2);

    for (color=1; color<pal.size; color++)
    {
       sangl = 360/(pal.size-1)*color;
       eangl = 360/(pal.size-1)*(color+1);
       setfillstyle(SOLID_FILL,color);
       setcolor(color);
       pieslice(maxx2, maxy2, sangl, eangl, maxx2/2);
    }

    /* gyors�t�s */
    ti=MAXI;
    do {
     forgatas(&pal);
     delay(ti);
     setallpalette(&pal);
     ti-=5;
    } while (ti>=60);

    /* menet */
    i=0;
    for (i=0; i<200; i++)
    {
     forgatas(&pal);
     delay(ti);
     setallpalette(&pal);
    }

    /* lass�t�s */
    do {
     forgatas(&pal);
     delay(ti);
     setallpalette(&pal);
     ti+=5;
    } while (ti<=MAXI);

    setallpalette(&oldpal);

    getch();
    closegraph();
}

