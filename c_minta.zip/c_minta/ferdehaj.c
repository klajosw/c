/*  FERDEHAJ.C */
#include <stdio.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include <conio.h>
#include <graphics.h>
#include <dos.h>
#include <stdlib.h>
#define G 9.81
#define PI 3.141592

void main()
{
float tav,tavadott,szogfok,szog,seb,szaz,h,d,x,yd;
int gd,gm,tavd,i,y,k, yt, n;
char s[40],szoveg[40],c;
 do{
   textmode(C40);
   textbackground(CYAN);
   window(0,0,40,25);
   clrscr();
   textcolor(YELLOW);
   gotoxy(13,5);
   cprintf("Ferdehaj�t�s");
   gotoxy(13,6);
   gotoxy(13,6);
   cprintf("------------");
   textcolor(RED);
   do
   {
      gotoxy(5,8);  textcolor(RED);
      delline();
      cprintf("T�vols�g   [m] : "); textcolor(WHITE);clreol();
     gets(s); sscanf(s,"%f",&tavadott);
   } while (tavadott < 0 || tavadott == 0);
   textcolor(2);
   do
   {
      gotoxy(5,10); textcolor(RED);
      delline();
      cprintf("Sz�g     [fok] : "); textcolor(WHITE); clreol();
      gets(s); sscanf(s,"%f",&szogfok);
   } while (szogfok<0 || szogfok> 90);
   do
   {
      gotoxy(5,12); textcolor(RED);
      delline();
      cprintf("Sebess�g[m/sec]: "); textcolor(WHITE); clreol();
      gets(s); sscanf(s,"%f",&seb);
   } while (seb < 0);
  szog=szogfok*PI/180;
  tav=seb*seb*sin(2*szog)/G;
  szaz=100*tav/tavadott-100;
  if(registerbgidriver(EGAVGA_driver) < 0) exit(1);
  gd = EGA; gm = EGAHI;
  initgraph(&gd,&gm,"");
  setbkcolor(WHITE);
  setcolor(BLUE);
  outtextxy(200,5,"Ferde haj�t�s");
  setcolor(RED);
  sprintf(s,"%10.1f",tavadott);
  strcpy(szoveg,"T�vols�g");
  k=strlen(s);
  strncat(szoveg,s,k); strncat(szoveg," m",2);
  outtextxy(10,20,szoveg);
  setcolor(GREEN);
  sprintf(s,"%10.1f",tav);
  strcpy(szoveg,"Dob�s t�vols�ga:  ");
  strncat(szoveg,s,strlen(s));
  strncat(szoveg," m",2);
  outtextxy(202,30,szoveg);
  sprintf(s,"%10.1f",szogfok);
  strcpy(szoveg,"Sz�g:             ");
  strncat(szoveg,s,strlen(s));
  strncat(szoveg," fok",4);
  outtextxy(202,50,szoveg);

  sprintf(s,"%10.1f",seb);
  strcpy(szoveg,"Sebess�g:         ");
  strncat(szoveg,s,strlen(s));
  strncat(szoveg," m/s",4);
  outtextxy(202,70,szoveg);

  sprintf(s,"%10.1f",szaz);
  strcpy(szoveg,"T�vols�g elt�r�s: ");
  strncat(szoveg,s,strlen(s));
  strncat(szoveg," %",2);
  outtextxy(202,90,szoveg);
  setcolor(RED);
  outtextxy(202,110,"Ujradob�s: [SPACE], kil�p�s: [RETURN]");
  yt = 320;
  n  = 300;
  if (tavadott>tav)  d=tavadott/n;
		  else d=tav/n;
  h=seb*seb*sin(szog)*sin(szog)/(2*G);
  h=h/n;
  if (h>d) d=h;
  tavd=(int)(tav/d+0.5);
  setcolor(YELLOW);
  line(0,yt,tavd,yt);
  setcolor(RED);
  line(0,yt,(int)(tavadott/d+0.5),yt);
  for(i=0; i<=tavd; i++)
  {
      x=i*d;
      yd=x*x*G/(2*seb*seb*cos(szog)*cos(szog));
      y=(int)((x*sin(szog)/cos(szog)-yd)/d+0.5);
      putpixel(i,yt-y,BLUE);
      if( i<(tavd/2))  sound(i*50);
		    else sound((tavd-i)*50);
  }
  nosound();
  c=getch();
  closegraph();
 }
 while (c == ' ');
  textmode(C80);
}