/* TSRRUTIN.C */

#include <dos.h>
#include <stdlib.h>

#define TIMER 0x1c
#define KEYBOARD 0x9

#define ATTR 0x0f00

  extern unsigned _heaplen=1024; /* def 0= maximum */
  extern unsigned _stklen =512;  /* def 4K */
  int on=1;
  unsigned int (far *screen)[80];
  int count;
  unsigned char kbdcode,x,y;

void interrupt (*oldtimer)(void);
void interrupt (*oldkeyboard)(void);

void interrupt timer(void)
{
  screen=MK_FP(0xb800,0);
  if (on)
  {
     count=++count % 10;
     screen[0][79]=count+'0'+ATTR;
     if (!count)
      {
	x=random(80);
	y=random(25);
	screen[y][x]=screen[y][x] ^ 0xff00;
      }
  }
  oldtimer();
}

void interrupt keyboard(void)
{
  kbdcode=inportb(0x60);
  if (kbdcode==1)
     {
      on=!on;

      kbdcode=inportb(0x61);
      outportb(0x61,kbdcode | 0x80);
      outportb(0x61,kbdcode);

      outportb(0x20,0x20);
     }
   else
     oldkeyboard();
}

int main()
{

  oldtimer   = getvect(TIMER);
  oldkeyboard= getvect(KEYBOARD);

  setvect(TIMER,timer);
  setvect(KEYBOARD,keyboard);

  keep(0,_SS+((_SP+100)/16) - _psp);
}



