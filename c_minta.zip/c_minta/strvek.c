#include <stdio.h>

char *Desc[] ={ "Cogito",
		 "ergo",
		 "sum.",
		  NULL };

void wsprint1(char **p)
{
  while (*p)
	printf("%s ",*p++);
  printf("\n");
}

void wsprint2(char *p[])
{
  int i=0;
  while (p[i])
	printf("%s ",p[i++]);
  printf("\n");
}

main()
{
  wsprint1(Desc);
  wsprint2(Desc);
}


