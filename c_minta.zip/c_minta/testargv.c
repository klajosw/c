  /*-------------------------------------------------------------*
			      TESTARGV.C

    A _setargv f�ggv�ny haszn�lat�t bemutat� program.

    Haszn�lata:

    TESTARGV ELSO *.*

    A ford�t�shoz a TESTARGV.PRJ (project) file, vagy a tcc
    parancssora haszn�lhat�:

    tcc -mX -c -Ic:\tc\include setargv.c
    tcc -mX -c -Ic:\tc\include testargv.c
    tlink -Lc:\tc\lib c0X testargv setargv, testargv,, emu mathX cX

    Ahol X a haszn�lni k�v�nt mem�riamodell (s, m, c, l, h)
    bet�jele.

   *-------------------------------------------------------------*/


#include <stdio.h>

main(int argc, char **argv)
{
  do
  {
    printf("%d  %s\n", argc,argv[--argc]);
  } while (argc > 0);
}
