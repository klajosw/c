#include <stdio.h>
main()
{
printf("\n  Hello\n");
}