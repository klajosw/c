 /* HARDERR.C - harderr p�lda */

 #include <stdio.h>
 #include <conio.h>
 #include <dos.h>

 #define IGNORE  0
 #define RETRY   1
 #define ABORT   2

 int count=0;

 /* A lehetseges lemezhibak */
 static char *err_msg[] = {
     "write protect",
     "unknown unit",
     "drive not ready",
     "unknown command",
     "data error (CRC)",
     "bad request",
     "seek error",
     "unknown media type",
     "sector not found",
     "printer out of paper",
     "write fault",
     "read fault",
     "general failure",
     "reserved",
     "reserved",
     "invalid disk change"
 };

 /* Sajat kommunikacio a felhasznaloval hiba eseten */
 error_win(char *msg)
 {
    int retval;
    cputs(msg);

    while(1)
    {
	retval= getch();
	if (retval == 'a' || retval == 'A')
	 {  retval = ABORT;
	    break;
	 }
	if (retval == 'r' || retval == 'R')
	 { retval = RETRY;
	   break;
	 }
	if (retval == 'i' || retval == 'I')
	 { retval = IGNORE;
	   break; 	}
    }

    return(retval);
 }

 /* a kritikus hibat lekezelo fuggveny */

 int handler(int errval,int ax,int bp,int si)
 {
    static char msg[80];
    unsigned di;
    int drive;
    int errorno;

    di= _DI;
    if (ax < 0)
    {
       /* ha device hiba */
       error_win("Device hiba");
       hardretn(ABORT);
    }
 /* lemezhiba */
    drive   = ax & 0x00FF;
    errorno = di & 0x00FF;
    count++;
    cprintf("\r\nHiba %d: \"%s\" az %c meghajtoban\r\nA)bort, R)etry, I)gnore: ",
	    count,err_msg[errorno], 'A' + drive);
    if (count>3)
      {
       cprintf("\r\nTalan majd maskor ...\n");
       hardresume(ABORT);
      }
   else hardresume(error_win(msg));
    return ABORT;
 }

 main()
 {
    harderr(handler);
    clrscr();
    printf("Nezze meg, hogy van-e lemez az A: meghajtoban\n");
    printf("ha van, akkor nyomjon meg egy gombot ....\n");
    getch();
    printf("Probalkozas az A: meghajto olvasasara\n");
    printf("\n\nAz fopen visszateresi erteke:  %p\n",fopen("A:temp.dat", "w"));
 }

