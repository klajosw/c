/* konstansok */
#define DB2FILE         2
#define DB3FILE         3
#define DB3WITHMEMO     0x83
#define FIELD_REC_LEN   32      /* a mezoleiro rekord hossza   */
#define HEADER_PROLOG   32      /* a header hossza a mezoleiro nelkul */
#define MAX_HEADER      4129    /* max. dBase III header hossz */
#define MAX_RECORD      4000    /* dBase III max. rekordszam   */
#define MAX_FIELDS      128     /* dBase III max. mezoszam     */
#define MAX_MEMO_BYTES  512     /* dBase III memo mezo  merete */

#define MAXPATH         80

/* hibakodok */
#define OUT_OF_MEM      8       /* Nincs eleg memoria  */
#define NO_FILE         2       /* Nincs meg a file    */
#define BAD_FORMAT      11      /* Nem dBASE III file  */
#define RECNO_TOO_BIG   105     /* Tul nagy rekordszam */

typedef unsigned char UCHAR;

/* a mezok eleresehez hasznalt  struktura */
struct  FIELD_RECORD
{                                                                                               /* with a fread.        do not change. */
  char name[11];        /* a mezo neve */
  char typ;             /* a mezo tipusa */
  char *field_data_address;     /* a mezo cime a rekordon belul */
  #if defined(__TINY__) || defined(__SMALL__) || defined (__MEDIUM__)
    int space_holder;   /* a field_data_address 32 bites kell legyen */
  #endif
  UCHAR len;            /* a mezo hossza */
  UCHAR dec;            /* a dec. jegyek szama */
  UCHAR reserved_bytes[14];     /* dbase altal hasznalt */
};

/* struktura a dBASE file eleresehez */
struct  DBF
{
  char filename[MAXPATH];       /* dos filen-nev */
  FILE *file_ptr;               /* c file pointer */
  unsigned long int current_record; /* akt. rekord a memoriaban */
  enum                                                                          /* status of file */
   {
        not_open=0,
        not_updated,
        updated
   } status;
  UCHAR num_fields;             /* mezok szama */

  UCHAR dbf_version;            /* verzio karakter */
  UCHAR update_yr;              /* az utolso iras eve (-1900) */
  UCHAR update_mo;              /* az utolso iras hava */
  UCHAR update_day;             /* az utolso iras napja */
  unsigned long int records;    /* rekordok szama */
  unsigned int  header_length;  /* a header struktura hossza */
  unsigned int  record_length;  /* a rekord hossza */

  struct FIELD_RECORD *fields_ptr; /* mutato a mezotombre */
  char *record_ptr;             /* az akt. rekordra mutato pointer */
};


/* fuggvenyek a DBF.C file-ban */

int d_addrec(struct DBF *d);
int d_blank(struct DBF *d);
int d_close(struct DBF *d);
int d_cpystr(struct DBF *s,struct DBF *d);
char d_getfld(struct DBF *d,int f,char *buff);
int d_getrec(struct DBF *d,unsigned long int r);
int d_open(struct DBF *d);
int d_putfld(struct DBF *d,int f,char *buff);
int d_putrec(struct DBF *d,unsigned long int r);

