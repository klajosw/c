/* FELT1.C */
#include <stdio.h>

main()
{
 double t;
  printf("\nA viz halmaz�llapot�nak vizsg�lata\n");
  printf("H�m�rs�klete   : ");
  scanf("%lf",&t);
  printf("Halmaz�llapota : ");
  if (t > 0)
   {
     if( t >= 100) printf("g�z");
       else  printf("viz");
   }
  else  printf("j�g");
}
