/* PELDA2.C */
#include <stdio.h>
#include <string.h>
main()
{
int   a,b,c;
float r;
char  ch, nev[20];

  a= 2; b= 11; c= -2;
  c= a+b;
  r= 26.5;
  strcpy(nev,"Zoltan");
  ch= 'i';
  printf("C p�ld�k:\n");
  printf("\n");
  printf("Mi a \"kutya\" neve?\n");
  printf("\'Bodri\' mondta Laci.\n");
  printf("%d + %d = %d\n",a,b,c);
  printf("Mennyi a sulya: %6.2f kg\n",r);
  printf("Mi a neved: %s\n",nev);
  printf("Valasz (i/n): %c\n",ch);
  printf("a = %2d\n",a);
  printf("a * a = %2d\n",a*a);
}