#include <stdio.h>

void cserel(int *, int *);      /* a protot�pus */

main()
{
  int x=7, y=30;

  printf("A h�v�s el�tt:\t x=%d  y=%d\n", x, y);

  cserel( &x, &y );            /* a f�ggv�nyh�v�s */

  printf("A h�v�s ut�n :\t x=%d  y=%d\n", x, y);

}

/* A csere f�ggv�ny defin�ci�ja */
void cserel ( int * p, int *q )
{
   int sv;

   sv = *p;
   *p = *q;
   *q = sv;
}
