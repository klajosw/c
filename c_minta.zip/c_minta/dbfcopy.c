/********************************************************************
**  dBASE file strukturajanak es tartalmanak masolasa masik file-ba
**
**  Hasznalata:  DBFCOPY forrasfile celfile
********************************************************************/

#include <stdio.h>
#include <alloc.h>
#include <string.h>
#include <stdlib.h>
#include "dbf.c"

void db_error(int errornum,char *filename)
{
        printf("File nyitasi hiba: ");
        switch (errornum)
        {
                case OUT_OF_MEM:
                        printf("Nincs eleg memoria\n");
                        break;
                case NO_FILE:
                        printf("A %s file nem talalhato.\n",filename);
                        break;
                case BAD_FORMAT:
                        printf("A %s file nem DBF file.\n",filename);
                        break;
        }
}

void main(int argc,char *argv[])
{
        struct DBF in,out;
        int errornum,fld;
        unsigned long rec;
        char *buff;

        if(argc < 2)
                {
                printf("Hasznalata:  DBFCOPY forrasfile celfile\n");
                exit(1);
                }

/* a forrasfile megnyitasa */

        strcpy(in.filename,argv[1]);
        if(!strchr(in.filename,'.'))  strcat(in.filename,".DBF");
        if((errornum = d_open(&in))!=0)
        {
                db_error(errornum,in.filename);
                exit(1);
        }

/* az file struktura masolasa */

        strcpy(out.filename,argv[2]);
        if(!strchr(out.filename,'.'))  strcat(out.filename,".DBF");
        if((errornum = d_cpystr(&in,&out))!=0)
        {
                db_error(errornum,out.filename);
                exit(1);
        }

/* rekordok masolasa */
        if ((buff=(char *)malloc(MAX_RECORD))==NULL)
                        {
                        db_error(OUT_OF_MEM,"file-nev hiba");
                        exit(1);
                        }

        for (rec=1L;rec <= in.records;rec++)
                {
                d_getrec(&in,rec);

/* mezok masolasa */
                for (fld=1;fld <= in.num_fields;fld++)
                        {
                        d_getfld(&in,fld,buff);
                        d_putfld(&out,fld,buff);
                        }

/* a torolt jelzo byte masolasa */
                *out.record_ptr = *in.record_ptr;
                d_addrec(&out);
               }
        free(buff);
        d_close(&in);
        d_close(&out);
}

