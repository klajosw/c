/*  CONIO3.C  */
#include <conio.h>
#include <dos.h>

void main()
{
   /* teljes k�perny� ablaka */
   textbackground(LIGHTGRAY);
   clrscr();

   /* els� ablak */
   window(10,10,20,15);
   textbackground(CYAN);
   clrscr();
   textcolor(RED); gotoxy(1,1);
   cputs("1. Sor ");
   delay(2000);
   gotoxy(1,2);
   cputs("2. Sor ");
   delay(2000);
   gotoxy(1,3);
   cputs("3. Sor ");
   delay(2000);
   gotoxy(1,1);
   textcolor(YELLOW+BLINK);
   cputs("Fel�l�r ");
   delay(2000);

   /* m�sodik ablak */
   textcolor(BLACK);
   window(15,20,35,22);
   textbackground(GREEN);
   clrscr();
   gotoxy(5,2);
   cputs("Nyomj Sz�k�zt!");
   getch();
   /* az �r�s sz�n�nek vissza�ll�t�sa */
   textcolor(LIGHTGRAY);
   /* a h�tt�r sz�n�nek vissza�ll�t�sa */
   textbackground(BLACK);
   window(1,1,80,25);
   clrscr();
}