#include "stdio.h"
#include "string.h"


#define BAL_MARGO   10
#define JOBB_MARGO  70
#define HOSSZ       (JOBB_MARGO-BAL_MARGO)
#define KOZEPRE(s)  printf("%*c%s\n", \
			   BAL_MARGO + \
			   ((HOSSZ-strlen(s)) / 2),' ',s);
main()
{
 char *s = "K�z�pen van! 10 - 70";
 KOZEPRE(s)
 KOZEPRE("Ez is!")
}
