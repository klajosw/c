/*--------------------------------------------------------*/
/*                       MOVE.C                           */
/*							  */
/*     File-ok mozgat�sa egyik alk�nyvt�rb�l m�sikba      */
/*   A * �s ? karakterek is haszn�lhat� a file-n�vben     */
/*--------------------------------------------------------*/

#include <stdio.h>
#include <dir.h>
#include <string.h>
#include <io.h>
#include <conio.h>


char    newpath[MAXPATH], pathname[MAXPATH],
	newname[MAXPATH], oldname[MAXPATH];

char    drive[MAXDRIVE], subdir[MAXDIR], file[MAXFILE], ext[MAXEXT];

char    helpname[MAXPATH], sourcename[MAXPATH];

struct ffblk dta;

int main(int argc,char *argv[])
{
    int len, done, count=0, wassubdir=1, loop, gavename=0, star=0;

    /* A program ind�t�si sor�nak ellen�rz�se */
    if(argc != 3) {
	printf("\nHaszn�lat:   move path]file(s).ext path[file.ext");
	return(1);
    }
    strcpy(sourcename,argv[1]);
    strcpy(newpath,argv[2]);    /* a c�l alk�nyvt�r */
    strcpy(subdir,argv[2]);
    strcpy(helpname,argv[2]);
    len = strlen(newpath);      /* a c�l �tvonal hossza */

    if(newpath[len-1] == 92)    /* Van-e backslash jal a c�l �tvonal megad�s�sban?*/
      {
       wassubdir=0;             /* A c�l alk�nyvt�r */
       if (len>1)
	  subdir[len-1] = 0;    /* A '\' leszed�se */
      }
      else
       {
	newpath[len] = 92;      /* A  '\' hozz�ad�sa */
	newpath[len+1] = 0;
       }
    getcwd(newname,MAXPATH);    /* Az aktu�lis k�nyvt�r elment�se */


    /* File �tnevez�se a MOVE seg�ts�g�vel */
    if (chdir(subdir) * wassubdir)  {
       fnsplit(helpname,drive,subdir,file,ext);
       gavename=1;
       newpath[len]=0;         /* A '\' leszed�se*/
       strcat(file,ext);
       len=strlen(subdir);
       subdir[len-1]=0;
       wassubdir=0;            /* nem alk�nyvt�r */

       /* �tnevez�skor nem haszn�lhat� a * �s a ? */
       for (loop=0;sourcename[loop]!=0;loop++)
       {
	   if ((sourcename[loop]=='*') || (sourcename[loop]=='?'))
	   star++;
       }

       for (loop=0;file[loop]!=0;loop++)
       {
	   if ((file[loop]=='*') || (file[loop]=='?'))
	   star++;
       }

       if (star)
       {
	       printf("A ? vagy * nem haszn�lhat� �tnevez�skor! ");
	       return 11;
       }
    }

    chdir(newname);

    /* A c�lk�nyvt�r l�tez�se�nek ellen�rz�se */
    if(chdir(subdir) * wassubdir)
      {
       printf("Nem tudja a %s k�nyvt�rat bev�ltani ... kil�p�s",subdir);
       return 1;
      }

    chdir(newname);                         /* Vissza a home k�nyvt�rba */
    fnsplit(argv[1],drive,subdir,file,ext); /* A forr�s file nev�nek tagol�sa */
    sprintf(pathname,"%s%s",drive,subdir);  /* A forr�s file el�r�si �tvonala */
    done = findfirst(argv[1],&dta,47);      /* Az els� file megkeres�se */

/* Amig van a felt�telnek megfelel� file */
while(!done){
    strcpy(oldname,pathname);      /* Honnam mozgat */
    strcat(oldname,dta.ff_name);
    strupr(oldname);
    strcpy(newname,newpath);      /* Hova mozgat */

    /* Igazi mozgat�s */
    if (!gavename)
    {
	strcat(newname,dta.ff_name);
    }
    strupr(newname);

    /* Pr�b�koz�s �tnevez�ssel */
    if(rename(oldname,newname)==0)
      {                              /* Ha siker�lt, ... */
	count++;
	printf("%-s �tmozgatva a %s file-ba\n",oldname,newname);
	done=findnext(&dta);         /* K�vetkez� file */
	continue;
      }

/* Ha nem megy az �tnevez�s :*/
   printf("A %s file l�tezik, k�v�nja-e fel�l�rni (i/n)",newname);
   len = getche();
   putchar('\n');
   if(len=='i' || len=='I')
     {
      if(_chmod(newname,1,0))        /* A r/w el�r�s be�ll�t�sa */
	 printf("Hiba l�pett fel a %s file el�r�si m�dj�nk �t�ll�t�sakor!", newname);
        else
          if(remove(newname))
	     printf("T�rl�si hiba %s.\n",newname);
            else
	     continue;             /* T�rl�s ut�n �jra �tnevez�ssel pr�b�lkozunk.*/
     }
   done=findnext(&dta);            /* A k�vetkez� file */
}

   if(count>0)                     /* Statisztika ki�r�sa */
      printf("\nAz �tmozgatott file-ok sz�ma: %3d\n",count);
    else
      printf("Egyetlen file-t sem mozgatott.\n");
}
