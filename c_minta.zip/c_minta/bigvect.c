#include <stdio.h>
#include <alloc.h>

#define  NELEM 50000
#define  KCORELEFT (farcoreleft() / 1024)
main()
{
    long huge * ht;
    long index;

    printf("A legnagyobb blokk m�rete:%luK\n", KCORELEFT);

    ht = (long huge *) farcalloc(NELEM, sizeof(long));
    if (!ht) {
       printf("\aNincs elgend� mem�ria!\n");
       return -1;
    }
    printf("A foglal�s ut�n: %luK\n", KCORELEFT);

    for (index=0; index<NELEM; index++)
	ht[index]=index;

    farfree(ht);
    printf("A felszabad�t�s ut�n: %luK\n", KCORELEFT);

}