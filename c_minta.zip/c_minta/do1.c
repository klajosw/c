
#include <stdio.h>
main()
{
  long sum = 0;
  int  n   = 1994;

  printf("Az els� %d eg�sz ", n);
  do {
     sum += n;
     n--;
  } while (n>0);
  printf("�sszege: %ld\n", sum);
}

