
#include <stdio.h>
#include <stdlib.h>
#define NELEM1 50
#define NELEM2 100

typedef double matrix [NELEM1] [NELEM2];

main()
{
  matrix *pm1, *pm2;
  int i , j;

  /* Helyfoglal�s ellen�rz�ssel */
  pm1 = (matrix *) calloc( 1 , sizeof(matrix));
  pm2 = (matrix *) calloc( 1 , sizeof(matrix));
  if (!pm1 || !pm2) {
     printf("\a\nNincs el�g mem�ria!\n");
     return -1;
  }

  /* Az 1. m�trix felt�lt�se v�letlen sz�mokkal */
  for (i = 0; i < NELEM1; i++)
    for (j = 0; j < NELEM2; j++)
        (*pm1)[i][j] = random(10000)*1.234;

  /* Az 1. m�trix 10-szeres�nek m�sol�sa a 2. m�trixba */
  for (i = 0; i < NELEM1; i++)
    for (j = 0; j < NELEM2; j++)
        (*pm2)[i][j] = (*pm1)[i][j] * 10.0;

  /* A lefoglalt ter�letek felszabad�t�sa */
  free(pm1);
  free(pm2);
}


