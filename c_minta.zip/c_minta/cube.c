/* CUBE.C */
#include <stdio.h>
double DCube(double x);
long LCube(long x);
int ICube(int x);

main()
{
double k;
long   j;
int    i;
  i = 2;
  j = 5;
  k = 6.0;
  printf("%6d^3 = %6d\n",i,ICube(i));
  printf("%6ld^3 = %6ld\n",j,LCube(j));
  printf("%6.1lf^3 = %6.1lf\n",k,DCube(k));
}

double DCube(double x)
{
double y;
  y = x*x*x;
  return y;
}

long LCube(long x)
{
long y;
  y = x*x*x;
  return y;
}

int ICube(int x)
{
int y;
  y = x*x*x;
  return y;
}
