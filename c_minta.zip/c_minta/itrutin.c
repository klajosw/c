  /*-------------------------------------------------------------*
			      ITRUTIN.C

     A p�ldaprogram bemutatja, hogyan lehet fut� C programhoz
     hozz�rendelni egy megszak�t�st, �s kil�p�skor hogyan kell
     felszabad�tani azt kil�p�si f�ggv�ny defini�l�s�val.

     A programb�l a <Shift><PrtSc> illetve a <Print Screen> gomb
     megnyom�s�val lehet kil�pni.

   !      A ford�t�skor a SMALL modell haszn�lata javasolt       !
   *-------------------------------------------------------------*/

  #include <stdio.h>
  #include <dos.h>
  #include <conio.h>
  #include <stdlib.h>


  #define IT 5

  typedef void interrupt (*itfunc)();

  /* Mutat� a r�gi IT-vektor elt�rol�s�ra */
  itfunc oldfunc;
  int WAIT = 1;

  /*--------------------------------------------------------------------
   * Az �j megszak�t�s rutin
   *-------------------------------------------------------------------*/
  void interrupt it_proc()
   {
	 cprintf("A <Shift><PrtSc> / <Print Screen> gombot megnyomt�k\n\r");
	 WAIT = 0;
  }

  /*--------------------------------------------------------------------
   * A r�gi megszak�t�svektor kiment�se �s az �j be�ll�t�sa
   *------------------------------------------------------------------*/
  void install_it(itfunc func, int itnum)
  {
       oldfunc  = getvect(itnum);
       setvect(itnum,func);
  }

  /*--------------------------------------------------------------------
   * Kil�p�si rutin
   *------------------------------------------------------------------*/
  void exit_fv(void)
  {
       /* Az eredeti IT vissza�ll�t�sa */
       setvect(IT,oldfunc);
       printf("\nMinden ok!\n");
  }


  void main () {

       /* Az exit f�ggv�ny defini�l�sa */
       atexit(exit_fv);

       puts("Kil�p�s a <Shift><PrtSc> / <Print Screen> megnyom�s�val!\n");
       install_it(it_proc,IT);

       while (WAIT);   /* v�rakoz�s */

       puts("Sikeres kil�p�s");
  }









