  /*-------------------------------------------------------------*/
  /*			      SERIAL.H                           */
  /*								 */
  /*		Konstansdef�nici�k a SERIAL.C programhoz         */
  /*-------------------------------------------------------------*/

  #define COM1            1
  #define COM2            2
  #define COM1BASE        0x3F8   /* a COM1 port c�me */
  #define COM2BASE        0x2F8   /* a COM2 port c�me */

  /*-------------------------------------------------------------*
   *-------------------------------------------------------------*
      A 8250 UART  10 regiszterrel rendelkezik, amelyeket k�z�l 7
      portc�m felhaszn�l�s�val c�mezhet�nk meg. (A defini�lt c�mek
      relat�vek az alap portc�mhez k�pest.)
      A baud rate registerek (DLL �s DLH) csak akkor akt�vok, ha
      a Divisor-Latch Access-Bit (DLAB) �rt�ke 1. (A DLAB az LCR
      7. bitje.)

   *-------------------------------------------------------------*/
   #define TXR             0       /* Transmit register (WRITE) */
   #define RXR             0       /* Receive register  (READ)  */
   #define IER             1       /* Interrupt Enable          */
   #define IIR             2       /* Interrupt ID              */
   #define LCR             3       /* Line control              */
   #define MCR             4       /* Modem control             */
   #define LSR             5       /* Line Status               */
   #define MSR             6       /* Modem Status              */
   #define DLL             0       /* Divisor Latch Low         */
   #define DLH             1       /* Divisor latch High        */


  /*-------------------------------------------------------------*
   *-------------------------------------------------------------*
    A Line Control Register (LCR) tartalmazza a kommunik�ci�
    param�tereit:

	  bit             �rtelmez�s
	  ---             ----------
	  0-1             00=5,  01=6,  10=7, 11=8  adatbit
	  2               stop bitek.
	  3               0=parity off, 1=parity on.
	  4               0=parity odd, 1=parity even.
	  5               A parit�shiba fel�lbir�l�sa
	  6               BREAK.
	  7               DLAB
   *-------------------------------------------------------------*/
   #define NO_PARITY       0x00
   #define EVEN_PARITY     0x18
   #define ODD_PARITY      0x08


  /*-------------------------------------------------------------*
   *-------------------------------------------------------------*
    A Line Status Register (LSR) bitjeinek jelent�se:

	  bit             �rtelmez�s
	  ---             ----------
	  0               �rv�nyes adat van
	  1               R�fut�s t�rt�nt
	  2               Parit�shiba
	  3               Keretez�sei hiba
	  4               A Break �llapot �rz�kel�se
	  5               Az ad� adatregisztere �res
	  6               Az ad� l�ptet�regisztere �res
	  7               Time out - off line.
   *-------------------------------------------------------------*/
   #define RCVRDY          0x01
   #define OVRERR          0x02
   #define PRTYERR         0x04
   #define FRMERR          0x08
   #define BRKERR          0x10
   #define XMTRDY          0x20
   #define XMTRSR          0x40
   #define TIMEOUT         0x80


  /*-------------------------------------------------------------*
   *-------------------------------------------------------------*
    A Modem Output Control Register (MCR) bitjei:

	  bit             �rtelmez�s
	  ---             ----------
	  0               Data Terminal Ready - K�sz fogadni
	  1               Request To Send - K�ldeni k�v�n
	  2               Auxillary output #1.
	  3               Auxillary output #2. (1-be kell �ll�tani az
			  interrupt k�r�s�hez)
	  4               Az UART kimeneteinek visszak�t�se
	  5-7             Nem haszn�lt
   *-------------------------------------------------------------*/
   #define DTR             0x01
   #define RTS             0x02
   #define MC_INT          0x08


  /*-------------------------------------------------------------*
   *-------------------------------------------------------------*
    A Modem Input Status Register (MSR) bitjei:

	  bit             �rtelmez�s
	  ---             ----------
	  0               A Clear To Send bemenet megv�ltozott
			  az utols� olvas�s �ta
	  1               A Data Set Ready bemenet megv�ltozott
			  az utols� olvas�s �ta
	  2               Az Ring Indicator bemenet akt�v �llapotba
			  ker�lt az utols� olvas�s �ta
	  3               A Data Carrier Detect bemenet megv�ltozott
			  az utols� kiolvas�sa �ta
	  4               Clear To Send  - ad�sra k�sz
	  5               Data Set Ready - adat k�sz
	  6               Ring Indicator - csenget�s jelz�
	  7               Data Carrier Detect - az adatviv� �rz�kelhet�
   *-------------------------------------------------------------*/
   #define CTS             0x10
   #define DSR             0x20

  /*-------------------------------------------------------------*
   *-------------------------------------------------------------*
    Az Interrupt Enable Register (IER) haszn�lt bitjei:

	  bit             �rtelmez�s
	  ---             ----------
	  0               Megszak�t�sk�r�s, ha adat j�tt
	  1               Megszak�t�sk�r�s, ha az ad� adatregisztere �res
	  2               Megszak�t�sk�r�s, ha adatfogad�si hiba l�p fel
	  3               Megszak�t�sk�r�s, ha modem �llapot megv�ltozik
	  4-7             Nem haszn�lt.
   *-------------------------------------------------------------*/
   #define RX_INT          0x01

  /*-------------------------------------------------------------*
   *-------------------------------------------------------------*
    Az Interrupt Identification Register (IIR) bitjei:

	  bit             �rtelmez�s
	  ---             ----------
	  0               Megszak�t�sk�r�s jelz�se
	  1-2       Megszak�t�s azonos�t�:
			  00=A modem �llapot megv�ltozott
			  01=Az ad� adatregisztere �res
			  10=Adat �rkezett
			  11=Adatfogad�si hiba l�pett fel
	  3-7             Nem haszn�lt
   *-------------------------------------------------------------*/
   #define RX_ID           0x04
   #define RX_MASK         0x07


  /*-------------------------------------------------------------*
   *-------------------------------------------------------------*
   Az 8259-es programozhat� megszak�t�svez�rl� portc�mei:        */
  #define IMR             0x21   /* Interrupt Mask Register port */
  #define ICR             0x20   /* Interrupt Control port       */

  /* A hartveres megszak�t�s v�g�t jelz� �rt�k:      */
  #define EOI             0x20   /* End Of Interrupt */

  /* Maszkok */
  #define IRQ3            0xF7  /* COM2 */
  #define IRQ4            0xEF  /* COM1 */




















