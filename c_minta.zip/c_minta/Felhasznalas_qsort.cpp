#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int sort_function (const void *a, const void *b);

char list[ ][4] = { "cat", "car", "cab", "cap", "can" };

#define LISTSIZE  sizeof(list)/sizeof(char*)
#define ELEMSIZE  sizeof(list[0])/sizeof(char)
int main(void)
{
   int  i;
   
   qsort((void*)list, LISTSIZE, ELEMSIZE, sort_function);
   for (i = 0; i < LISTSIZE; printf("%s\n", list[i++]))
   ;
   printf ("%c", list[1][2]);
   return 0;
}
/* ----------------------------------------------------- */
int sort_function(const void *a, const void *b)
{
   return  strcmp((char*)a,(char*)b);
}
/* ----------------------------------------------------- */
