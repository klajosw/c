/* FOLVAS.C */
#include <stdio.h>
#include <stdlib.h>
main(int argc, char *argv[])
{
 FILE *f;
 int ch;
 f = fopen(argv[1],"r");
 if(f == NULL)
 {
   printf("Nem l�tezik: %s\n", argv[1]);
   exit(1);
 }
 while((ch = getc(f)) != EOF)
   putchar(ch);
 fclose(f);
}