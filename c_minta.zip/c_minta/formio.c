#include <stdio.h>

main()
{
 double a;
 int    b;
 char szoveg[30];

 printf("K�rek a nev�t :");
 scanf("%s", szoveg);

 printf("K�rek k�t sz�mot vessz�vel elv�lasztva: ");
 scanf("%lf,%d",&a, &b);

 printf("\nKedves %s!\n",szoveg);
 printf(" A be�rt k�t sz�m: a = %f \t b = %d\n", a, b);
}