/* RAJZ2.C */
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>

void main()
{
 int Gd, Gm, Hibakod;
   Gd = EGA;
   Gm = EGAHI;
   initgraph(&Gd, &Gm,"");
   Hibakod = graphresult();
   if (Hibakod != grOk)
    {
       clrscr();
       cprintf("Grafikus hiba: %s",grapherrormsg(Hibakod));
       exit(1);
    }

   setbkcolor(WHITE);
   setcolor(RED);
   settextjustify(CENTER_TEXT,CENTER_TEXT);
   outtextxy(300,20,"BETUKESZLETEK BEMUTATASA");
   setcolor(LIGHTBLUE);
   settextjustify(LEFT_TEXT,TOP_TEXT);
   settextstyle(DEFAULT_FONT,HORIZ_DIR,1);
   outtextxy(50,50,"Szoveg kiiratas: DefaultFont Vizszintes: HorizDir Meret: 1 ");
   settextstyle(TRIPLEX_FONT,HORIZ_DIR,2);
   outtextxy(50,70,"Szoveg kiiratas: TriplexFont Meret: 1");
   settextstyle(SANS_SERIF_FONT,HORIZ_DIR,2);
   outtextxy(50,90,"Szoveg kiiratas: SansSerifFont Meret: 1");
   settextstyle(SMALL_FONT,HORIZ_DIR,4);
   outtextxy(50,120,"Szoveg kiiratas: SmallFont Meret: 4");
   settextstyle(GOTHIC_FONT,HORIZ_DIR,1);
   outtextxy(50,140,"Szoveg kiiratas: GothicFont Meret: 2");
   settextstyle(GOTHIC_FONT,HORIZ_DIR,2);
   outtextxy(50,170,"Szoveg kiiratas: GothicFont Meret: 4");
   setcolor(BLUE);
   settextstyle(DEFAULT_FONT,VERT_DIR,1);
   outtextxy(50,220,"Szoveg VertDir");
   setcolor(BLUE);
   settextstyle(SMALL_FONT,VERT_DIR,4);
   outtextxy(80,220,"Fuggoleges irany");
   getch();
   closegraph();
}
