#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <stdlib.h>
typedef struct
				{
				 char varos[40];
				 char ut[40];
				 char hsz[10];
				 int irsz;
				} cim;
typedef struct
				{
				 int korzet;
				 int szam;
				} telefon;

typedef struct szem
				{ char nev[40];
					char fogl[40];
					cim  lakc;
					telefon tel;
					char hely[40];
					float km;
					struct szem *kov;
				} data;
 typedef void valtoztatas(int *szam,data *elso);
 void adatbe(int*);
 data* olvas(int*);
 void listszem(data*,valtoztatas*,int*);
 void listut(data*,valtoztatas*,int*);
 void keres(data*,valtoztatas*,int*);
 void leg(data*);
 void kiir(data*,int*);
 valtoztatas modosit;


main()
{

	int kilep=0,valaszt=0,in=0,friss=0,irt=0;
	data *elso,*aktual;
	clrscr();						 
		while((kilep!=105)&&(kilep!=73))
		{
			while((valaszt>6)||(valaszt<1))
			{
				gotoxy(30,6);
				printf("1:uj adat bevitele");
				gotoxy(30,8);
				printf("2:lista: nev,foglalkozas,cim");
				gotoxy(30,10);
				printf("3:lista: nev,varos,ut hossza");
				gotoxy(30,12);
				printf("4:kereses varos szerint");
				gotoxy(30,14);
				printf("5:a legtavolabbi varosba utazo adatai");
				gotoxy(30,17);
				printf("6:kilepes");
				gotoxy(30,20);
				scanf("%d",&valaszt);
			}
		 switch (valaszt)
			{
			 case	1: adatbe(&friss);break;
			 case 2: if(friss) listszem(elso,modosit,&irt);
							 else {
										 elso=olvas(&friss);
										 listszem(elso,modosit,&irt);
										}
							 break;
			 case 3: if(friss) listut(elso,modosit,&irt);
							 else {
										 elso=olvas(&friss);
										 listut(elso,modosit,&irt);
										}
							 break;

			 case 4: if(friss) keres(elso,modosit,&irt);
							 else {
										 elso=olvas(&friss);
										 keres(elso,modosit,&irt);
										}
							 break;
			 
			 case 5: if(friss) leg(elso);
							 else {
										 elso=olvas(&friss);
										 leg(elso);
										}
							 break;
			 case 6: gotoxy(20,22);
							 printf("Biztosan ki akar lepni?(i,I=igen;n,N=nem)");	
							 kilep=0;
							 while((kilep!=105)&&(kilep!=73)&&(kilep!=78)&&(kilep!=110))
							 kilep=getchar();
							 break;
			}
		}
 if(irt)
	{
	 gotoxy(10,23);
	 printf("A file tartalma megvaltozott. Kivanja menteni?(i,I=igen;n,N=nem)");
	 in=0;
	 while((in!=105)&&(in!=73)&&(in!=78)&&(in!=110))
	 in=getchar();
	 if((in=105)&&(in=73))
		kiir(elso,&irt);
	}
	 aktual=elso;
	 while(aktual->kov!=NULL)
	 free(aktual);
}

void adatbe(int*fris)
 {
	FILE *fp;
	data ad;
	int folytat=1,in=0;
	clrscr();
	fp=fopen("c:\\tuc\\adat.dat","w+b");
	 if(fp==NULL)
		{
		 clrscr();
		 gotoxy(30,12);
		 printf("A file nem megnyithato.");
		 sleep(3);
		 *fris=1;
		 clrscr();
		 return;
		}
		gotoxy(25,2);printf("ADATBEVITEL");
	do
	 {
		gotoxy(2,4);delline();printf("Nev :");
		gotoxy(2,6);delline();printf("Foglalkozas :");
		gotoxy(2,8);delline();printf("Lakcim varos :");
		gotoxy(2,10);delline();printf("utcanev :");
		gotoxy(9,12);delline();printf("hazszam :");
		gotoxy(9,14);delline();printf("iranyitoszam :");
		gotoxy(9,16);delline();printf("Telefon korzetszam :");
		gotoxy(10,18);delline();printf("szam :");
		gotoxy(2,20);delline();printf("uticel(helyseg) :");
		gotoxy(2,22);delline();printf("tavolsag(km) :");

		gotoxy(40,4);gets(ad.nev);
		gotoxy(40,6);gets(ad.fogl);
		gotoxy(40,8);gets(ad.lakc.varos);
		gotoxy(40,10);gets(ad.lakc.ut);
		gotoxy(40,12);gets(ad.lakc.hsz);
		gotoxy(40,14);scanf("%d",&(ad.lakc.irsz));
		gotoxy(40,16);scanf("%d",&(ad.tel.korzet));
		gotoxy(40,18);scanf("%d",&(ad.tel.szam));

		gotoxy(40,20);gets(ad.hely);
		gotoxy(40,22);scanf("%f",&(ad.km));
		ad.kov=NULL;
		gotoxy(18,24); delline();
		printf("Kivan modositani?(igen=i,I;nem=n,N)");
		in=0;
		while((in!=105)&&(in!=73)&&(in!=78)&&(in!=110))
		in=getchar();
		if((in=110)&&(in=78))
		 {
			fwrite(&ad,sizeof(data),1,fp);
			gotoxy(76,24);printf("Y");
			fflush(fp);
		 }
		delline();
		 gotoxy(18,24);
		 printf("Kivan ujabb adatot beirni?(igen=i,I;nem=n,N)");
		 folytat=0;
		 in=0;
		 while((in!=105)&&(in!=73)&&(in!=78)&&(in!=110))
		 {
		 gotoxy(64,24);
		 in=getchar();
		 }
		 if((in=105)||(in=73))
			folytat=1;
	 }
	while(folytat);
	 fclose(fp);
	 *fris=0;
	 clrscr();
	 return;
 }

data* olvas(int*fris)
 {
	int muv;
	data *aktual,*elozo,*elso;
	FILE *fp;
	fp=fopen("c:\\tuc\\adat.dat","rb");
	 if(fp==NULL)
		{
		 clrscr();
		 gotoxy(30,12);
		 printf("A file nem megnyithato.");
		 sleep(3);       
		 *fris=0;
		 return(NULL);
		}
	 elso=(data*)malloc(sizeof(data));
	 muv=fread(elso,sizeof(data),1,fp);
	 aktual=elso;
	 while(muv)
	 {
		elozo=aktual;
		aktual=(data*)malloc(sizeof(data));
		muv=fread(elso,sizeof(data),1,fp);
		elozo->kov=aktual;
		if(!muv)
		 {
			elozo->kov=NULL;
			free(aktual);
		 }
	 }
	 *fris=1;
	 fclose(fp);
	 return(elso);
 }

void listszem(data *elso,valtoztatas *fvp,int *irt)
 {
	 data *aktual;
	 int sorszam=0,valaszt=0;
		clrscr();
		gotoxy(25,2);printf("LISTA");
		gotoxy(1,23);printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
		aktual=elso;
		while(aktual->kov!=NULL)
		{
			gotoxy(1,4+((sorszam)%3)*6);
			printf("%d",sorszam);
			gotoxy(7,4+((sorszam)%3)*6);
			printf("Nev : %s",aktual->nev);
			gotoxy(7,5+((sorszam)%3)*6);
			printf("Foglalkozas : %s",aktual->fogl);
			gotoxy(7,6+((sorszam)%3)*6);
			printf("Lakcim  varos : %s",aktual->lakc.varos);
			gotoxy(7,7+((sorszam)%3)*6);
			printf("         ut : %s",aktual->lakc.ut);
			gotoxy(7,8+((sorszam)%3)*6);
			printf("         hsz : %s",aktual->lakc.hsz);
			gotoxy(30,8+((sorszam)%3)*6);
			printf("irsz : %d",aktual->lakc.irsz); 
			aktual=aktual->kov;
			sorszam++; 
			if (!(sorszam%3))
			 {
				 gotoxy(60,23);
				 valaszt=0;
				 while((valaszt!=109)&&(valaszt!=107)&&(valaszt!=102))
				 valaszt=getchar();
				 switch(valaszt)
				 {
					case 109: (*fvp)(&sorszam,elso);
										*irt=1;
										clrscr();
										gotoxy(25,2);
										printf("LISTA");
										gotoxy(1,23);
										printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
										break;
					case 107: clrscr();
										gotoxy(25,2);
										printf("LISTA");
										gotoxy(1,23);
										printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
										break;
					case 102: clrscr();
										return;
				 }
			 }
		}
	gotoxy(1,23);
	delline();
	printf(" m:adatmodositas  f:vissza a fomenube");
	gotoxy(60,23);
	valaszt=0;
	 while((valaszt!=109)&&(valaszt!=102))
		valaszt=getchar();
		switch(valaszt)
		 {
			case 109: (*fvp)(&sorszam,elso);
								*irt=1;
								clrscr();
								gotoxy(25,2);
								printf("LISTA");
								gotoxy(1,23);
								printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
								break;
			case 102: clrscr();
								return;
		 }
 }
void listut(data *elso,valtoztatas *fvp,int *irt)
 {
	 data *aktual;
	 int sorszam=0,valaszt=0;
		clrscr();
		gotoxy(25,2);printf("LISTA");
		gotoxy(1,23);printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
		aktual=elso;
		while(aktual->kov!=NULL)
		 {
			gotoxy(1,4+((sorszam)%3)*6);
			printf("%d",sorszam);
			gotoxy(7,4+((sorszam)%3)*6);
			printf("Nev : %s",aktual->nev);
			gotoxy(7,6+((sorszam)%3)*6);
			printf("Utazasi cel : %s",aktual->hely);
			gotoxy(7,7+((sorszam)%3)*6);
			printf("uticel tavolsaga : %f",aktual->km);
			
			aktual=aktual->kov;
			sorszam++; 
			if (!(sorszam%3))
			 {
				 gotoxy(60,23);
				 valaszt=0;
				 while((valaszt!=109)&&(valaszt!=107)&&(valaszt!=102))
				 valaszt=getchar();
				 switch(valaszt)
				 {
					case 109: (*fvp)(&sorszam,elso);
										*irt=1;
										clrscr();
										gotoxy(25,2);
										printf("LISTA");
										gotoxy(1,23);
										printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
										break;
					case 107: clrscr();
										gotoxy(25,2);
										printf("LISTA");
										gotoxy(1,23);
										printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
										break;
					case 102: clrscr();
										return;
				 }
			 }
			}
	gotoxy(1,23);
	delline();
	printf(" m:adatmodositas  f:vissza a fomenube");
	gotoxy(60,23);
	valaszt=0;
	 while((valaszt!=109)&&(valaszt!=102))
		valaszt=getchar();
		switch(valaszt)
		 {
			case 109: (*fvp)(&sorszam,elso);
								*irt=1;
								clrscr();
								gotoxy(25,2);
								printf("LISTA");
								gotoxy(1,23);
								printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
								break;
			case 102: clrscr();
								return;
		 }
 }

void keres(data*elso,valtoztatas *fvp,int*irt)
 {
	data *aktual;
	char kerhely[40];
	int sorszam=0,valaszt=0;
		clrscr();
		gotoxy(25,2);printf("KERESES");
		gotoxy(5,10);printf("Melyik varosba utazok adataira kivancsi?");
		gets(kerhely);
		delline();
		gotoxy(1,23);printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
		aktual=elso;
		while(aktual->kov!=NULL)
		 {
				if(aktual->hely==kerhely)
				 {
					 gotoxy(2,4);printf("Nev :");
					 gotoxy(40,4);printf("%s",aktual->nev);
					 gotoxy(2,6);printf("Foglalkozas :");
					 gotoxy(40,6);printf("%s",aktual->fogl);
					 gotoxy(2,8);printf("Lakcim varos :");
					 gotoxy(40,8);printf("%s",aktual->lakc.varos);
					 gotoxy(2,10);printf("       utcanev :");
					 gotoxy(40,10);printf("%s",aktual->lakc.ut);
					 gotoxy(2,12);printf("       hazszam :");
					 gotoxy(40,12);printf("%s",aktual->lakc.hsz);
					 gotoxy(2,14);printf("       iranyitoszam :");
					 gotoxy(40,14);printf("%d",aktual->lakc.irsz);
					 gotoxy(2,16);printf("Telefon korzetszam :");
					 gotoxy(40,16);printf("%d",aktual->tel.korzet);
					 gotoxy(2,18);printf("        szam :");
					 gotoxy(40,18);printf("%d",aktual->tel.szam);
					 gotoxy(2,20);printf("Uticel(helyseg) :");
					 gotoxy(40,20);printf("%s",aktual->hely);
					 gotoxy(2,22);printf("Tavolsag(km) :");
					 gotoxy(40,22);printf("%f",aktual->km);

					gotoxy(60,23);
					valaszt=0;
					while((valaszt!=109)&&(valaszt!=107)&&(valaszt!=102))
					valaszt=getchar();
					switch(valaszt)
					{
					 case 109: (*fvp)(&sorszam,elso);
										 *irt=1;
										 clrscr();
										 gotoxy(25,2);
										 printf("LISTA");
										 gotoxy(1,23);
										 printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
										 break;
					 case 107: clrscr();
										 gotoxy(25,2);
										 printf("LISTA");
										 gotoxy(1,23);
										 printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
										 break;
					 case 102: clrscr();
										 return;
					}
				 }
				aktual=aktual->kov;
				sorszam++; 
		 }

	gotoxy(1,23);
	delline();
	printf(" m:adatmodositas  f:vissza a fomenube");
	gotoxy(60,23);
	valaszt=0;
	 while((valaszt!=109)&&(valaszt!=102))
		valaszt=getchar();
		switch(valaszt)
		 {
			case 109: (*fvp)(&sorszam,elso);
								*irt=1;
								clrscr();
								gotoxy(25,2);
								printf("LISTA");
								gotoxy(1,23);
								printf("k:kovetkezo  m:adatmodositas  f:vissza a fomenube");
								break;
			case 102: clrscr();
								return;
		 }
 }

void leg(data*elso)
{
 float legkm=0;
 data *aktual,*akt;
 clrscr();
 gotoxy(10,2);printf("A LEGNAGYOBB UTAT MEGTEVO ADATAI:");
	 akt=elso;
		 while(akt->kov!=NULL)
		 {
			if(akt->km>legkm)
			{
			 legkm=akt->km;
			 aktual=akt;
			}
			akt=akt->kov;
		 }
	 gotoxy(2,4);printf("Nev :");
	 gotoxy(40,4);printf("%s",aktual->nev);
	 gotoxy(2,6);printf("Foglalkozas :");
	 gotoxy(40,6);printf("%s",aktual->fogl);
	 gotoxy(2,8);printf("Lakcim varos :");
	 gotoxy(40,8);printf("%s",aktual->lakc.varos);
	 gotoxy(2,10);printf("       utcanev :");
	 gotoxy(40,10);printf("%s",aktual->lakc.ut);
	 gotoxy(2,12);printf("       hazszam :");
	 gotoxy(40,12);printf("%s",aktual->lakc.hsz);
	 gotoxy(2,14);printf("       iranyitoszam :");
	 gotoxy(40,14);printf("%d",aktual->lakc.irsz);
	 gotoxy(2,16);printf("Telefon korzetszam :");
	 gotoxy(40,16);printf("%d",aktual->tel.korzet);
	 gotoxy(2,18);printf("        szam :");
	 gotoxy(40,18);printf("%d",aktual->tel.szam);
	 gotoxy(2,20);printf("Uticel(helyseg) :");
	 gotoxy(40,20);printf("%s",aktual->hely);
	 gotoxy(2,22);printf("Tavolsag(km) :");
	 gotoxy(40,22);printf("%f",aktual->km);
	 gotoxy(10,23);printf("f:fomenu");
	 while(getchar()!=102)
	 sleep(1);
	 clrscr();
	 return;
}

void kiir(data*elso,int *irt)
{
 data*aktual;
 FILE *fp;
	fp=fopen("c:\\tuc\\adat.dat","wb");
	 if(fp==NULL)
		{
		 clrscr();
		 gotoxy(30,12);
		 printf("A file nem megnyithato.");
		 sleep(3);
		 clrscr();
		 *irt=0;
		 return;
		}
		aktual=elso;
		while(aktual->kov!=NULL)
		{
		 fwrite(aktual,sizeof(data),1,fp);
		 fflush(fp);
		 aktual=aktual->kov;
		}
 *irt=1;
 fclose(fp);
}

void modosit(int *szam,data *elso)
{
 int i,valaszt;
 data *aktual,*elozo;
 aktual=elso;
 for(i=1;i< *szam;i++)
	{
	 elozo=aktual;
	 aktual=aktual->kov;
	}
 clrscr();
		gotoxy(2,4);printf("1.Nev :");
		gotoxy(40,4);printf("%s",aktual->nev);
		gotoxy(2,6);printf("2.Foglalkozas :");
		gotoxy(40,6);printf("%s",aktual->fogl);
		gotoxy(2,8);printf("3.Lakcim varos :");
		gotoxy(40,8);printf("%s",aktual->lakc.varos);
		gotoxy(2,10);printf("4.       utcanev :");
		gotoxy(40,10);printf("%s",aktual->lakc.ut);
		gotoxy(2,12);printf("5.       hazszam :");
		gotoxy(40,12);printf("%s",aktual->lakc.hsz);
		gotoxy(2,14);printf("6.       iranyitoszam :");
		gotoxy(40,14);printf("%d",aktual->lakc.irsz);
		gotoxy(2,16);printf("7.Telefon korzetszam :");
		gotoxy(40,16);printf("%d",aktual->tel.korzet);
		gotoxy(2,18);printf("8.        szam :");
		gotoxy(40,18);printf("%d",aktual->tel.szam);
		gotoxy(2,20);printf("9.Uticel(helyseg) :");
		gotoxy(40,20);printf("%s",aktual->hely);
		gotoxy(2,22);printf("10.Tavolsag(km) :");
		gotoxy(40,22);printf("%f",aktual->km);
		gotoxy(10,23);
		printf("Melyik adatot kivanja modositani?(1-10,11.=rekord torlese)");
		valaszt=0;
		while((valaszt>11)&&(valaszt<1))
		scanf("%d",&valaszt);
		switch(valaszt)
		{
		 case 1: gotoxy(40,4);
						 clreol();
						 gets(aktual->nev);
						 break;
		 case 2: gotoxy(40,6);
						 clreol();
						 gets(aktual->fogl);
						 break;
		 case 3: gotoxy(40,8);
						 clreol();
						 gets(aktual->lakc.varos);
						 break;
		 case 4: gotoxy(40,10);
						 clreol();
						 gets(aktual->lakc.ut);
						 break;
		 case 5: gotoxy(40,12);
						 clreol();
						 gets(aktual->lakc.hsz);
						 break;
		 case 6: gotoxy(40,14);
						 clreol();
						 scanf("%d",&(aktual->lakc.irsz));
						 break;
		 case 7: gotoxy(40,16);
						 clreol();
						 scanf("%d",&(aktual->tel.korzet));
						 break;
		 case 8: gotoxy(40,18);
						 clreol();
						 scanf("%d",&(aktual->tel.szam));
						 break;
		 case 9: gotoxy(40,20);
						 clreol();
						 gets(aktual->hely);
						 break;
		 case 10: gotoxy(40,22);
							clreol();
							scanf("%f",&(aktual->km));
							break;
		 case 11: elozo=aktual->kov;
							free(aktual);
							(*szam)--;
							break;
		}
}
