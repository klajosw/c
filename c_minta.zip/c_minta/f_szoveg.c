/*  F_SZOVEG.C */
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>

void main()
{
 int Gd, Gm, Hibakod;
    Gd = DETECT;
    initgraph(&Gd, &Gm,"");
    Hibakod = graphresult();
    if (Hibakod)
    {
       clrscr();
       cprintf("Grafikus hiba: %s ",grapherrormsg(Hibakod));
       exit(1);
    }
    settextstyle(TRIPLEX_FONT,HORIZ_DIR,4);
    outtextxy(50,50,"Normalis");
    setusercharsize(1,2,1,1);
    outtextxy(50,100,"Keskeny");
    setusercharsize(3,1,1,1);
    outtextxy(50,150,"Szeles");
     getch();
    closegraph();
 }
