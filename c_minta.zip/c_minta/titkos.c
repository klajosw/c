
#include <stdio.h>

#define KULCS 0xE7;

main()
{
  char s[80], *p;
  int i;

  printf("K�rek egy sz�veget   : ");
  gets(s);

  for (i = 0; s[i]; i++)        /* A titkos�t�s   */
      s[i] ^= KULCS;
  printf("A titkos�tott sz�veg : %s\n", s);

  p=s;
  while (*p)                    /* A vissza�ll�t�s */
     *p++ ^= KULCS;
  printf("Az eredeti sz�veg    : %s\n", s);
}

