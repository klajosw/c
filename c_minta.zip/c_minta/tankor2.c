/* TANKOR2.C */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>

struct datum    {
		  int ev;
		  char honap[10];
		  char nap[9];
		};
struct szemely  {
		  char  nev[30];
		  float osztondij;
		  int tankorszama;
		  struct datum szuldatum;
		  char honap[10];
		  char nap[10];
	       };

main()
{
int    i, n, j, c;
int    sor;
float  maxdij;
struct szemely tanulok[12];

    printf("\nTanul�k sz�ma : "); scanf("%d",&n);

    for (i = 0; i < n; i++)
    {
      printf("\nNeve          : ");
      j = 0;
      c = getchar();
      c = getchar();
      while( c  != '\n')
      {
	tanulok[i].nev[j] = c;
	j++;
	c = getchar();
      }
      tanulok[i].nev[j] = '\0';
      printf("�szt�ndija    : ");
      scanf("%f",&tanulok[i].osztondij);
      printf("tank�r sz�ma  : ");
      scanf("%d",&tanulok[i].tankorszama);
      printf("sz�let�si �ve : ");
      scanf("%d",&tanulok[i].szuldatum.ev);
      printf("h�nap         : ");
      scanf("%s",tanulok[i].szuldatum.honap);
      printf("nap           : ");
      scanf("%s",tanulok[i].szuldatum.nap);

     }

     sor = 0;
     maxdij = tanulok[0].osztondij;
     for(i = 0; i < n; i++)
     {
      if ( maxdij < tanulok[i].osztondij)
	{
	  maxdij = tanulok[i].osztondij;
	  sor = i;
	}
     }
    printf("\nA legt�bb �szt�ndijat kapja:");
    printf("\nNeve          :%s %s\n",tanulok[sor].nev);
    printf("�szt�ndija    :%6.2f\n",tanulok[sor].osztondij);
    printf("tank�r sz�ma  :%d\n",tanulok[sor].tankorszama);
    printf("sz�let�si �ve :%d\n",tanulok[sor].szuldatum.ev);
    printf("h�nap         :%s\n",tanulok[sor].szuldatum.honap);
    printf("nap           :%s\n",tanulok[sor].szuldatum.nap);

}
