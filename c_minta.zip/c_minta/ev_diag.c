/* EV_DIAG.C */
#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include <ctype.h>
#include <string.h>
#define TRUE 1

void ev_diagram(double *w,int n, char *sz,int ev,int tipus);
int GetMin(double *w,int n);
int GetMax(double *w,int n);

void main()
{
double y[12];
int m,i,evszam,tip;
char sz[80];
  clrscr();
  printf("Adatok beolvas�sa havi bont�sban\n");
  m = 12;
  printf("Az adatok sz�ma: %d\n",m);
  for( i = 0; i < m; i++)
  {
    printf("%3d .adat = ",i+1); scanf("%lf",&y[i]);
  }
  sz[0] = '\0';
  printf("\nA diagram fejl�ce: ");
  do
  {
    gets(sz);
  }while (sz[0] == '\0');
  printf("�vsz�m           :  "); scanf("%d",&evszam);
  tip = 3;
  do
  {
    printf("�br�zol�s m�dja: has�b(1) t�glalap (0) : ");
    scanf("%d", &tip);
  }
  while ((tip != 1) && (tip != 0));
  ev_diagram(y,m,sz,evszam,tip);
}

int GetMin(double w[], int n)   /* minim�lis �rt�k kiv�laszt�sa */
{
 int    i,imin;
 double min;
   min = w[1];
	 for(i = 1; i <= n; i++)
     if(w[i] < min) { min = w[i]; }
  imin = min + 0.5;
 return(imin);
}

int GetMax(double w[],int n)  /* maxim�lis �rt�k kiv�laszt�sa */
{
 int    i,imax;
 double max;
  max = w[1];
  for(i = 0; i < n; i++)
   if(w[i] > max) { max = w[i]; }
  imax = max+0.5;
 return( imax);
}

void ev_diagram(double w[],int n,char *sz,int ev,int tipus)
/* diagramrajzol� */
{
 char szam[10], szam1[10], buff[70];
 int i;
 double snorm;
 int tmax,tmin;
 int gd,gm;
 int color[3];
 int xk,xm,ym,m,tsz,xx1,yy1,xx2,yact;
 int x1,y1,x2,y2;
 char *ho[]= {
              "JAN",
              "FEBR",
              "MARC",
              "APR",
              "MAJ",
              "JUN",
              "JUL",
              "AUG",
              "SZEP",
              "OKT",
              "NOV",
              "DEC"
             };
  tmax=GetMax(w,n);
  tmin=GetMin(w,n);
  detectgraph(&gd,&gm);   /* a monitor t�pus�nak kiv�laszt�sa */
  switch(gd)
  {
    case 1:gm = CGAC1;
           color[1] = 1; color[2] = 2;color[3] = 3;
           break;
    case 3:gm = EGALO;
           color[1] = CYAN; color[2] = LIGHTRED; color[3] = BLUE;
           break;
    case 9:gm = VGALO;
           color[1] = CYAN; color[2] = LIGHTRED;color[3] = BLUE;
           break;
  }
  initgraph(&gd,&gm,"");  /* grafikus �zemm�d megnyit�sa */
  xm = getmaxx();      /* k�perny� max m�rete */
  ym = getmaxy();
  setcolor(color[1]);
  if (gd == 1) setbkcolor(BLACK); else setbkcolor(WHITE);
  settextjustify(CENTER_TEXT,CENTER_TEXT);
  outtextxy( (int)(xm/2),10, sz);       /* fejl�c kiirat�sa */
  sprintf(szam,"%4d", ev);
  outtextxy((int)(xm/2),192,szam);     /* �vsz�m kiirat�sa */
  x1 = 20; y1 = 30; x2 = xm-20; y2 = ym-30;
  if (gd == 1) {x1 = 5; x2 = xm-5; }
  setcolor(color[3]);
  settextjustify(LEFT_TEXT,BOTTOM_TEXT);
  sprintf(szam,"%6d",tmax);           /* minim�lis �s maxim�lis */
  sprintf(szam1,"%6d",tmin);          /* �rt�kek kiirat�sa      */
  buff[0] = '\0';
  strncat(buff,"minimum: ",9);
  strncat(buff,szam1,6);
  strncat(buff,"     maximum: ",15);
  strncat(buff,szam,6);
  outtextxy(x1,28,buff);
  rectangle(x1,y1,x2,y2+2);
  m = y2-y1-6;
  snorm=(double)m/(double)tmax;
  yact=y2-y1;
  if (gd==1) { tsz=(x2-x1-9)/n; xx2=-4; }
   else { tsz=(x2-x1-1)/n; xx2=x1-8;}
  tsz=tsz-9;
  setcolor(color[2]);
  window(x1,y1,x2,y2);
  setfillstyle(9,color[2]);
  if( gd == 1)
  {
    settextstyle(SMALL_FONT,HORIZ_DIR,1);
    setusercharsize(13,12,14,17);
  }
  for(i = 0; i < n; i++)
  {
    xx1=xx2+10;
    xx2=xx1+tsz;
    yy1=y1+yact-(int)(w[i]*snorm+0.5);
    setcolor(color[1]);
    /* ha a tipus �rt�ke 1, akkor has�bdiagramot rajzol */
    /* ha a tipus �rt�ke 0, akkor t�glalappal �br�zol   */
    if(tipus) bar3d(xx1,yy1,xx2,y2,6,TRUE);
    else
    {
      bar(xx1,yy1,xx2,y2);
      rectangle(xx1,yy1,xx2,y2);
    }
  if (gd == 1) xk = xx1;
    else xk = xx1+8;
   outtextxy(xk, y2+12, ho[i]);
  }
  getch();   /* egy billenty� le�t�s�re v�r  */
  closegraph();     /* lez�rja a grafikus m�dot     */
 return;
}
