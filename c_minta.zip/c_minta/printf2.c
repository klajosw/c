#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
main()
{
int a,b,c;
char str[160];
do{
	 printf("\n  Kerem a ket szamot!:  ");
	 gets(str);
	 if ( sscanf(str,"%ds%d",&a,&b)!=2 ) { printf("\nHibas adatok");
																		fflush(stdin);
																		continue; 
																	}
	 c=a+b;
	 printf("\n A ket szam osszege: %d+%d=%d",a,b,c);
	 }
while (getch()!=32);
}