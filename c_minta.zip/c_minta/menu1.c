#include <stdio.h>
#include <conio.h>

/* A men� defin�ci�ja */

char * menu[] = { "\n",
		  "1. Beolvas",
		  "2. Sz�mol",
		  "3. Ki�r",
		  "----------",
		  "0. Kil�p" ,
		  "\n",
		  NULL };


/* Glob�lis v�ltoz�k, k�z�s haszn�latra */
int a, b, c;


/* A men�pontnak megfelel� f�ggv�nyek defin�ci�ja */
void beolvas(void)
{
  printf("K�rek k�t sz�mot [a,b]: ");
  scanf("%d,%d",&a,&b);
}

void szamol(void)
{
  c = a + b;
}

void kiir(void)
{
  printf("%d + %d = %d\n", a, b, c);
}

main()
{
  char ch , **p;

  do
  {
      /* A men� ki�r�sa */
      p = menu;
      while (*p)
	 printf("%s\n", *p++);
      ch = getch();
      switch (ch) {
	case '0':
	     break;
	case '1':
	     beolvas();
	     break;
	case '2':
	     szamol();
	     break;
	 case '3':
	     kiir();
	     break;
	 default:
	     putchar('\a');
      }
  } while  (ch!='0');
}
