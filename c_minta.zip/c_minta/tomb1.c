/*  TOMB1.C  */
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define xabs(x) ((x) < 0 ? (-(x)) : (x))

typedef double f_x[50];

int beolvas(f_x);
void kiir(int, f_x);
double atlag(int , f_x);
double szumma(int, f_x );
void anal(int, f_x, int*, int* , int* );
void elter(int, f_x, int*,double*, int*, double*);

main()
{
int n,nulla,pozitiv,neg,mini,maxi;
f_x  y;
double atl,elter_min,elter_max,sum;
    n=beolvas(y);
    kiir(n,y);
    atl=atlag(n,y);
    printf("\n�tlag  : %6.2lf \n",atl);

    sum=szumma(n,y);
    printf("�sszeg : %6.2lf \n",sum);

    printf("\nAnalizis\n");
    anal(n,y,&nulla,&pozitiv,&neg);
    printf("Z�rus   tagok sz�ma: %d \n",nulla);
    printf("Pozitiv tagok sz�ma: %d \n",pozitiv);
    printf("Negativ tagok sz�ma: %d \n",neg);

    printf("\nElt�r�s az �tlagt�l\n");
    elter(n,y,&mini,&elter_min,&maxi,&elter_max);
printf("%d. elem %6.2lf %6.2lf �rt�kkel minim�lisan t�r el %6.2lf �tlagt�l\n",
	    mini,y[mini],elter_min,atl);
printf("%d. elem %6.2lf %6.2lf �rt�kkel maxim�lisan t�r el %6.2lf �tlagt�l\n",
	    maxi,y[maxi],elter_max,atl);
}

int beolvas(f_x y)
{
int i,n;
    printf("\nAz elemek sz�ma : "); scanf("%d",&n);
    for(i=0; i<n; i++)
    {
      printf(" %d. elem : ",i); scanf("%lf",&y[i]);
    }
    return(n);
}

void kiir(int m, f_x w)
{
int i;
   printf("\nBeolvasott elemek \n");
   for(i=0; i<m; i++)
      printf(" %d. elem : %6.2lf\n",i,w[i]);
}

double atlag(int m, f_x w)
{
int i;
double s;
  s=0.;
  for(i=0; i<m; i++)
    s=s+w[i];
return(s/m);
 }

double szumma(int m, f_x w)
{
int i;
double s;
  s=0.;
  for(i=0; i<m; i++)
    s=s+w[i];
return(s);
 }

void anal(int m, f_x w, int* zerus, int* poz, int* neg)
{
int i;
   *poz=0; *neg=0; *zerus=0;
   for(i=0; i<m; i++)
   {
    if( w[i] > 0) *poz+=1;
	       else
	       { if(w[i]<0) *neg+=1;
		    else *zerus+=1;
	       }
   }
}

void elter(int m, f_x w, int* min, double* elter_min,
	   int* max, double* elter_max)
{
int i;
double atl,s;
  atl=atlag(m,w);
  *min=1;
  *max=1;
  *elter_min=xabs(atl-w[1]);
  *elter_max=xabs(atl-w[1]);
  for(i=1; i<m; i++)
  {
    s=xabs(atl-w[i]);
    if( s < *elter_min) { *min=i; *elter_min=s; }
    if( s > *elter_max) { *max=i; *elter_max=s; }
  }
 }
