/*  GRAFIKA1.C */
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>

void main()
{
 int   Gd, Gm, Hibakod;
   Gd = DETECT;
   initgraph(&Gd, &Gm, "");
   Hibakod = graphresult();
   if (Hibakod)
   {
     clrscr();
     cprintf("Grafikus hiba: %s ",
	      grapherrormsg(Hibakod));
     exit(1);
   }
   /* rajzol�s */
   rectangle(100,100,60,40);
   getch();
   closegraph();
}

