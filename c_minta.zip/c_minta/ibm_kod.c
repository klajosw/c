/* IBM_KOD.C */

#include <conio.h>

void main()
{
  typedef char tscreen[25][80][2];

  char st[]="0123456789ABCDEF";
  tscreen far * scr=(tscreen far *)0xb8000000;
  int  i,j;

  textbackground(BLUE);
  textcolor(YELLOW);
  clrscr();

  gotoxy(8,3);
  for (i=0; i<=15; i++)
    cprintf("%4c",st[i]);

  for (i=0; i<=15; i++)
  {
    gotoxy(1,i+6);
    cprintf("%4c",st[i]);
    for (j=0; j<=15; j++)
       (*scr)[(i+5)][10+j*4][0]=i*16+j;
  }
  cprintf("\n");
  getch();
}
