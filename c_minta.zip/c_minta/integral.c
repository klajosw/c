/* INTEGRAL.C */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

typedef double func(double x);
typedef func   *fp;

double fg1(double);
double fg2(double);
double fg3(double);

double teglalap(double,double,int,fp);
double trapez(double,double,int,fp);
double simpson(double,double,int,fp);

void main()
{
 double a,b;
 int    n;
   _fpreset();
   printf("Integr�l�s t�glalap, trap�z �s Simpson m�dszerrel\n");

   printf("A program az f(x)=4./(1.+x*x) f�ggv�ny hat�rozott\n");
   printf("integr�lj�t sz�mitja ki az adott intervallumban.\n");
   printf("Javasolt adatok: als� hat�r:0, fels� hat�r:1, intervallum: 100\n");

   printf("\nAls� hat�r         : ");
   scanf("%lf",&a);

   printf("Fels� hat�r        : ");
   scanf("%lf",&b);

   printf("Intervallumok sz�ma: ");
   scanf("%d",&n);

   printf("\nA t�glalap integr�l : %lf",teglalap(a,b,n,fg1));

   printf("\nA trap�z integr�l   : %lf",trapez(a,b,n,fg1));

   printf("\nA Simpson integr�l  : %lf",simpson(a,b,n,fg1));
}

/* Az fg1  a pi = 3.141592 �rt�k�t adja a [0,1] intervallumban */

double fg1(double x)
{
  return(4.0/(1.0+x*x));
}

/* Az fg2 az [1,2] intervallumban ln(x)= 0.68  */
double fg2(double x)
{
   return (1/x);
}

/* Az fg3 az [0,3.141] intervallumban 2.0 �rt�ket adja */
double fg3 (double x)
{
  return (sin(x));
}

double teglalap(double a, double b, int n, fp f)
{
 int    i;
 double s, h;
   h = (b-a)/n;
   s = 0;
   for(i = 1; i < n; i++)
   {
     s +=  (*f)(a+h*i);
   }
   return h * ((*f)(a) + s + (*f)(b));
}

double trapez(double a, double b, int n, fp f)
{
 int    i;
 double s, h;
   h = (b-a)/n;
   s = 0;
   for(i = 1; i < n; i++)
   {
     s += (*f)(a+h*i);
   }
   return h * ((*f)(a)/2 + s + (*f)(b)/2);
}

double simpson(double a, double b, int n, fp f)
{
 double h, s;
 int    i;
   s = 0;
   h = (b-a)/n;

   for(i = 1; i < n; i++)
   {
     s = s+4*(*f)(a+i*h)*(i % 2)+2*(*f)(a+i*h)*((i+1) % 2);
   }
   s += (*f)(a)+(*f)(b);
   s *= h/3;
   return s;
}
