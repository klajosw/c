/*-------------------------------------------------------*/
/*                        ZONGORA.C                      */
/*   							 */
/*            Egyszer� zen�l� billenty�zet               */
/*-------------------------------------------------------*/


#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <ctype.h>
#include <string.h>


char teszt(char s);
int hang(int hang);

enum {OFF, ON};

FILE *szalag;
char nev;
int i,j,s,z,m,v;
int record = OFF;

int main()
{
  static  char hangok[]="<A>\0<S>\0<D>\0<F>\0<G>\0<H>\0<J>\0<K>\0<L>\0";
  static int a[8]={70,140,210,280,350,420,490,560};
  static int b[8]={150,2,150,150,2,150,150,150};
  static int c[6]={50,190,260,400,470,540};
  static int d[6]={90,230,300,440,510,580};
  static int e[5]={0,10,20,30,40};
  static int f[9]={15,20,25,30,35,40,45,15,20};
  static int h[9]={30,100,170,240,310,380,450,520,590};
  int ch;

   /* az automatikus vez�rl� �s m�d detekt�l�s k�r�se */
   int gdriver = DETECT, gmode, errorcode;

   /* a grafikus m�d inicializ�l�sa */
   initgraph(&gdriver, &gmode, "");

   /* az inicializ�ci� sikeress�g�nek ellen�rz�se */
   errorcode = graphresult();
   if (errorcode != grOk)  /* ha hiva volt */
   {
      printf("Graphics error: %s\n", grapherrormsg(errorcode));
      printf("Press any key to halt ...");
      getch();
      exit(1);             /* kil�p�s hibak�ddal */
   }

   setcolor(LIGHTBLUE);
   setbkcolor(BLACK);

   /*---- a zongora billenty�inek rajzol�sa ----*/
   setfillstyle(SOLID_FILL, WHITE);
   bar(0,0,getmaxx(),getmaxy()/2);

   for (i=0; i<=7; i++)
      line(a[i],getmaxy()/2,a[i],b[i]);

   setfillstyle(SOLID_FILL,BLACK);
   for (i=0; i<=5; i++)
       bar(c[i],0,d[i],148);

   /*---- a  hangjegyek rajzol�sa ----*/
   for (i=0; i<=4; i++)
       line(0,(getmaxy()*2/3)-(e[i]),getmaxx(),(getmaxy()*2/3)-(e[i]));

   setfillstyle(SOLID_FILL,getcolor());
   for (i=0;i<=8;i++)
       fillellipse(h[i],(getmaxy()*2/3)-(f[i]),4,4);

   /*---- sz�veg elhelyez�se a grafik�ban ----*/
   settextstyle(TRIPLEX_FONT,0,3);
   for (i=0; i<9; i++)
   outtextxy(i*70+10,(getmaxy()/2)-50,&hangok[4*i]);

   setcolor(YELLOW);
   settextstyle(SMALL_FONT,0,6);
   outtextxy(getmaxx()/2-70,(getmaxy()-125),"1: felvetel indit");
   outtextxy(getmaxx()/2-70,(getmaxy()-100),"2: felvetel vege");
   outtextxy(getmaxx()/2-70,(getmaxy()-75), "3: visszajatszas");
   outtextxy(getmaxx()/2-70,(getmaxy()-50), "X: kilepes");

   /* vez�rl�s a billenty�zetr�l */
   do {
     s=toupper(getch());
     switch (s) {
	case '1': /* felv�tel kezdete*/
	     szalag = fopen("SZALAG.DAT","wb");
	     if (szalag){
		setfillstyle(SOLID_FILL, LIGHTRED);
		bar(100, getmaxy()-100, 150, getmaxy()-50);
		record = ON;
	     }
	     else
		ungetch('X');
	     break;
	case '2': /* felv�tel v�ge */
	     if (record) {
		 fclose(szalag);
		 setfillstyle(SOLID_FILL, getbkcolor());
		 bar(100, getmaxy()-100, 150, getmaxy()-50);
		 record = OFF;
	     }
	     break;
	case '3': /* visszaj�tsz�s */
	     szalag = fopen("SZALAG.DAT","rb");
	     if (szalag) {
		 setfillstyle(SOLID_FILL, LIGHTGREEN);
		 bar(100, getmaxy()-100, 150, getmaxy()-50);
		while ((ch=getc(szalag))!=EOF){
		   hang(ch);
		   delay(100);
		}
		fclose(szalag);
		 setfillstyle(SOLID_FILL, getbkcolor());
		 bar(100, getmaxy()-100, 150, getmaxy()-50);

	     }
	     break;

	case 'X': /* kil�p�s */
	     break;

	default:
	    if(teszt(s)) hang(i);
     }
   } while(s!='X');

   /* a grafika kikapcsol�sa */
   closegraph();
   restorecrtmode();
   return 0;
}

char teszt(char s)   /*billentyu teszt */
{
   static char minta[]="AWSDRFTGHUJIKOL";
   for(i=0; i<strlen(minta); i++)
      if(s==minta[i]) return 1;
    return 0;
}

int hang(int i)
{
  static int hm[15]={440,477,512,550,587,623,660,697,
		     733,770,808,843,880,955,1026};
  delay(0);
  sound(hm[i]);
  delay(200);
  nosound();
  if (record) putc(i, szalag);
  return 0;
}















