#include <stdio.h>

void cime(int ** pp, int* p)
{
   *pp = p;
}

main()
{
  int a=4730;
  int *ap;

  printf("A h�v�s el�tt:a=%d\n", a);

  cime(&ap, &a);
  *ap += 13;

  printf("A h�v�s el�tt:a=%d\n", a);
}

