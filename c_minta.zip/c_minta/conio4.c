/*  CONIO4.C */
#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <string.h>
#include <dos.h>

int str_to_int(char *s, int *code);

void main()
{
   int       adat, hiba, x, y;
   char      ch, sz[20];
   textmode(C40);
   textbackground(CYAN);
   clrscr();
   textcolor(RED);
   gotoxy(2,5);
   cputs("Adat beolvas�sa billenty�zetr�l");
   do
   {
      do
      {
        textcolor(WHITE);
        gotoxy(2,10);
	      cputs("Adat: ");
	      textcolor(YELLOW); clreol();
	      x = wherex(); y = wherey();
	      gets(sz);
	      adat= str_to_int(sz, &hiba);
	      if (hiba)
	      {
	        gotoxy(x+4,y+1);
          textcolor(RED+BLINK);
          cputs("Hib�s adat!");
          textcolor(YELLOW);
          cputs(" Nyomj Sz�k�zt!");
          sound(100); delay(200);
          nosound();
          getch();
          gotoxy(2,10); delline();
        }
      }while (hiba);
      do
      {
        gotoxy(2,12);
        textcolor(BLACK);
        cputs("Akarja jav�tani (i/n): "); ch = getch();
        ch= toupper(ch);
      }while ((ch !='I') && (ch !='N'));
      gotoxy(2,12); delline();
   }while (ch != 'N');
   gotoxy(3,12);
   cprintf("%d",adat);
}

int str_to_int(char *s, int *hiba)
{
int i,n,sign;
    *hiba = 0;
    if(strcmp(s,"") == 0) { *hiba = 1; return 0;}
    for(i = 0; s[i] ==' ' || s[i] == '\n' || s[i] == '\t'; i++);
    sign = 1;
    if(s[i] == '+' || s[i] == '-') sign = (s[i++] == '+') ? 1: -1;
    for( n = 0; s[i] != '\0'; i++)
     if (s[i] >= '0' && s[i] <= '9') n = 10*n + s[i] - '0';
     else { *hiba = 1; return 0; }
  return(sign*n);
}
