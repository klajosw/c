/* RASTER.C */
#include <stdlib.h>
#include <conio.h>
#include <graphics.h>

void main()
{
    int gd, gm, xd, yd, i;
    double xc ,yc;

    clrscr();
    cprintf("\n Az oszlopok sz�ma : ");
    cscanf("%d",&xd);
    cprintf("\n\n A sorok sz�ma     : ");
    cscanf("%d",&yd);
    getch();

    detectgraph(&gd,&gm);
    if (gd!=EGA && gd!=VGA)
		{
		 cputs("\nCsak EGA, vagy VGA grafik�val rendelkez� g�pen futtathat�!\n");
		 exit(1);
		}

    initgraph(&gd,&gm,"");

    xc=(getmaxx()+1.0) / xd;
    yc=(getmaxy()+1.0) / yd;

    setcolor(LIGHTGREEN);
    setlinestyle(DOTTED_LINE,0,NORM_WIDTH);

   for(i=0; i<xd; i++)
      line(i*xc,0,i*xc,getmaxy());
   line(0, getmaxy(),getmaxx(), getmaxy());

   for(i=0; i<yd; i++)
      line(0,i*yc,getmaxx(),i*yc);
   line(getmaxx(), 0 ,getmaxx(), getmaxy());

    getch();
    closegraph();
}


