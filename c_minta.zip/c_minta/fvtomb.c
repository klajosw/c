/* FVTOMB.C */

#include <stdio.h>

typedef void prfv(char * p);

prfv p0;
prfv p1;
prfv q0;
prfv ures;

/* A feldolgozand� programr�szlet */
char *prog[]={ "P0 100,300",
	       "P1 Hello",
	       "P2 100,LEFT",
	       "P0 200,500",
	       "Q1 500",
	       "P1 Bye",
	       "Q0 "};
main()
{
   prfv * fvt[26][10];
   int i, j, n;


   /* Inicializ�l�s:  ures */
  for (i = 0; i < 26; i++ )
      for (j = 0; j < 10; j++ )
	  fvt[i][j] = ures;

  fvt['P'-'A']['0'-'0'] = p0;
  fvt['P'-'A']['1'-'0'] = p1;
  fvt['Q'-'A']['0'-'0'] = q0;

  /* A program feldolgoz�sa */
  n=sizeof(prog)/sizeof(prog[0]);
  for ( i = 0; i < n; i++ )
      fvt[ prog[i][0]-'A' ][ prog[i][1]-'0' ] (&prog[i][3]);
}

/* A parancsf�ggv�nyek defin�ci�ja */
prfv ures
{
  printf("**** �rv�nytelen parancs ****\n");
}

prfv p0
{
  int a,b;
  sscanf(p, "%d,%d", &a, &b);
  printf("%d + %d = %d\n", a, b, a+b);
}

prfv p1
{
  printf("%s\n", p);
}

prfv q0
{
  printf("--- A feldolgoz�s v�ge ---\n");
}
