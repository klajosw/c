/* REKORD2.C */
typedef union{
	       int w;
	       struct {
			char lo;
			char hi;
		      } b;
	       } szo;
	 szo xc;
 main()
 {
 }