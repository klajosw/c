/* KARIR.C */
#include <stdio.h>
#include <conio.h>

void bin_ckiir(char c);
main()
{
  int c;
  printf("\nKarakter le�t�se (q karakter a kil�p�s)\n");
  do {
     c = getch();
     bin_ckiir(c);
  } while (c != 'q');
}
void bin_ckiir(char c)
{
  int k;
  for(k = 128; k > 0; k /= 2)
    if( c & k) printf("1 ");
     else printf("0 ");
  printf("  %c  %d\n",c,c);
 return;
}

