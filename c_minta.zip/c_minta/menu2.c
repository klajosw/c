#include <stdio.h>
#include <conio.h>

/* A men� defin�ci�ja */

char * menu[] = { "\n",
		  "1. Beolvas",
		  "2. Sz�mol",
		  "3. Ki�r",
		  "----------",
		  "0. Kil�p" ,
		  "\n",
		  NULL };


/* Glob�lis v�ltoz�k, k�z�s haszn�latra */
int a, b, c;


/* A men�pontnak megfelel� f�ggv�nyek defin�ci�ja */
void beolvas(void)
{
  printf("K�rek k�t sz�mot [a,b]: ");
  scanf("%d,%d",&a,&b);
}

void szamol(void)
{
  c = a + b;
}

void kiir(void)
{
  printf("%d + %d = %d\n", a, b, c);
}

main()
{
  char ch , **p;

  void (*menupont[3]) (void) = { beolvas, szamol, kiir };

  do
  {
      /* A men� ki�r�sa */
      p = menu;
      while (*p)
	 printf("%s\n", *p++);

      /* A v�lasz feldolgoz�sa */
      ch = getch();
      if (ch > '0' && ch < '4')
	 menupont[ch-'1'] ();
      else if (ch != '0')
	      putchar('\a');
  } while  (ch!='0');
}

