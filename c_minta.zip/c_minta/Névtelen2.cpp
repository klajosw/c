#include <stdio.h>
int sor = 0;
main()
{
#if defined(__STDC__) || VAXC
    sor = __LINE__;

    printf("The compilation circumstances of %s:\n",
           __FILE__);
    printf("Date of compilation: %s\n",__DATE__);
    printf("Time of compilation: %s\n",__TIME__);
    printf("Approximate length of 'main': %d\n",
           __LINE__ - sor);
#else
    printf("The compiler is not ANSI C/VAX-C compatible\n");
    printf("No way to identify compilation circumstances\n");
#endif
}
