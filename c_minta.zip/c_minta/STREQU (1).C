#include <stdio.h>
#include <string.h>

/* A f�ggv�ny protot�pusa */
int strequ(char *, char *, char **ps, char **pt);

main()
{

    char s1[32], s2[32];
    char *p1, *p2;

    /* Azonos sztringek */
    strcpy(s1,"C nyelv");
    strcpy(s2, s1);

    if (strequ(s1, s2, &p1, &p2))
       printf("A k�t sztring azonos!\n");
    else
       printf("A k�t sztring elt�r� r�szei: %s   %s \n", p1, p2);


    /* K�l�nb�z� sztringek */
    strcpy(s1, "Hello mindenki!");
    strcpy(s2, "Hello mindenhol!");

    if (strequ(s1, s2, &p1, &p2))
       printf("A k�t sztring azonos!\n");
    else
       printf("A k�t sztring elt�r� r�szei: %s   %s \n", p1, p2);

}

int strequ(char *s, char *t, char **ps, char **pt)
{
  int equ;
  *ps = s; /* *ps �s *pt a sztringekre mutatnak */
  *pt = t;
  /* A k�t sztring karakterenk�nti �sszehasonl�t�sa */
  /* legfeljebb az els� sztring v�g�ig              */
  while (( equ = (**ps == **pt)) && (**ps != 0))
  {
       ++*ps;   /* L�ptet�s a sztringekben */
       ++*pt;
  }
  return equ;
}



