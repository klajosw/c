/* OSZLOP.C */
#include <stdio.h>
#include <graphics.h>
#include <conio.h>
#include <string.h>

void oszlop(double w[],int n, char *sz);
int GetMin(double w[],int n);
int GetMax(double w[],int n);

void main()
{
double y[100];
int m,i;
char sz[80];
  clrscr();
  printf("Adatok beolvas�sa\n");
  printf("Az adatok sz�ma: "); scanf("%d",&m);
  for( i = 1; i <= m; i++)
  {
    printf("%3d .elem = ",i); scanf("%lf",&y[i]);
  }
  sz[0] = '\0';
  printf("\nA diagram fejl�ce: ");
  do {
    gets(sz);
  }while (sz[0] == '\0');
  oszlop(y,m,sz);
}

int GetMin(double w[],int n)  /* kiv�lasztja a minim�lis �rt�ket */
{
 int    i,imin;
 double min;
   min = w[1];
   for(i = 1; i <= n; i++)
     if(w[i] < min) { min = w[i]; }
   imin = min+0.5;
 return(imin);
}

int GetMax(double w[],int n)   /* kiv�lasztja a maxim�lis �rt�ket  */
{
 int    i,imax;
 double max;
   max = w[1];
   for(i = 1; i <= n; i++)
     if(w[i] > max) { max = w[i]; }
  imax = (int)(max + 0.5);
 return(imax);
}

void oszlop(double w[],int n,char sz[])
{
 char szam[10],szam1[10],buff[70];
 int i;
 double snorm;
 int tmax,tmin;
 int gd,gm;
 int color[6];
 int xm,ym,m,dx,tsz,xx1,yy1,xx2,yact;
 int x1,y1,x2,y2;
	 tmax = GetMax(w,n);
	 tmin = GetMin(w,n);
	 detectgraph(&gd,&gm);     /* a monitor automatikus detekt�l�sa */
	 switch(gd)
   {
    case 1:gm=CGAC1;
           color[1] = 1; color[2] = 2; color[3] = 3;
           break;
    case 3:gm=EGALO;
           color[1] = CYAN; color[2] = LIGHTRED; color[3] = BLUE;
           break;
    case 9:gm=VGALO;
           color[1] = CYAN; color[2] = LIGHTRED; color[3] = BLUE;
           break;
   }
  initgraph(&gd,&gm,"");     /* grafika inicializ�l�sa */
  xm = getmaxx();
  ym = getmaxy();
	setcolor(color[1]);
  if (gd == 1) setbkcolor(BLACK); else setbkcolor(WHITE);
  settextjustify(CENTER_TEXT,CENTER_TEXT);
  outtextxy( (int)(xm/2),10,sz);             /* fejl�c kiirat�sa */
	x1 = 40; y1 = 30; x2= xm-20; y2 = ym-15;
  if (gd == 1) {x1 = 10; x2 = xm-10; }
  setcolor(color[3]);
  settextjustify(LEFT_TEXT,BOTTOM_TEXT);
  sprintf(szam,"%6d",tmax);               /* maxim�lis �rt�k, */
  sprintf(szam1,"%6d",tmin);    /* minim�lis �rt�k kiirat�sa  */
  buff[0] = '\0';
  strncat(buff,"minimum: ",9);
  strncat(buff,szam1,6);
  strncat(buff,"     maximum: ",15);
  strncat(buff,szam,6);
  outtextxy(x1,28,buff);
	m = y2-y1-2;
	snorm=(double)m/((double)tmax);
  yact = y2-y1;
  if (gd == 1)
  {      /* sz�veg poz�cion�l�sa k�perny� t�pusonk�nt */
    tsz = (x2-x1-1)/n;
    xx2 = x1+2; tsz = tsz-3; dx = 3;
  }
  else
  {
    tsz = (x2-x1-1)/n;
    xx2 = x1+2; tsz = tsz-4; dx = 4;
  }
  setcolor(color[1]);
	x2 = x1+n*(tsz+dx)+dx+2;
  setcolor(color[1]);
  rectangle(x1,y1,x2,y2+2);
  window(x1,y1,x2,y2);
  setfillstyle(1,color[2]);
  for(i = 1; i <= n; i++)
  { /* adatok �br�zol�sa oszlopokkal */
    xx1 = xx2+dx;
    yy1 = y1+yact-(int)(w[i]*snorm+0.5);
    xx2 = xx1+tsz;
    setcolor(color[1]);
    bar(xx1,yy1,xx2,y2);
		rectangle(xx1,yy1,xx2,y2);
    sprintf(szam,"%2d",i);
    setcolor(color[1]);
    if( gd == 1)
    {  /* oszlopsorsz�mok kiirat�sa */
      if (n < 25)
      {
        settextstyle(SMALL_FONT,HORIZ_DIR,1);
        setusercharsize(13,12,14,17);
        outtextxy(xx1+1,y2+10,szam);
      }
    }
    else
    if (n < 31) { outtextxy(xx1+5,y2+12,szam); }
	} /* ha az adatok sz�ma nagyobb 30-n�l, csak az els�  */
    /* �s az utols� sorsz�m ker�l kiirat�sra            */
  if((gd == 1) && (n > 24) || (gd != 1) && (n > 30))
  {
    outtextxy(x1+3,y2+13,"1");
    sprintf(szam,"%3d",n);
    outtextxy(xx2-22,y2+13,szam);
  }
  getch();         /* egy billenty� le�t�s�re v�r */
 closegraph();           /* grafikus m�d lez�r�sa       */
 return;
}
