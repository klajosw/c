/* GRHANOI.C */

#include <conio.h>
#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <dos.h>

#define  MAXKORONG  10

void PalcaRajz(int ith);
void KorongRajz(int Korong, int Sh, int Lathato );
void Honnan_Hova_Mozgatas(char, char);
void Hanoi(int, char, char, char);


typedef unsigned char byte;

enum  Palca {bal, kozepso, jobb};
enum {FALSE, TRUE};

byte L[MAXKORONG+1] = {0,140,128,116,104,92,80,68,56,44,32};
byte PalcaTomb[3][MAXKORONG+1];
int DelayTime;


void main()
{
    int gd, gm, error;
    int  i;
    int  KorongSzam;

    detectgraph(&gd,&gm);
    initgraph(&gd,&gm,"");
    error = graphresult();
    if (error != grOk) {
     printf("\n%s\n",grapherrormsg(error));
     exit(-1);
   }
   restorecrtmode();

   printf("\nA korongok sz�ma (max. 10): ");
   scanf("%d", &KorongSzam);
   printf("\nV�rakoz�si id� : ");
   scanf("%d", &DelayTime);
   printf("\n");
   setgraphmode(getgraphmode());

   for (i=0; i<=2; i++) PalcaRajz(i);

   for (i=1; i<=KorongSzam; i++) {
	  PalcaTomb[bal][i] = i;
	  PalcaTomb[bal][0] = i;
	  KorongRajz(i, 0, TRUE);
   }

   PalcaTomb[bal][0]     = KorongSzam;
   PalcaTomb[kozepso][0] = 0;
   PalcaTomb[jobb][0]    =0;

   Hanoi(KorongSzam, bal, kozepso, jobb);

   getch();
   closegraph();
   restorecrtmode();
}

void PalcaRajz(int ith)
{   int k;

    k = 200*ith;
    line( 35+k, 350, 185+k, 350);
    line(109+k, 100, 109+k, 350);
    line(111+k, 100, 111+k, 350);
};

void KorongRajz(int Korong, int Sh, int Lathato )
{
   int Center, x1, x2, y1, y2;

   if (Lathato)
      setcolor(16-Korong);
   else
      setcolor(getbkcolor());
   Center = 110 + Sh*200;
   x1 = Center - L[Korong] / 2;
   x2 = Center + L[Korong] / 2;

   Korong=PalcaTomb[Sh][0];
   y1 = 350 - Korong *23;
   y2 = 350 - (Korong-1)*23-1;
   rectangle(x1,y1,x2,y2-1);
}

void Hanoi(int n, char honnan, char mivel, char hova)
{
    if (n == 1)
       Honnan_Hova_Mozgatas(honnan, hova);
    else {
	Hanoi(n-1, honnan, hova, mivel);
	Honnan_Hova_Mozgatas(honnan, hova);
	Hanoi(n-1, mivel, honnan, hova);
     }
} /* Hanoi */

void Honnan_Hova_Mozgatas(char innen, char ide)
{
    KorongRajz(PalcaTomb[innen][PalcaTomb[innen][0]], innen, FALSE);
    PalcaTomb[ide][0]++;
    PalcaTomb[ide][PalcaTomb[ide][0]]=PalcaTomb[innen][PalcaTomb[innen][0]];
    PalcaTomb[innen][0]--;
    KorongRajz(PalcaTomb[ide][PalcaTomb[ide][0]], ide, TRUE);
    delay(DelayTime);
}  /* Honnan_Hova_Mozgatas */;





