/* HAROMSZ.C */
#include <stdio.h>
#include <math.h>
void olvas(double*, double*, double*);
double terulet(double, double, double);
double kerulet(double, double, double);

main()
{
double a1,b1,c1,ter1,ker1;
   olvas(&a1,&b1,&c1);
   ter1=terulet(a1,b1,c1);
   ker1=kerulet(a1,b1,c1);
   printf("A h�romsz�g ter�lete: %8.2lf\n",ter1);
   printf("A h�romsz�g ker�lete: %8.2lf\n",ker1);
}

void olvas(double *a, double* b, double* c)
{
double x1,x2,x3;
  printf("\nA h�romsz�g oldalai\n");
  for(;;)
  {
    printf("A oldal : "); scanf("%lf",&x1);
    printf("B oldal : "); scanf("%lf",&x2);
    printf("C oldal : "); scanf("%lf",&x3);
    *a=x1; *b=x2; *c=x3;

    if( ((*a+*b) > *c ) && ((*a+*c) > *b ) && ((*b+*c) > *a))
       {  break; }
       else printf("Hib�s adat!\n\n");
  }
}

double terulet(double a, double b,double c)
{
double s;
    s=(a+b+c)/2.;
    return(sqrt(s*(s-a)*(s-b)*(s-c)));
}

double kerulet(double a, double b, double c)
{
  return(a+b+c);
}
