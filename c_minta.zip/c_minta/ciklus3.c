/* CIKLUS3.C */
#include <stdio.h>
#include <math.h>

main()
{
int     i,j,x;
double  d,y;

  for (j = 1; j <= 12; j++)
  {
    printf("j     = %2d\n", j);
    printf("j*j   = %4d\n", j*j);
    printf("j*j*j = %6d\n", j*j*j);
  }

  for( i = 15, x = i; i > -100; i -= 15)
  {
    x += i;
    printf("x = %4d i = %4d\n",x,i);
  }
  d = 5;
  for(y = d/2; fabs(y*y-d) > 0.07; y = (y+d/y)/2.0);
  printf("y = %lf\n",y*y-d);
}