/*------------------------------------------------------*/
/*                         TITKOS.C                     */
/*						        */
/* Adott file tartalm�nak titkos�t�sa adott kulcssz�val */
/*						        */
/*------------------------------------------------------*/

#include <stdio.h>
#include <fcntl.h>
#include <graphics.h>
#include <conio.h>
#include <stdlib.h>
#include <dos.h>

#define EOS  '\0'

void error(char *);

/*-----------------*/
/* A main f�ggv�ny */
/*-----------------*/
main(int argc, char *argv[])
{
    int c;
    char *p;
    FILE * fin, *fout;

    if (argc !=4 ) {
       fputs("Haszn�lat: TITKOS forr�s_file c�l_file kulcssz�\n\n",stderr);
       error("Hib�s argumentumok!");
    }

    fin   = fopen(argv[1],"rb");
    if (!fin) error("Hib�s a forr�s file!");

    fout  = fopen(argv[2],"wb");
    if (!fin) error("Hib�s a forr�s file!");

    p= *(argv+3);

    while((c=fgetc(fin))!=EOF)
     {
      c^=*p++;
      if(*p==EOS)
	p= *(argv+3);
      putc(c, fout);
     }

   flushall();
   fcloseall();

   exit(0);
}


/*-------------*/
/* Hibakezel�s */
/*-------------*/
void error(char *text)
{
  fprintf(stderr, "\a%s\n\n", text);
  fputs("B�rmely billenty�re kil�p ... \n",stderr);
  getch();
  exit(1);
}
