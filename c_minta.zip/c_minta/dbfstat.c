/********************************************************************
**  dBASE file strukturajanak listazasa
**
**  Hasznalata:  DBFSTAT dbasefile-nev
********************************************************************/

#include <stdio.h>
#include <alloc.h>
#include <string.h>
#include <stdlib.h>

#include "dbf.c"

main(int argc,char *argv[])
{
        int errornum;
        int i,j;
        struct DBF *d;
        struct FIELD_RECORD *f;

        if(argc < 2)
                {
                printf("\nHasznalat: DBFSTAT dbasefile-nev\n");
                exit(1);
                }

        d = (struct DBF *)malloc(sizeof(struct DBF));

        for(j=1;j<argc;j++)
        {
        strcpy(d->filename,argv[j]);
        if(!strchr(d->filename,'.'))
                strcat(d->filename,".DBF");
        if((errornum = d_open(d))!=0)
        {
        printf("File nyitasi hiba: ");
        switch (errornum)
        {
                case OUT_OF_MEM:
                        printf("Nincs eleg memoria\n");
                        break;
                case NO_FILE:
                        printf("A %s file nem talalhato.\n",d->filename);
                        break;
                case BAD_FORMAT:
                        printf("A %s file nem DBF file.\n",d->filename);
                        break;
        }

        continue;
        }

        printf("\nA file neve     : %s\n",d->filename);
        printf("A header hossza : %-u\n",d->header_length);
        printf("Mezok szama     : %-u\n",d->num_fields);
        if (d->dbf_version == DB3FILE)
           printf("Verzio          : dBASE III\n");
        else
           printf("Verzio          : dBASE III Memo mezovel\n");
        printf("Utolso iras     : %02u/%02u/%2u\n",
                d->update_mo,d->update_day,d->update_yr);
        printf("Rekordok szama  : %-u\n",d->records);
        printf("Rekordhossz     : %-u\n",d->record_length);

        f = d->fields_ptr;
        printf("\n\n        FILE STRUKTURA\n");
        printf("\n  # MEZONEV  TIPUS  HOSSZ   DEC");
        printf("\n--------------------------------\n");
        for(i=1;i<=d->num_fields;++i,f++)
           printf("%3u %-12s %c  %3u   %3u\n",i,
                   f->name,f->typ,f->len,f->dec);
        printf("\n\n\n\n");
        d_close(d);
        }
        free(d);
        exit(0);
}

