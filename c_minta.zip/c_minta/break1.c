#include <stdio.h>

main()
{
  char *q = "      A C programoz�si nyelv";
  char *p;

  for (p = q; *p!='\0'; p++)
       if (*p != ' ') break;

  printf("%s\n", p);
}



