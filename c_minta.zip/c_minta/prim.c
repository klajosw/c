/* PRIM.C */
#include <stdio.h>
#include <math.h>

int prime(int n);

main()
{
int n;
  printf("\nPrimsz�m vizsg�lat\n");

  printf("K�rem a sz�mot = "); scanf("%d",&n);
  if (prime(n))
       printf("\n   %d primsz�m \n",n);
  else printf("\n   %d nem primsz�m\n",n);
}

int prime(int n)
{
int sqrtn, oszto, osztja;
   if( n <= 0) return 0;
   sqrtn = sqrt(n)+1;	/* C-ben automatikus konverzi� van ! */
   if (n < 4) return 1; /* Csak 2 es 3 lehet; 1-re nincs �rtelme */
   oszto = 2;
   osztja = !(n % oszto); /* ha osztja, m�d = 0 -> nem lehet prim */
   if (osztja) return 0; /* megvan az eredm�ny! */
    else oszto = 3;      /* mostant�l csak p�ratlannal osztunk */
   while (!osztja && (oszto <= sqrtn))
   {
     osztja = !(n % oszto);
     if (osztja)
	return 0;      /* osztotta, teh�t nem prim, return */
     else
	oszto+=2;      /* k�vetkez� p�ratlan sz�m          */
   }
   /* ha id�ig eljut a vez�rl�s, biztos primsz�m volt  */
   return 1;          /* visszat�r�si �rt�k: logikai IGAZ (!0) */
 }
