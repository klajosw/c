//--------------------------------include---------------------------------
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <alloc.h>
//----------------------------------typedef-------------------------------
typedef struct akarmi{
                      char magy[30];
                      char ang[30];
                      struct akarmi *kov;
                      }rek ;
typedef	rek *mutato;
//------------------glob�lisovaty---declaration---------------------------
void HOZZATOLT(int);       // �j elem bevitele a mem�ri�ba
void KERES(char *,int);    // keres�s a mem�ri�ban
void ELOHOZ();             // Mem�ria �p�t�se lemez alapj�n
void ELMENT();             // Mem�riament�s lemezre
void ABLAK0();             // Kezel�fel�let
void ABLAK1();             // Magyarr�l angolra
void ABLAK2();             // Angolr�l magyarra
void ABLAKigen();          // Igen/nem
void ABLAKnem();           // Nem/igen
mutato elso;
char szo[30],ertek[30];
//------------------------------------main-----------------------------------
void main(void)
{
char *forditas,ch;
int i,j,u;
ELOHOZ();
do
 {
  ABLAK1();i=0;
  do
   {
    fflush(stdin);
    u=getch();
    if (i==0) i=1;else i=0;
    if (i==1) ABLAK2();
    if (i==0) ABLAK1();
   }
  while  (u!=13);
  ABLAK0();
  if (i==1) j=1; else j=2;
  cprintf(" K�rem a");  if (j==1) cprintf(" magyar sz�t: ");
  if (j==2) cprintf("z angol sz�t: ");
  scanf("%s",szo);
  KERES(szo,j);
  if (strcmp(ertek,"xxx")==0) HOZZATOLT(j);
                                 else {gotoxy(5,3);cprintf("%s -> %s",szo,ertek);}
  gotoxy(10,4);cprintf("Folytatod? ");
  ABLAKigen();i=0;
  do
   {
    u=getch();
    if (i==1) i=0;
              else i=1;
    if (i==1) ABLAKnem();
              else ABLAKigen();
   }
  while (u!=13);
  if (i==0) ch='y';
            else ch='a';
 }
while (ch != 'y');
ELMENT();
}
//---------------------------------hozzatolt--------------------------------
void HOZZATOLT(int j)
{
 mutato uj;
 gotoxy(1,2);cprintf("Sajnos a sz�t nem ismerem.Felveszem a sz�t�ramba:");
 if (elso==NULL)
  {
   uj=(rek*)malloc(sizeof(rek));
   elso=uj;
   elso->kov=NULL;
  }
   else
  {
   uj=(rek*)malloc(sizeof(rek));
   uj->kov=elso->kov;
   elso->kov=uj;
	}
 gotoxy(5,3);
 if (j==1) {cprintf(" angolul: ");  scanf("%s",uj->ang);strcpy(uj->magy,szo);}
 if (j==2) {cprintf(" magyarul: ");  scanf("%s",uj->magy);strcpy(uj->ang,szo);}
}
//----------------------------------keres----------------------------------
void KERES(char szo[30],int j)
{
strcpy(ertek,"xxx");
mutato p;
p=elso;
while (p!=NULL)
 {
  switch (j)
   {
    case 1: if (strcmp(p->magy,szo)==0) strcpy(ertek,p->ang);
    case 2: if (strcmp(p->ang,szo)==0) strcpy(ertek,p->magy);
   }
  p=p->kov;
 }
}
//-----------------------------elohoz----------------------------------
void ELOHOZ()
{
 FILE *fp;
 rek adat;
 mutato p,uj;
 fp=fopen("szavak.dat","r");
 if (fp!=NULL)
  {
   uj=(rek*)malloc(sizeof(rek));
   elso=uj;
   while (!feof(fp))
		{
		 if (!feof(fp))
			{
			 p=uj;
			 fread(&adat,sizeof(rek),1,fp);
			 strcpy(p->magy,adat.magy);
			 strcpy(p->ang,adat.ang);
			 uj=(rek*)malloc(sizeof(rek));
			 p->kov=uj;
			}
    } // while
   p->kov=NULL;
   free(uj);
  } //if else
  else {elso=NULL;}
 fclose(fp);
}
//--------------------------------elment----------------------------------
void ELMENT()
{
 FILE *fp;
 rek adat;
 mutato p,elozo;
 fp=fopen("szavak.dat","w");
 p=elso;
 while (p!=NULL)
  {
   strcpy(adat.magy,p->magy);strcpy(adat.ang,p->ang);
   fwrite(&adat,sizeof(rek),1,fp);
   elozo=p;
   p=p->kov;
   free(elozo);
  }
 fclose(fp);
}
//---------------------------------ablak1-----------------------------------
void ABLAK1()
{
 ABLAK0();
 textcolor(BLINK);cprintf("                Mit ford�tsak? \n");
 textcolor(MAGENTA);
 printf("\n");
 gotoxy(5,4);textbackground(GREEN);cprintf("Magyarr�l->Angolra");
 gotoxy(30,4);textbackground(CYAN);cprintf("Angolr�l->Magyarra");
}
//----------------------------------ablak2---------------------------------
void ABLAK2()
{
 ABLAK0();
 textcolor(BLINK);   cprintf("                Mit ford�tsak? \n"     );
 textcolor(MAGENTA);
 printf("\n");
 gotoxy(5,4);textbackground(CYAN);cprintf("Magyarr�l->Angolra");
 gotoxy(30,4);textbackground(GREEN);cprintf("Angolr�l->Magyarra");
}
//---------------------------------ablak0----------------------------------
void ABLAK0()
{
 window(1,1,80,25);     textbackground(4);       clrscr();
 window(3,2,78,24);     textbackground(BLACK);   clrscr();
 window(15,9,64,10);    /*highwideo;*/   textbackground(BLUE);    clrscr();
 textcolor(WHITE);
 cprintf("            -----SZ�T�RPROGRAM-----       ");
 window(15,10,64,14);   textbackground(CYAN);   clrscr();
}
//---------------------------------ablakigen-----------------------------
void ABLAKigen()
{
 window(31,14,35,14);   textbackground(GREEN);    clrscr();
 textcolor(BLINK);
 printf("IGEN");
}
//---------------------------------ablaknem------------------------------
void ABLAKnem()
{
 window(31,14,35,14);   textbackground(RED);    clrscr();
 textcolor(BLINK);
 printf(" NEM");
}
//-------------------------------v�ge--------------------------------------
//=========================================================================
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++