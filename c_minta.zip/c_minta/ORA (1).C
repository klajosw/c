/*-----------------------------------------------------------*/
/*                          ORA.C                            */
/*                                                           */
/*      Id� kijelz�se megszak�t�s rutin seg�ts�g�vel         */
/*                                                           */
/*  ! A ford�t�skor a SMALL modell haszn�lata javasolt  !    */
/*-----------------------------------------------------------*/

#ifndef __SMALL__
#error A forditaskor a SMALL modell hasznalata javasolt!
#endif

#include <dos.h>
#include <stdio.h>

/* A r�gi id�z�t� c�m�nek elt�rol�sa */
void interrupt (*oldtimer)(void);

/* Az �j id�z�t� rutin */
void interrupt newtimer(void);

int vmode(void);

extern unsigned _heaplen=1024; /* def 0= maximum */
extern unsigned _stklen =512;  /* def 4K */

/* glob�lis seg�dv�ltoz�k */
unsigned intsp;
unsigned intss;
unsigned tsrss;
unsigned stack;

static union REGS regs;
static struct SREGS seg;
unsigned vseg;

struct date datum;
struct time ido;

int fut = 0;
char puffer[25];
unsigned v;

char formatum [] = " %4d.%02d.%02d %02d:%02d:%02d ";
int utem = 0;

/*-----------------------*/
/*  A main f�ggv�ny      */
/*-----------------------*/
main()
{
    /* ------ a rezidens program verme -------- */
    segread(&seg);
    tsrss  = _SS;
    stack =  _SP;

    /* --------- a 0x1c vektor �t�ll�t�sa -------- */
    oldtimer = getvect(0x1c);
    setvect(0x1c, newtimer);

    /* ---- A sz�veges k�perny� szegmens�nek meghat�roz�sa ---- */
    vseg = vmode() == 7 ? 0xb000 : 0xb800;

    /* ---- Az aktu�lis id� �s d�tum ------ */
    gettime(&ido);
    getdate(&datum);

    /* ------ t�rrezidens kil�p�s ------- */
    keep(0,_SS+((_SP+100)/16) - _psp);
}

/*-------------------------*/
/*  A videom�d lek�rdez�se */
/*-------------------------*/
int vmode(void)
{
  union REGS regs;
  regs.h.ah = 15;
  int86(16, &regs, &regs);
  return regs.h.al;
}


/*--------------------------*/
/*  Az �j megszak�t�s rutin */
/*--------------------------*/
void interrupt newtimer(void)
{
 /* A r�gi rutin megh�v�sa */
 (*oldtimer)();
 /* Ha nem fut �ppen, a sz�ks�ges l�p�sek elv�gz�se */
 if (fut == 0)	{
    fut = 1;

    /* A stack be�ll�t�sa */
    disable();
    intsp = _SP;
    intss = _SS;
    _SP = stack;
    _SS = tsrss;
    enable();

    /* Az id� �ll�t�sa a timer �teme alapj�n */
    if (utem == 0) {
       utem = (((ido.ti_sec % 5) == 0) ? 19 : 18);
       ido.ti_sec++;                 /* m�sodperc */
       if (ido.ti_sec == 60)	{
	  ido.ti_sec = 0;
	  ido.ti_min++;             /* perc */
	  if (ido.ti_min == 60)	{
	     ido.ti_min = 0;
	     ido.ti_hour++;         /* �ra */
	     if (ido.ti_hour == 24)
		ido.ti_hour = 0;
          }
       }
       /* A kijelz�si form�tum al��ll�t�sa */
       sprintf(puffer, formatum, datum.da_year, datum.da_mon, datum.da_day,
	       ido.ti_hour, ido.ti_min, ido.ti_sec);
    }
    --utem;

    /* Kijelz�s */
    for (v = 0; v < 21; v++)
	    pokeb(vseg, (58 + v) * 2, 0x7000 + puffer[v]);

    /* A verem visszall�t�sa */
    disable();
    _SP = intsp;
    _SS = intss;
    enable();
    fut = 0;
 }
}

