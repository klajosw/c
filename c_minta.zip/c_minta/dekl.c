/* DEKL.C */
typedef char maxptr[256];
typedef char *strptr;

char   nev[81];
maxptr puffer;
char   cim[41];
strptr ptr;

main()
{
}