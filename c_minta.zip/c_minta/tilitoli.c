/* Fazekas Ruck Andrea: TILITOLI.C  */

/*=========================================================================*/

#include	<stdlib.h>
#include	<conio.h>
#include	<ctype.h>
#include	<time.h>
#include	<dos.h>

/*=========================================================================*/

#define	byte			unsigned char
#define word			unsigned int
#define	dword			unsigned long int
#define	SZEL			5
#define	MAG			5
#define	X0			((82-1-SZEL*9)/2)
#define	Y0			((27-1-MAG*4)/2)
#define	KEVER			1000
#define	EOS			'\0'
#define	ESC			0x1B

/*===========================================================================

Ir�nyok:
	0 = fel
	1 = le
	2 = balra
	3 = jobbra

===========================================================================*/

void	jatek(void);
void	rajzol(void);
void	kever(void);
void	tologat(void);
void	tol(word d);

/*=========================================================================*/

word    tabla[SZEL][MAG];
char	tar1[64];
char	tar2[256];
char	conv[16];
word	xpos,ypos;
word	timing;

/*=========================================================================*/

void	main()
{
	randomize();
	textattr(0x11);
	clrscr();
	jatek();
	textattr(7);
	clrscr();
} /* end main() */

/*=========================================================================*/

void	jatek(void)
{
	rajzol();
	xpos=SZEL-1;
	ypos=MAG-1;
	getch();
	kever();
	tologat();
} /* end jatek() */

/*=========================================================================*/

void	rajzol(void)
{
	register word x,y;

	textattr(0x70);
	y=Y0;
	for(y=Y0;y<=Y0+MAG*4;y++) {
		gotoxy(X0,y);
		if(y==Y0) {
			cputs("�");
		} else {
			if(y==Y0+MAG*4) {
				cputs("�");
			} else {
				if(((y-Y0)&3)==0) cputs("�"); else cputs("�");
			} /* end if-else */
		} /* end if-else */
		for(x=1;x<=SZEL;x++) {
			if(y==Y0) {
				if(x<SZEL) cputs("���������"); else cputs("�������Ŀ");
			} else {
				if(y==Y0+MAG*4) {
					if(x<SZEL) cputs("���������"); else cputs("���������");
				} else {
					if(((y-Y0)&3)==0) {
						if(x<SZEL) cputs("���������"); else cputs("�������Ĵ");
					} else {
						cputs("        �");
					} /* enbd if-else */
				} /* end if-else */
			} /* end if-else */
		} /* end for */
	} /* end for */
	for(x=0;x<SZEL*MAG-1;x++) {
		gotoxy(X0+4+9*(x%SZEL)+(x<9),Y0+2+4*(x/SZEL));
		itoa(x+1,conv,10);
		cputs(conv);
		tabla[x%SZEL][x/SZEL]=x+1;
	} /* end for */
	tabla[SZEL-1][MAG-1]=0;
	textattr(0x4F);
	for(y=Y0+(MAG-1)*4+1;y<Y0+MAG*4;y++) {
		gotoxy(X0+(SZEL-1)*9+1,y);
		cputs("        ");
	} /* end for */
	textattr(0x70);
   gotoxy(80,25);
} /* end rajzol() */

/*=========================================================================*/

void	kever(void)
{
	register word n;

	timing=0;
	for(n=0;n<KEVER;n++) tol(random(4));
	while(xpos<SZEL-1) tol(3);
	while(ypos<MAG-1) tol(1);
} /* end kever() */

/*=========================================================================*/

void	tologat(void)
{
	register word n,m;
	char c;

	timing=1;
	while(1) {
		gotoxy(80,25);
		c=toupper(getch());
		if(c==ESC) break;
		if(c==EOS) {
			c=getch();
			switch(c) {
				case	0x48:
					tol(0);
					break;

				case	0x50:
					tol(1);
					break;

				case	0x4B:
					tol(2);
					break;

				case	0x4D:
					tol(3);
					break;
			} /* end switch */
			while(kbhit()) getch();
		} /* end if */
		c=0;
		for(m=0;m<MAG;m++) {
			for(n=0;n<SZEL-(m==MAG-1);n++) {
				if(tabla[n][m]!=1+m*SZEL+n) c=1;
			} /* end for */
		} /* end for */
		if(!c) {
			textattr(0x4F);
			gotoxy(35,1);
			cputs("Gratul�lok !");
			while(kbhit()) getch();
			getch();
			break;
		} /* end if */
	} /* end while */
} /* end tologat() */

/*=========================================================================*/

void	tol(word d)
{
	register word i,j;
	word n,m;
	word t;

	d&=3;
	n=X0+9*(xpos-(d==2))+1;
	m=Y0+4*(ypos-(d==0))+1;
	if(d&2) j=9; else j=4;
	for(i=0;i<j;i++) {
		if(i&&timing) delay(20);
		switch(d) {
			case	0:		/* fel */
				if(!ypos) break;
				gettext(n,m,n+7,m,tar1);
				gettext(n,m+1,n+7,m+7,tar2);
				puttext(n,m,n+7,m+6,tar2);
				puttext(n,m+7,n+7,m+7,tar1);
				if(i+1==j) {
					t=tabla[xpos][ypos];
					tabla[xpos][ypos]=tabla[xpos][ypos-1];
					tabla[xpos][ypos-1]=t;
					ypos--;
				} /* end if */
				break;

			case	1:		/* le */
				if(ypos>=MAG-1) break;
				gettext(n,m+7,n+7,m+7,tar1);
				gettext(n,m,n+7,m+6,tar2);
				puttext(n,m+1,n+7,m+7,tar2);
				puttext(n,m,n+7,m,tar1);
	    if(i+1==j) {
					t=tabla[xpos][ypos];
					tabla[xpos][ypos]=tabla[xpos][ypos+1];
					tabla[xpos][ypos+1]=t;
					ypos++;
				} /* end if */
				break;

			case	2:		/* balra */
				if(!xpos) break;
				gettext(n,m,n,m+2,tar1);
				gettext(n+1,m,n+17,m+2,tar2);
				puttext(n,m,n+16,m+2,tar2);
				puttext(n+17,m,n+17,m+2,tar1);
	    if(i+1==j) {
					t=tabla[xpos][ypos];
					tabla[xpos][ypos]=tabla[xpos-1][ypos];
					tabla[xpos-1][ypos]=t;
					xpos--;
				} /* end if */
				break;

			case	3:		/* jobbra */
				if(xpos>=SZEL-1) break;
				gettext(n+17,m,n+17,m+2,tar1);
				gettext(n,m,n+16,m+2,tar2);
				puttext(n+1,m,n+17,m+2,tar2);
				puttext(n,m,n,m+2,tar1);
	    if(i+1==j) {
					t=tabla[xpos][ypos];
					tabla[xpos][ypos]=tabla[xpos+1][ypos];
					tabla[xpos+1][ypos]=t;
					xpos++;
				} /* end if */
				break;
		} /* end switch */
	} /* end for */
} /* end tol() */

/*=========================================================================*/
