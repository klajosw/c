#include<stdio.h>
#include<math.h>
double hatvany(double,double);
void main()
{
    double a,b;
		printf("alap ?\n");
		scanf("%lf",&a);
		printf("kitevo?\n");
		scanf("%lf",&b);
		printf("az eredmeny:%8.4lf\n",hatvany(a,b));
}
double hatvany(double a,double b)
{
   double fv;
   if(a>0 && b>=0)
   {
      if(b==0)
      {
         fv=1;
      }
      else
      {
          fv=(exp(b*log(a)));
      }
      return fv;
   }
   else
   {
			printf("hibas adatbevitel\n");
			exit(-1);
			return 0;

   }
}








