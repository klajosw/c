
#include <stdio.h>
#include <stdlib.h>

#define NELEM1 50
#define NELEM2 100

main()
{
  double **pp1, **pp2;
  int i , j;

  /* Helyfoglal�s ellen�rz�ssel */

  /* A mutat�vektorok l�trehoz�sa */
  pp1 = (double **) calloc( NELEM1 , sizeof(double *));
  pp2 = (double **) calloc( NELEM1 , sizeof(double *));
  if (!pp1 || !pp2) {
     printf("\a\nNincs el�g mem�ria!\n");
     return -1;
  }

  /* Helyfoglal�s a k�tdimenzi�s t�mb sorai sz�m�ra */
  for (i = 0; i < NELEM1; i++) {
      pp1[i]   = (double *) calloc(NELEM2, sizeof(double));
      *(pp2+i) = (double *) calloc(NELEM2, sizeof(double));
      if (!pp1[i] || !pp2[i]) {
         printf("\a\nNincs el�g mem�ria!\n");
         return -1;
      }
  }

  /* Az 1. m�trix felt�lt�se v�letlen sz�mokkal */
  for (i = 0; i < NELEM1; i++)
    for (j = 0; j < NELEM2; j++)
        *(pp1[i] + j) = random(10000)*1.234;

  /* Az 1. m�trix 10-szeres�nek m�sol�sa a 2. m�trixba */
  for (i = 0; i < NELEM1; i++)
    for (j = 0; j < NELEM2; j++)
        pp2[i][j] = *( *(pp1+i) + j) * 10.0;

  /* A lefoglalt ter�letek felszabad�t�sa */

  /* A t�mb sorainak felszabad�t�sa */
  for (i = 0; i < NELEM1; i++) {
      free(pp1[i]);
      free(*(pp2+i));
  }
  /* A mutat�vektorok felszabad�t�sa */
  free(pp1);
  free(pp2);
}


