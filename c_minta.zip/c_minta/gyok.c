/* GYOK.C */
#include <stdio.h>
#include <math.h>

main()
{
 double  uj, regi, x;

 printf("Gy�kvon�s\n");
 printf(" A sz�m  : "); scanf("%lf",&x);
 /* A gy�kvon�s ciklusa */

 for(uj = x/2, regi = 0.0; fabs(regi-uj) > 0.001;
      regi = uj, uj = 0.5*(regi+x/regi));

 printf(" A gy�ke : %lf\n",uj);
}
