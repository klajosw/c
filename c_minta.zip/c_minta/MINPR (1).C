/* MINPR.C */
#include <stdio.h>
int amin(int a[], int n)
{
 int min = a[1], i;
 for(i = 2; i < n; i++)
   if( a[i] < min) min = a[i];
 return min;
}

main()
{
 int b[] = { 1, 2, 3, -1, 0, 2 };
 int mini;

 mini = amin(b,6);
 printf("mini = %d\n",mini);
}