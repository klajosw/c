/*******************************************************************/
/*                          BEEP.C                                 */
/*               Hanggener�l�s C programb�l                        */
/*******************************************************************/

#include <dos.h>

void beep(int,int);

/* A tesztel� f�program */
main()
{
  int i;
  for (i = 10;i < 700;i += 50)
   beep(400+i,i/5);

  for (i = 700;i > 10;i -= 50)
   beep(400+i,i/5);
}

/* A hanggener�l� f�ggv�ny */

#define TMODE  182        /* timer m�d �ll�t�sa */
#define FSCALE 1190000L   /* timer frekvencia   */
#define TSCALE 1230L
#define TMODEP 67
#define FREQP  66
#define BEEPP  97

void beep(int voice,int time)
{
  int hibyt, lobyt, port;
  long i,count,divisor;

    divisor = FSCALE/voice;
        lobyt   = divisor % 256;
        hibyt   = divisor /256;

    count   = TSCALE * time;

        outp(TMODEP,TMODE);
        outp(FREQP,lobyt);
        outp(FREQP,hibyt);

    port=inp(BEEPP);
        outp(BEEPP,port | 3);

        for (i=0; i<count; i++);

        outp(BEEPP,port & ~3);
}

