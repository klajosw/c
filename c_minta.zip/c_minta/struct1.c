#include <stdio.H>

struct book {
	       char nev[20];
	       char cim[40];
	       int ev;
	       float ar;
	     };

main()
{
   struct book  wb;

   /* Az adatok beolvas�sa */
   printf("\nK�rem a k�nyv adatait!\n\n");
   printf(" Szerz�     : ");    gets( wb.nev );
   printf(" C�m        : ");    gets( wb.cim );
   printf(" Kiad�s �ve : ");    scanf("%d", &wb.ev );
   printf(" �r (Ft)    : ");    scanf("%f", &wb.ar );

   /* Az adatok megjelen�t�se */

   printf("\nA k�nyv adatai :\n\n");
   printf("Szerz�     :  %s\n", wb.nev );
   printf("C�m        :  %s\n", wb.cim );
   printf("Kiad�s �ve :  %4d\n", wb.ev );
   printf("�r         :  %5.2f Ft\n", wb.ar );


}
