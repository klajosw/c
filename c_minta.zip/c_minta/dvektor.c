
#include <stdio.h>
#include <stdlib.h>
#define NELEM 1000

main()
{
  double *pd, sv;
  int i , j, lepes;

  /* Helyfoglal�s ellen�rz�ssel */
  pd = (double *) calloc( NELEM, sizeof(double));
  if (! pd) {
     printf("\a\nNincs el�g mem�ria!\n");
     return -1;     /* Hiba t�rt�nt */
  }

  /* A t�mb felt�lt�se v�letlen sz�mokkal */
  for (i = 0; i < NELEM; i++)
      *(pd + i) = random(10000)*12.34;

  /* Shell - rendez�s */
  for (lepes = NELEM/2; lepes >0;  lepes /=2)
     for (i = lepes; i < NELEM; i++)
       for (j=i-lepes; j>=0 && pd[j]>pd[j+lepes]; j-=lepes)
        {
            sv         =  pd[j];
            pd[j]      =  pd[j+lepes];
            pd[j+lepes]=  sv;
        }

  /* A lefoglalt ter�let felszabad�t�sa */
  free(pd);

  return 0;        /* Hib�tlan volt a program fut�sa */
}

