/* CIKLUS2.C */
#include <stdio.h>

main()
{
  int  a, b, c;
  do {
       printf("a �rt�ke:");
       scanf("%d",&a);
     }
  while ( a < -5 || a > 5); /* kil�p, ha a felt�tel hamis */
}

