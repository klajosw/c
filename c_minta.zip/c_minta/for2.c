#include <stdio.h>
#include <conio.h>
#include <ctype.h>

main()
{
  int i, j, valasz;
  char kesz = ' ';

  printf("\nSzorz�t�bla program\n\n");
  for (i = 1; i < 10 && kesz != 'N'; i++)
  {
    for (j = 1; j < 10; j++)
    {
       printf ("Mennyi %d * %d ? ",i ,j);
       scanf("%d", &valasz);
       if (valasz != i * j)
           printf("hib�s\n");
       else
           printf("helyes\n");
     }
     printf("\nTov�bb? ");
     kesz = toupper(getche());
     printf("\n");
   }
}

