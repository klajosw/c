// nincs meg kesz

#include<stdio.h>;
#include<alloc.h>;
#include<stdlib.h>;
#include<conio.h>;
#include<math.h>;
void fileir();                                  /* feltolti a "kapuk.dat" file-t */
double aram(double, double, double *);              /* kiszamolja az aramot */
double deltaU(double, double, double *,int*,int*);  /* feszultsegeses rekurzivan */
void fileolvas(int*);                           /* beolvassa a "kapuk.dat" file-t */

main()
{
 double P=800000;           /* a mozdony felvett teljesitmenye */
 double U0=27500;           /* uresjarasi feszultseg */
 double *pdU;                /* a pillanatnyi feszultsegeses */
 char foly;
 int *t;                   /* a kapuk parameterei */
 int *szaml;

 clrscr();
 printf("Akarsz negypolusokat beolvasni? (y) ");   scanf("%c%c",&foly);
			 if (foly=='y') fileir();
 
 t=(int*)malloc(8*sizeof(int));
 fileolvas(t); 
 for(int i=0;i<8;i++) printf("\n%d",t[i]);
 *pdU=0.0;   *szaml=0;       /* kezdeti ertekadas */

 double temp=deltaU(P,U0,pdU,t,szaml);
 printf("\nA feszultsegeses: %lf",temp);
 free(t);
 printf("\n%d load-flow tortent",*szaml);
}



void fileir()
	{ 
		int A1,B1,C1,D1,A2,B2,C2,D2;
		FILE *fp;
		fp=fopen("kapuk.dat","wt");
		clrscr();
		printf("Az elso kapu:\n");
		printf("\nA1= ");   scanf("%d",&A1);
		printf("\nB1= ");   scanf("%d",&B1);
		printf("\nC1= ");   scanf("%d",&C1);
		printf("\nD1= ");   scanf("%d",&D1);
		printf("\nA masodik kapu:\n");
		printf("\nA2= ");   scanf("%d",&A2);
		printf("\nB2= ");   scanf("%d",&B2);
		printf("\nC2= ");   scanf("%d",&C2);
		printf("\nD2= ");   scanf("%d",&D2);
	 fprintf(fp,"%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n",A1,B1,C1,D1,A2,B2,C2,D2);
	 fflush(fp);  fclose(fp);
	 }  

void fileolvas(int *tm)      /* a tombmutatot allitja az adott ertekre */
 {
	 FILE *fpo;                /* file pointer */
	 if (!(fpo=fopen("kapuk.dat","r")))
			{ fprintf(stderr,"Sikertelen file megnyitas!\n"); exit(-1);	 }
	 fflush(fpo);
	 for (int j=0;j<8;j++)	 fscanf(fpo,"%d\n",tm+j); 
	 fclose(fpo);
 }
	

double aram(double P, double U0, double *pdU)
			 { return P/(U0 - *pdU);}



double deltaU(double P, double U0, double *pdU, int *tp, int *szamlalop)
 {
	 A1a=tp[0]; A1a=tp[0]; A1a=tp[0]; A1a=tp[0]; 
	 A1a=tp[0]; A1a=tp[0]; A1a=tp[0]; A1a=tp[0];
	 
	 A0a=tp[0];A1a=tp[0]; A1a=tp[0]; A1a=tp[0];   
   A1a=tp[0]; A1a=tp[0]; A1a=tp[0]; A1a=tp[0]; 

	 (*szamlalop)++;
	 printf ("\n%d. load-flow utan  %lf\n",*szamlalop,*pdU);
	double I=aram(P,U0,pdU); 
	double elozodU = *pdU;

	*pdU= I* *(tp+1)+I* *(tp+6);                              /* ez kamu */

	if ( abs(*pdU-elozodU) > 1.0) deltaU(P,U0,pdU,tp, szamlalop);
	 return (*pdU);  
 }
 