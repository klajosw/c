#include <stdio.h>
#include <stdlib.h>

void main()
{
	FILE * forras;
	FILE * cel;
	int ch, i;

	forras=fopen("c:\\felix\\nevsor2.txt", "rt");
	if (forras==NULL)
		{
		fprintf(stderr, "Sikertelen file-nyitasi kiserlet!\n");
		exit(-1);
		}
	cel=fopen("c:\\felix\\nevsor3.txt", "wt");

	i=0;

	while (!feof(forras))
	{ 
		ch=fgetc(forras);
		if (ch==10)
		{
			if (i==0)	{fputc(ch, cel); i=1;}
			else i=0;
		}
	}
	fflush(cel);
	fclose(cel); fclose(forras);
}