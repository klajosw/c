#include <stdio.h>
#include <mem.h>
#include <alloc.h>
#include <dos.h>

#include "dbf.h"

/* a teszt main() forditasahoz az alabbi makro szukseges
#define  DEBUG_MAIN                                     */


/********************************************************************
**  Rekord toltese a dBASE III file-bol a DBF.record_prt altal
**  mutatott teruletre
**
**  Hasznalata:
**              d = (struct DBF *)malloc(sizeof(struct DBF));
**              strcpy(d->filename,"filename.dbf");
**              d_open(d);
**              d_getrec(d,(long)rekordszam);
**              ... a rekord tartalmanak elerese ...
**              d_close(d);
**              free(d);
**
**  return:     0 - ha sikeres a vegrehajtas
**              RECNO_TOO_BIG   - ha a rekord nincs a file-ban
********************************************************************/

int d_getrec(struct DBF *d,unsigned long int r)
{
  if (r > d->records)
     return(RECNO_TOO_BIG);
  if (r > 0L)
     {
        fseek(d->file_ptr,((long)d->header_length +
                     ((r - 1L) * d->record_length)),0);
        fread(d->record_ptr,d->record_length,1,d->file_ptr);
        d->current_record = r;
        return(0);
     }
  return(RECNO_TOO_BIG);
}


/********************************************************************
**  Dbase III file rekordjainak file-ba irasa
**
**  Hasznalata:
**             d=(struct DBF *)malloc(sizeof(struct DBF));
**             strcpy(d->filename,"filename.dbf");
**             d_open(d);
**             d_getrec(d,(long)rekordszam);
**             ... a rekord modositasa ...
**             d_putrec(d,(long)rekordszam);
**             d_close(d);
**             free(d);
**
**  Megjegyzes:a rekord tartalmat a DBF.record_ptr azonositja
**
**  return:     0 - ha sikeres a vegrehajtas
**              RECNO_TOO_BIG   - ha a rekord nincs a file-ban
*********************************************************************/

int d_putrec(struct DBF *d,unsigned long int r)
{
  if (r > d->records)
     return(RECNO_TOO_BIG);
  if (r > 0L)
     {
        fseek(d->file_ptr,((long)d->header_length +
                    ((r - 1) * d->record_length)),0);
        fwrite(d->record_ptr,d->record_length,1,d->file_ptr);
        d->status = updated;
     }
  d->current_record = r;
  return(0);
}


/********************************************************************
**  A kivalasztott rekordmezo  sztringkent torteno pufferbe irasa
**
**  Hasznalata:
**              d = (struct DBF *)malloc(sizeof(struct DBF));
**              strcpy(d->filename,"filename.dbf");
**              d_open(d);
**              d_getrec(d,(long)rekordszam);
**              d_getfld(d,mezoszam,buffer);
**              ... a mezo adatainak hasznalata ...
**              d_close(d);
**              free(d);
**
**  return:     a mezo tipusat ,ha sikeres
**              null ha nem sikeres
********************************************************************/

char d_getfld(struct DBF *d,int f,char *buff)
{
  struct FIELD_RECORD *fp;
  if (f > 0 && f <= d->num_fields)
     {
        fp = d->fields_ptr + (f - 1);
        memcpy(buff,fp->field_data_address,fp->len);
        buff[fp->len] = '\0';
        return(fp->typ);
     }
  else
     {
        buff[0]='\0';
        return('\0');
     }
}


/*********************************************************************
**  Rekordmezo pufferbol valo feltoltese
**
**  Hasznalata:
**              d = (struct DBF *)malloc(sizeof(struct DBF));
**              strcpy(d->filename,"filename.dbf");
**              d_open(d);
**              d_getrec(d,(long)rekordszam);
**              d_getfld(d,mezoszam,buffer);
**              ... mezo adatinak modositasa
**              d_putfld(d,mezoszam,buffer);
**              d_putrec(d,(long)rekordszam);
**              d_close(d);
**              free(d);
**
**  return:     sikeres esetben a mezo hosszat,
**              0 -t sikertelen esetben
*********************************************************************/

int d_putfld(struct DBF *d,int f,char *buff)
{
  struct FIELD_RECORD *fp;

  if (f > 0 && f <= d->num_fields)
     {
        fp = d->fields_ptr + (f - 1);
        memcpy(fp->field_data_address,buff,fp->len);
        return(fp->len);
      }
  else
      {
        return(0);
      }
}

/********************************************************************
**  Letezo dBASE III file megnyitasa
**
**  Hasznalata:
**              d = (struct DBF *)malloc(sizeof(struct DBF));
**              strcpy(d->filename,"filename.dbf");
**              d_open(d);
**              ... a file elerese mas fuggvenyekkel ...
**              d_close(d);
**              free(d);
**
**  returns: 0 - sikeres megnyitas eseten, kulonben
**           NO_FILE    - ha a file nem talalta meg
**           OUT_OF_MEM - ha nincs eleg memoria
**           BAD_FORMAT - ha nem dBASE file
********************************************************************/

int d_open(struct DBF *d)
{
  int i;
  int n;

  d->status = not_open;
  if ((d->file_ptr = fopen(d->filename,"r+b")) == NULL)
     return(NO_FILE);

  rewind(d->file_ptr);

  fread((void *)&d->dbf_version,(unsigned)1,(unsigned)12,d->file_ptr);

  /* Dbase III file ? */
  if (    d->dbf_version != DB3FILE
       && d->dbf_version != DB3WITHMEMO
       || d->update_mo == 0)
        {
                fclose(d->file_ptr);
                return(BAD_FORMAT);
        }

  d->current_record = 0L;
  d->num_fields = ((d->header_length - (FIELD_REC_LEN+1))
                  / HEADER_PROLOG);

  if ((d->fields_ptr = (struct FIELD_RECORD *)
      malloc((unsigned)(d->num_fields * FIELD_REC_LEN)))==NULL)
                return(OUT_OF_MEM);

  /* pozicionalas a mezoleirora */
  fseek(d->file_ptr,(long)HEADER_PROLOG,0);

  /* a mezoleiro beolvasasa */
  fread((void *)d->fields_ptr,sizeof *d->fields_ptr,
        (unsigned)d->num_fields,d->file_ptr);

  if ((d->record_ptr = (char *)malloc(d->record_length))==NULL)
     return(OUT_OF_MEM);

  /* pointerek raallitasa a rekord mezoire */
  for (i=0,n=1;i<d->num_fields;i++)
      {
        d->fields_ptr[i].field_data_address = d->record_ptr + n;
        n += d->fields_ptr[i].len;
      }

  d->status = not_updated;  /* sikeres megnyitas */
  return(0);
}


/********************************************************************
**  Uj dBASE III file letrehozasa egy letezo file strukturajanak
**  felhasznalasaval
**
**  Hasznalata:
**      forras = (struct DBF *)malloc(sizeof(struct DBF));
**      cel     = (struct DBF *)malloc(sizeof(struct DBF));
**      strcpy(forras->filename,"forras.dbf");
**      strcpy(cel->filename,"cel.dbf");
**      d_open(forras);
**      d_cpystr(forras,cel);
**      d_close(forras);
**      d_close(cel);
**      free(forras);
**      free(cel);
**
**  Megjegyzes: A DBASE megfeleloje a fuggvenynek:
**              USE SOURCE
**              COPY STRUCTURE TO DEST
**
**  return: 0 - sikeres esetben, kulonben
**          NO_FILE     - a file nem talalhato
**          OUT_OF_MEM  - nincs eleg memoria
********************************************************************/

int d_cpystr(struct DBF *s,struct DBF *d)
{
  struct FIELD_RECORD *f;
  int i;
  int n;

  /* Meg van-e nyitva a forras file ? */
  if (s->status != not_updated && s->status != updated)
     return(NO_FILE);

  d->status = not_open;

  if ((d->file_ptr = fopen(d->filename,"w+b")) == NULL)
     return(NO_FILE);

  if((d->fields_ptr = (struct FIELD_RECORD *)
      malloc(s->num_fields * FIELD_REC_LEN))==NULL)
      return(OUT_OF_MEM);

  memcpy(d->fields_ptr,s->fields_ptr,(s->num_fields * FIELD_REC_LEN));
  memcpy(&d->dbf_version,&s->dbf_version,12);
  d->records = 0L;
  d->current_record = 0;
  d->num_fields = s->num_fields;
  d->header_length=HEADER_PROLOG+(d->num_fields * FIELD_REC_LEN)+1;
  if ((d->record_ptr = (char *)malloc(d->record_length))==NULL)
     return(OUT_OF_MEM);

  for (i=0,n=1;i<d->num_fields;i++)
     {
        f = d->fields_ptr + i;
        f->field_data_address = d->record_ptr + n;
        n += f->len;
     }
  fwrite(&d->dbf_version,1,12,d->file_ptr);
  for (i=1;i<=20;i++)
         fwrite("\0",1,1,d->file_ptr);
  fwrite(d->fields_ptr,FIELD_REC_LEN,d->num_fields,d->file_ptr);
  fwrite("\x0d",1,1,d->file_ptr);
  d->status = updated;
  return(0);
}


/********************************************************************
**  dBASE III file lezarasa
**
**  Hasznalata:
**              d = (struct DBF *)malloc(sizeof(struct DBF));
**              strcpy(d->filename,"filename.dbf");
**              d_open(d);
**              ... a file elerese mas fuggvenyekkel ...
**              d_close(d);
**              free(d);
********************************************************************/

int d_close(struct DBF *d)
{
  union REGS inregs,outregs;
  if (d->status == updated)
     {
        /* a datum */
        inregs.h.ah=0x2a;
        intdos(&inregs,&outregs);
        d->update_day=outregs.h.dl;
        d->update_mo=outregs.h.dh;
        d->update_yr=outregs.x.cx-1900;

        /* pozicionalas a file elejere */
        rewind(d->file_ptr);
        /* a file header ujrairasa */
        fwrite(&d->dbf_version,1,12,d->file_ptr);

        /* pozicionalas a file vegere */
        fseek(d->file_ptr,0L,2);
        /* eof kiirasa */
        fwrite("\x1a",1,1,d->file_ptr);
     }

  free(d->fields_ptr);
  free(d->record_ptr);
  fclose(d->file_ptr);
}


/********************************************************************
**  Rekord hozzafuzese dBASE III file-hoz
**
**  Hasznalata:
**              d = (struct DBF *)malloc(sizeof(struct DBF));
**              strcpy(d->filename,"filename.dbf");
**              d_open(d);
**              ... a kivant adatok elhelyezese a memoriaba a
**                  d->record_ptr cimtol kezdve ...
**              d_addrec(d);
**              d_close(d);
**              free(d);
********************************************************************/

int d_addrec(struct DBF *d)
{
  fseek(d->file_ptr,((long)d->header_length +
        (d->records * d->record_length)),0);
  fwrite(d->record_ptr,d->record_length,1,d->file_ptr);
  d->current_record = ++d->records;
  d->status = updated;
  return(0);
}


/********************************************************************
**  Rekord feltoltese szokozokkel a memoriaban
**
**  Hasznalat:
**              d = (struct DBF *)malloc(sizeof(struct DBF));
**              strcpy(d->filename,"filename.dbf");
**              d_open(d);
**              d_blank(d);
**              d_addrec(d);
**              d_close(d);
**              free(d);
/********************************************************************

int d_blank(struct DBF *d)
{
  memset(d->record_ptr,'\x20',d->record_length);
  return(0);
}


/* teszt program, ha DEBUG_MAIN szimbolum definialt */

#ifdef DEBUG_MAIN

main(int argc,char **argv)
{
struct DBF d;
int errornum;
int i;

if (argc != 2)
        {
        printf("Hasznalat: DBF dbasefile-nev");
        exit(1);
        }

strcpy(d.filename,argv[1]);
if(!strchr(d.filename,'.'))  strcat(d.filename,".DBF");
if((errornum = d_open(&d))!=0)                                                                                           /* open file                                                   */
{
        printf("File nyitasi hiba: ");
        switch (errornum)
        {
           case OUT_OF_MEM:
                   printf("Nincs eleg memoria.\n");
                   break;
           case NO_FILE:
                   printf("A %s file nem letezik.\n",d.filename);
                   break;
           case BAD_FORMAT:
                   printf("A %s file nem dBASE III file.\n",d.filename);
                   break;
       }
        exit(1);
}

printf("\nA file neve    : %s",d.filename);
printf("\nAktualis rekord: %ld",d.current_record);
printf("\nDBF szignatura : %d",d.dbf_version);
if (d.status==not_updated)
        printf("\nAllapot - nem modositott\n");
else
        printf("\nAllapot - nem nyitott\n");
printf("\nMezok szama    : %d",d.num_fields);
printf("\nModositas eve  : %d",d.update_yr);
printf("\nModositas hava : %d",d.update_mo);
printf("\nModositas napja: %d",d.update_day);
printf("\nRekordok szama : %ld",d.records);
printf("\nRekordhossz    : %d\n",d.record_length);
for (i=0;i<d.num_fields;i++)
        printf("\n%d. mezo : %s",i,d.fields_ptr[i].name);
}
#endif
