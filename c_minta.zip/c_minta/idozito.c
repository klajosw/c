/*---------------------------------------------------------*/
/*                      IDOZITO.C                          */
/*             						   */
/*   8254 id�z�t� (timer) haszn�lata 1 ms pontoss�ggal	   */
/*---------------------------------------------------------*/

#include <dos.h>
#include <stdio.h>
#include <stdlib.h>

#define ZERO_FLAG	0x040
#define CONTROL_C	3
#define MS_PER_TICK	53	/* az IBM PC �r�j�nak �teme */
#define TIMER_IT        8

unsigned long count, count0;
unsigned ticks;
void interrupt timer(), interrupt (*old_handler)(void);

/*---------------------*/
/*   A main f�ggv�ny   */
/*---------------------*/
main()
{
	union REGS sreg, rreg;

	/* az id� null�r�l indul */
	count = count0 = 0;
	ticks = 0;

	/* BIOS szint� billnty�zetolvas�s inicializ�l�sa */
	sreg.x.dx = 0xff;
	sreg.h.ah = 0x06;

	printf("\nKil�p�s a programb�l: CTRL-C.");
	printf("\nM�s billenty� lenyom�sakor kb. 1 ms pontoss�ggal,\n");
	printf("\nkijelzi a program az ind�t�sa eltelt id�t (ms).\n\n");

	/* Az eredeti timer megszak�t�s rutin */
	old_handler = getvect(TIMER_IT);

	/* Az �j rutin be�ll�t�sa */
	setvect(TIMER_IT, timer);

	/* Az IRQ0 hardveres megszak�t�s enged�lyez�se */
	outportb(0x21, inportb(0x21) & 0xfe);

	/* A timer m�k�d�se m�dj�nak be�ll�t�sa (mode 2)*/
	outportb(0x43, 0x34);

	/* A sz�ml�lt �rt�k be�ll�t�sa:               */
	/* 0x4cd * 813.8 ns = 1 ms (LSB, MSB sorrend) */
	outportb(0x40, 0xcd); /* LSB */
	outportb(0x40, 0x04); /* MSB */

	while (1) {
		/* v�rakoz�s billenty�nyom�sra */
		while ( 1 ) {
			intdos(&sreg, &rreg);
			if ( ! (rreg.x.flags & ZERO_FLAG) )
				break;
	    	}

		/* Ctrl-C  eset�n a program meg�ll�t�sa */
		if ( (rreg.x.ax & 0xff) == CONTROL_C ) {
			/* A Timer vissza�ll�t�sa az IBM PC-n */
			/* szok�sos �llapot�ra                */
			outportb(0x43, 0x34);
			outportb(0x40, 0);
			outportb(0x40, 0);

			/* A megszak�t�s vektor vissza�ll�t�sa */
			setvect(8, old_handler);

			printf("Siekeres kil�p�s!\n");
			exit(0);
		}
		else  {
			/* Az eltels id� ki�r�sa */
			printf("A program %lu ms id� �ta fut\n",count);
			printf("A k�t billenty�nyom�s k�z�tt eltelt id� %lu ms\n",count-count0);
			count0 = count;
	       }
	}
}

/*----------------------------*/
/*  A timer f�ggv�ny  - INT 8 */
/*----------------------------*/
void interrupt
timer()
{
	count++;

	/* A r�gi megszak�t�s rutin megh�v�sa az MS-DOS �ltal haszn�lt */
	/* �temez�snek megfelel�en                                     */
	if (++ticks == MS_PER_TICK) {
		old_handler();
		ticks = 0;
	}

	/* A megszak�t�s v�g�nek jelz�se a 8259 chip fel� */
	outportb(0x20, 0x20);
}
