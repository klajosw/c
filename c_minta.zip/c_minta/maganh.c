/* MAGANH.C */
#include <stdio.h>
#include <string.h>

main()
{
char sz[80];
char c;
int  n,a,o,i,e,u,j;
  printf("K�rem a sz�veget\n:");
  gets(sz);
  n = strlen(sz);
  a = o = i = e = u = 0;
  for( j = 0; j < n; j++)
  {
    c = sz[j];
    switch (c)
    {
     case 'a':
     case 'A': a++;
	       break;
     case 'o':
     case 'O': o++;
	       break;
     case 'i':
     case 'I': i++;
	       break;
     case 'e':
     case 'E': e++;
	       break;
     case 'u':
     case 'U': u++;
	       break;
    }
  }
  printf("Mag�nhangz� statisztika:\n");
  printf("   a,A: %d\n",a);
  printf("   e,E: %d\n",e);
  printf("   i,I: %d\n",i);
  printf("   o,O: %d\n",o);
  printf("   u,U: %d\n",e);
}

