#include <stdio.h>                  /* El�ford�t� utas�t�sok     */
#define  EGY   1
#define  KETTO 2

extern int sum(int, int);           /* Glob�lis defin�ci�k �s     */
int e;                              /* deklar�ci�k                */

main()                             /* A main f�ggv�ny defin�ci�ja */
{
  int a,b;                         /* Lok�lis defin�ci�k �s      */
				   /* deklar�ci�k                */

  a=EGY; b=KETTO;                  /* Utas�t�sok */
  e=sum(a,b);
  printf("Az �sszeg: %d\n",e);
}

