/* MOZOG.C */
#include <conio.h>
#include <graphics.h>
#include <math.h>
#include <stdlib.h>

void page(int *);
void mozog(int *,int,int,int,int,int);

void main()
{
  int Gd, Gm;
  int Active;
  int Hibakod;

  Gd = EGA;     /* vga    */
  Gm = EGAHI;   /* vgamed */
  initgraph(&Gd, &Gm,"");
  Hibakod = graphresult();
  if (Hibakod)
   {
    clrscr();
    cprintf("Grafikus hiba: %s",grapherrormsg(Hibakod));
    exit(1);
   }

  cleardevice();
  setvisualpage(0);
  setactivepage(1);
  cleardevice();
  Active = 1;
  setbkcolor(BLUE);
  mozog(&Active,100, 100, 500, 300, 30);
  mozog(&Active,500, 300, 100, 100, 10);
  mozog(&Active,500, 100, 100, 300, 10);
  mozog(&Active,100, 300, 500, 100, 10);
  mozog(&Active,100, 100, 100, 300, 10);
  mozog(&Active,100, 300, 100, 100, 10);
  mozog(&Active,100, 100, 500, 300, 30);
  mozog(&Active,500, 300, 100, 100, 10);
  closegraph();
}

void page(int *Active)
{
    setvisualpage(*Active);
    *Active = 1 - *Active;
    setactivepage(*Active);
    cleardevice();
}

void mozog(int *Active, int X0,int Y0,int X1,int Y1,int V0)
{
  int Vx, Vy, T, X, Y;
  double  Dx, Dy, S0;

    Dx = (double)(X1 - X0); Dy = (double)(Y1 - Y0);
    S0 = sqrt(Dx * Dx + Dy * Dy);
    Vx = (int)(V0 * Dx / S0 + 0.5 );
    Vy = (int)(V0 * Dy / S0 + 0.5);
    T = 0;
    X = X0; Y = Y0;
    do
    {
      setcolor(RED);
      circle(X+2,Y+3,12);
      fillellipse(X, Y, 30,5);
      line(X-10,Y-10,X+2,Y+3);
      line(X+10,Y-10,X+2,Y+3);
      page(Active);
      X = X0 + T * Vx;
      Y = Y0 + T * Vy;
      T++;
    }while ((abs(T * Vx) < abs(Dx)) && (abs(T * Vy) < abs(Dy)));
  }
