#include <stdio.h>

/* x abszolut�rt�k�nek meghat�roz�sa */
#define abs(x)   ( (x) < 0 ? (-(x)) : (x) )

/* a �s b maximum�nak kisz�m�t�sa */
#define max(a,b) ( (a) > (b) ? (a) : (b) )

/* A �s B minimum�nak kisz�m�t�sa */
#define min(A,B) ( (A) < (B) ? (A) : (B) )

/* N�gyzetre emel�s */
#define sqr(x)   ( (x) * (x) )

/* K�t eg�sz objektum tartalm�nak felcser�l�se */
/* csak eg�sz bal�rt�k argumentummal m�k�dik helyesen */
#define swap(a,b) { int c; c = a, a=b, b=c; }

main()
{
 int a=-4, b=6;
				/* Eredm�nyek */
 printf("%d\t%d\n",a ,b);       /*   -4    6  */
 printf("%d\n", abs(a));        /*    4       */
 printf("%d\n", abs(b));        /*    6       */
 printf("%d\n", sqr(a));        /*   16       */
 printf("%d\n", min(a,b));      /*   -4       */
 printf("%d\n", max(a,b));      /*    6       */
 swap(a,b);
 printf("%d\t%d\n",a ,b);       /*    6    -4 */
}