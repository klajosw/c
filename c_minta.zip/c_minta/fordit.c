/* FORDIT.C */
#include <stdio.h>

main()
{
int  szam, i1, i2, i3, i4, n, k;

  printf("\nSz�m (max. 5 jegy�): "); scanf("%d",&szam);
  if( szam < 10000)
  {
    if( szam < 10) k = 1;
    else if( szam <100) k = 2;
    else if( szam < 1000) k =3;
    else if( szam < 10000) k = 4;
    i4 = -1; i3 = -1; i2 = -1; i1 = -1;
    switch (k)
    {
      case 4: i1 = szam / 1000;
	      i2 = (szam  % 1000) / 100;
	      i3 = (szam % 100) / 10;
	      i4 = szam % 10;
	      break;
      case 3: i1 = szam / 100;
	      i2 = (szam % 100) / 10;
	      i3 = szam % 10;
	      break;
      case 2: i1 = szam / 10;
	      i2 = szam % 10;
	      break;
      case 1: i4 =szam ;
    }
    n = 0;
    printf("A sz�mjegyek forditott sorrendben: ");
    if(i4 >= 0) { printf("%d",i4); n = 1; }
    if(n && i3 >= 0 ) printf("%d",i3);
    else if (i3 >= 0) { printf("%d",i3); n = 1; }
    if(n && i2 >=0 ) printf("%d",i2);
    else if (i2 >= 0) { printf("%d",i2); n = 1; }
    if (i1 >= 0) printf("%d",i1);
  }
}
