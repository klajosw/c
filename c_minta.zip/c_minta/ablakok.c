/* ABLAKOK.C */
#include <string.h>
#include <conio.h>
#include <alloc.h>
#include <stdlib.h>
#include <time.h>
#include <dos.h>

#define WAIT delay(1000);

#define WAITKBD while(!kbhit()); getch();

#define MAXWINDOW 100

struct savewin {
       char * save;
       int    x1,y1,x2,y2;
       int    cb,cp;
       } ;


signed stptr=-1;

struct savewin winfo[MAXWINDOW];


/* A keret felrajzol�sa a fejl�ccel */
/* -------------------------------- */

void keret(int x, int y, int u, int v, char *h)
{
int i,hx,wx;
char *sor;

  sor=(char *)malloc(80);
  if (!sor)
     {
      putch('\a');
      return;
     }
  memset(sor,205,u-x);

  sor[0]=201;
  sor[u-x]=187;
  sor[u-x+1]='\0';
  gotoxy(x,y);
  cputs(sor);

  sor[0]=200;
  sor[u-x]=188;
  gotoxy(x,v);
  cputs(sor);

  for (i=y+1;i<=v-1;i++)
      {
	gotoxy(x,i);putch(186);
	gotoxy(u,i);putch(186);
      }

     wx=u-x;
     hx=strlen(h);
     gotoxy(x+(wx-hx)/2+1 ,y);
     cputs(h);
     free(sor);
}


/* Az ablak elk�sz�t�se */
/* -------------------- */

void mkwin(int x1, int y1, int x2, int y2, int hatter,
	   int szoveg, char * fejlec)
{
  int wsize;
  char * wptr;

     window(1,1,80,25);
     wsize=(x2-x1+1)*(y2-y1+1);
     wptr=(char *)malloc(2*wsize);
     if (!wptr)
	{
	 putch('\a');
	 return;
	}
     gettext(x1,y1,x2,y2,wptr);

     winfo[++stptr].save=wptr;

     winfo[stptr].x1=x1;
     winfo[stptr].y1=y1;
     winfo[stptr].x2=x2;
     winfo[stptr].y2=y2;
     winfo[stptr].cb=hatter;
     winfo[stptr].cp=szoveg;


     textbackground(hatter);
     textcolor(szoveg);

     keret(x1,y1,x2,y2,fejlec);

     window(x1+1,y1+1,x2-1,y2-1);

     clrscr();
     gotoxy(1,1);
 }

/* A legfels� ablak lev�tele */
/* ------------------------- */

void killwin(void)
{
int x1,x2,y1,y2;

  if (stptr<0)
   {
    putch('\a');
    return;
   }

  x1=winfo[stptr].x1;
  y1=winfo[stptr].y1;
  x2=winfo[stptr].x2;
  y2=winfo[stptr].y2;

  puttext(x1,y1,x2,y2,winfo[stptr].save);
  free(winfo[stptr--].save);

  if (stptr>=0)
     {
	x1=winfo[stptr].x1;
	y1=winfo[stptr].y1;
	x2=winfo[stptr].x2;
	y2=winfo[stptr].y2;
	window(x1+1,y1+1,x2-1,y2-1);
	textbackground(winfo[stptr].cb);
	textcolor(winfo[stptr].cp);
      }
      else
	window(1,1,80,25);
}


void main()
{
  int i, hszin, bszin;
  char cim[]=" Win. ";
  int x,y;

  randomize();

  textbackground(BLACK);
  textcolor(LIGHTGRAY);
  clrscr();
  for (i=0; i<25; i++)
   { gotoxy(1,i+1);
     cprintf("\n%*cComputerBooks 1994",1+random(60),' ');
   }

  mkwin(1,1,80,24,1,7," Editing ");
  cputs("Editor");
  WAIT;

  mkwin(35,5,80,22,4,10," Linking ");
  cputs("Linker");
  WAIT;

  mkwin(10,10,50,20,3,14," Compiling ");
  cputs("Compiler");
  WAIT;

  mkwin(25,15,65,19,7,4," Running ");
  cputs("Running");
  WAIT;

  for (i=1;i<=4;i++)
  {
    gotoxy(2,2);
    cputs("Done");
    WAIT;
    killwin();
  }


  for(i=1;i<10;i++)
  {
    cim[4]='0'+i;
    hszin=1+random(15);
    bszin=15-hszin;
    x=i+random(34);
    y=i+random(2);
    mkwin(x,y,x+8+random(38-i),y+4+random(18-i),hszin,bszin,cim);
  }

  for(i=1;i<10;i++)
   {
     WAIT;
     killwin();
   }
}
