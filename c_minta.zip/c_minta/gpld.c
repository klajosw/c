/*  GPLD.C */
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>
#include <dos.h>

void main()
{
int Gd, Gm, Hibakod, x, y;
 /* A grafika bekapcsol�sa automatikus hardver �s m�d detekt�l�ssal */
 detectgraph(&Gd, &Gm);
 initgraph(&Gd, &Gm, "");

 /*  Ha nem siker�lt bekapcsolni a grafik�t kil�p�s a programb�l */
 Hibakod = graphresult();
 if (Hibakod != grOk)
   {
      cprintf("Grafika hiba: %s",grapherrormsg(Hibakod));
      exit(1);
   }

 /* A rajzol�si l�p�sek */

 setbkcolor(WHITE);

 setcolor(BLUE);
 x = 0;   y = getmaxy();
 do
 {
    line(0,0,x,y);
    x += 10;
 }while (x < getmaxx());

 setcolor(GREEN);
 x = getmaxx();  y = 0;
 do
 {
   line(getmaxx(),getmaxy(),x,y);
   x -= 10;
 }while (x > 0);

 setcolor(RED);
 rectangle(  getmaxx() / 4,  getmaxy() / 4,
	   3*getmaxx() / 4, 3*getmaxy() / 4);

 setfillstyle(SOLID_FILL,GREEN);
 floodfill(getmaxx() / 2, getmaxy() / 2, RED);

 settextstyle(TRIPLEX_FONT,HORIZ_DIR,4);
 outtextxy(  getmaxx() / 4, getmaxy() / 4,"      Turbo C");

 settextstyle(TRIPLEX_FONT,VERT_DIR,3);
 outtextxy(getmaxx() / 4, getmaxy() / 4,"Grafika");

 circle(getmaxx() / 2, getmaxy() / 2,60);
 arc(getmaxx() / 2 -30 ,getmaxy() / 2,180,0,30);
 arc(getmaxx() / 2 +30 ,getmaxy() / 2,0,180,30);
 setfillstyle(SOLID_FILL,RED);
 floodfill(getmaxx() / 2-30, getmaxy() / 2, RED);
 setfillstyle(SOLID_FILL, YELLOW);
 floodfill(getmaxx() / 2+30, getmaxy() / 2, RED);

 delay(4000);

 /* A grafika kikapcsol�sa �s a sz�veges �zemm�d vissza�ll�t�sa */
 closegraph();
 restorecrtmode();
}


