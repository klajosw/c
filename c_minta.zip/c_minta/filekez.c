#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
void main()
{
	 char esso;
	 clrscr();			
	 FILE *seged;
	 seged=fopen("C:\\TUC\\BIN\\ELSO.C","rt");
	 if(seged==NULL)
	 {
			printf("sikertelen megnyitas\n");
			exit(-1);
	 }
	 while((feof(seged))==0)
	 {
			esso=getc(seged);
			if(esso=='/')
			{
				 while(esso=getc(seged)!='/')
				 {
				 }
			}
			else
			{
					printf("%c",esso);
			}
	 }
	 fclose(seged);
}

