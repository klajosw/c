#include <stdio.h>
#include <conio.h>

/* A matematikai f�ggv�nyek t�pusa */
typedef double matfv(double x);

/* A tabl�z f�ggv�ny protot�pusa */
void tabloz(matfv *, double, double, double);

matfv sqr;       /* a saj�t f�ggv�ny protot�pusa */
matfv sqrt;      /* a k�nyvt�ri f�ggv�ny protot�pusa*/

main()
{
 printf("\n\nAz x� f�ggv�ny �rt�kei ( [-2,2] dx=0.5 )\n");
 tabloz(sqr, -2, 2, 0.5);
 getch();
 printf("\n\nAz �x f�ggv�ny �rt�kei ( [0,2] dx=0.2 )\n");
 tabloz(sqrt, 0, 2, 0.2);
 getch();
}

/* A tabl�z f�ggv�ny defin�ci�ja */
void tabloz(matfv *fp, double a, double b, double lepes)
{
  double x;
  for (x=a; x<=b; x+=lepes)
      printf("%13.5f \t %15.10f\n", x, (*fp)(x));
}

/* Az sqr f�ggv�ny defin�ci�ja */
matfv sqr
{
  return x * x;
}

