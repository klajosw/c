/* OLIMPIA.C */

#include <conio.h>
#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>

void main()
{
    int gd, gm, xc,yc,rc;
    struct palettetype  pal;

    detectgraph(&gd,&gm);
    if (gd!=EGA && gd!=VGA)
    {
	    printf("\nCsak EGA, vagy VGA grafik�val\n");
      printf("rendelkez� g�pen futtathat�!\n");
	    exit(1);
    }

    initgraph(&gd,&gm,"");
    getpalette(&pal);
    xc=getmaxx() / 2;
    yc=getmaxy() / 2;
    rc=getmaxy() / 5;
    setbkcolor(WHITE);

    /* A palett�ban a feh�r sz�n hely�n a fekete sz�n lesz */
    setpalette(15,0);

    /* A fekete karika */
    setcolor(WHITE);
    setlinestyle(SOLID_LINE,0,THICK_WIDTH);
    circle(xc,yc,rc);

    /* A k�k karika */
    setcolor(BLUE);
    setlinestyle(SOLID_LINE,0,THICK_WIDTH);
    circle(xc-2.3*rc,yc,rc);

    /* A piros karika */
    setcolor(RED);
    setlinestyle(SOLID_LINE,0,THICK_WIDTH);
    circle(xc+2.3*rc,yc,rc);

    /* A s�rga karika */
    setcolor(YELLOW);
    setlinestyle(SOLID_LINE,0,THICK_WIDTH);
    circle(xc-1.2*rc,yc+0.8*rc,rc);

    /* A z�ld karika */
    setcolor(GREEN);
    setlinestyle(SOLID_LINE,0,THICK_WIDTH);
    circle(xc+1.2*rc,yc+0.8*rc,rc);

    /* A k�k karika */
    setcolor(BLUE);
    setlinestyle(SOLID_LINE,0,THICK_WIDTH);
    arc(xc-2.3*rc,yc,330,30,rc);

    /* Az �tfed�sek megfelel� kialak�t�sa */
    setcolor(WHITE);
    setlinestyle(SOLID_LINE,0,THICK_WIDTH);
    arc(xc,yc,240,280,rc);
    setlinestyle(SOLID_LINE,0,THICK_WIDTH);
    arc(xc,yc,330,30,rc);

    setcolor(RED);
    setlinestyle(SOLID_LINE,0,THICK_WIDTH);
    arc(xc+2.3*rc,yc,240,280,rc);

    getch();
    setallpalette(&pal);
    getch();
    closegraph();
}


