#include <stdio.h>
#include <string.h>

char szo[8];
int  nbetu, nperm;

void swapnm(char, char);
void permut(int);

main()
{
 printf("\nK�rek egy max. 7 bet�s sz�t: ");
 gets(szo);
 nbetu = strlen(szo);
 nperm = 1;

 if (nbetu > 0 && nbetu <8)
    permut(nbetu-1);
}

void permut(int k)
{
 int i;
 for (i=0; i<=k; i++)
 {
   swapnm(i, k);
   if (k)
      permut(k-1);
   else
      printf("\n%3d - %s",nperm++, szo);
   swapnm(k, i);
 }
}

void swapnm( char n, char m)
{
    char z;
    z=szo[n];  szo[n]=szo[m]; szo[m]=z;
}

