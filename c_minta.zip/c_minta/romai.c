/* ROMAI.C */
#include <stdio.h>
#include <conio.h>

main()
{
int x,y;
   y=1;
   printf("\nR�mai sz�mok (1..2000):\n");
   printf("b�rmely billenty� le�t�se sz�ks�ges\n");
 do {
      x=y;
      printf("%4d : ",x);
      while (x>=1000){ printf("M"); x=x-1000;}
	if( x>=900) { printf("CM"); x=x-900; }
	if( x>=500) { printf("D"); x=x-500; }
	if( x>=400) { printf("CD"); x=x-400; }
      while (x>=100){ printf("C"); x=x-100;}
	if( x>=90) { printf("XC"); x=x-90; }
	if( x>=50) { printf("L"); x=x-50; }
	if( x>=40) { printf("XL"); x=x-40; }
      while (x>=10){ printf("X"); x=x-10;}
	if( x>=9) { printf("IX"); x=x-9; }
	if( x>=5) { printf("V"); x=x-5; }
	if( x>=4) { printf("IV"); x=x-4; }
      while (x>=1){ printf("I"); x=x-1;}
      printf("\n");
      if( y == 40) getch();
      if( y == 100) getch();
      if(y<20) y+=1;
	    else
	    if(y<100) y+=10;
		   else y+=100;

  }
  while (y <=2000);
}
