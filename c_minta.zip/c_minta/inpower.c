#include <stdio.h>

/*  A hatv�ny f�ggv�ny protot�pusa */
static double near inpower(double, int);

/* Interface az inpower f�ggv�nyhez, a mem�riamodellt�l
   f�gg a c�m�nek a t�pusa! */
double power(double, int);

main()
{
   int i;

   for (i=-5; i<6; i++)
       printf("2 ^%3d = %8.4lf\n", i, power(2.0,i));
}


static double near inpower(double x, int exp)
{

   if (!exp || !x)       /* ha 0 a kitev� vagy 0.0 az alap */
      return 1;
   else
   {
     if (exp < 0) {      /* ha negat�v a kitev� */
	 x = 1 /x;
	 exp = -exp;
      }
      return x*power(x, exp-1);
   }
}

double power(double x, int exp)
{
  return inpower(x, exp);
}
