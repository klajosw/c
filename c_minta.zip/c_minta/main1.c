#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[], char **envp)
{
  int i;
  char **p;

  printf("Az argumentumok sz�ma: %d\n\n",argc);

  for (i=0; i<argc; i++)
      printf("%d. argumentum: \"%s\"\n",i,argv[i]);

  printf("\n");
  p = envp;
  while (*p)
      printf("DOS k�rnyezeti v�ltoz�: \"%s\"\n",*p++);

  return (EXIT_SUCCESS);
}

