/* NAPTAR.C */
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <dos.h>
#include <conio.h>
#include <string.h>

#define PozKurzor(sor,oszlop) gotoxy((oszlop),(sor))

#define KICSI		3
#define NAGY		4


void Naptar( int, int, int, int, int, char *);
void Box( int, int, int, int );
void Vonal( int, int, int, char, char, char );
int  Unnep_e(int,int);
void Husvet_Punkosd(int ev);

enum {JANUAR, FEBRUAR, MARCIUS, APRILIS, MAJUS, JUNIUS, JULIUS,
       AUGUSZTUS, SZEPTEMBER, OKTOBER, NOVEMBER, DECEMBER};

struct Unnepnap {
	      int honap;
	      int nap;
	      };


static int    Ugras[ 12 ] =	{ 1, 4, 4, 0, 2, 5, 0, 3, 6, 1, 4, 6 };

static int    HonapNap[ 12 ] =	{ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

static char  *HonapNev[ 12 ] =  { "janu�r",   "febru�r",   "m�rcius",
				  "�prilis",  "m�jus",     "j�nius",
				  "j�lius",   "augusztus", "szeptember",
				  "okt�ber",  "november",  "december" };

static struct Unnepnap Unnep[] ={{0     ,    0},  /* H�sv�t */
				 {0     ,    0},
				 {0     ,    0},  /* P�nk�sd */
				 {0     ,    0},
				 {JANUAR,    1},
				 {MARCIUS,  15},
				 {MAJUS,     1},
				 {AUGUSZTUS,20},
				 {OKTOBER,  23},
				 {DECEMBER, 25},
				 {DECEMBER, 26}};

static char  *Nagy_fejlec =  { " H   K   Sz  Cs  P   Sz  V" };
static char  *Kis_fejlec  =  { "H  K  Sz Cs P  Sz  V" };

void Naptar( int, int, int, int, int, char *);
void Keret( int, int, int, int );
void Vonal( int, int, int, char, char, char );

void main(int argc, char * argv[])
{
    time_t			akt_ido;
    register struct tm		*datum,dat;

    clrscr();

    /* az aktu�lis d�tum lek�rdez�se */
    if (argc!=3)
     {
       akt_ido = time( NULL );
       datum = localtime( &akt_ido );
     }
     else
     {
       datum=&dat;
       dat.tm_year=atoi(argv[1])-1900;
       dat.tm_mon =atoi(argv[2])-1;
     }

    Husvet_Punkosd(datum->tm_year);

    /* az aktu�lis h�nap napt�ra */
    Naptar( datum->tm_mon, datum->tm_year, 5, 26, NAGY, Nagy_fejlec );

    /* az el�z� h�nap napt�ra */
    datum->tm_mon--;
    if( datum->tm_mon < 0 ) {
	    datum->tm_mon = 11;
    	datum->tm_year--;
    }
    Naptar( datum->tm_mon, datum->tm_year, 10, 3, KICSI, Kis_fejlec );

    /* a k�vetkez� h�nap napt�ra */
    datum->tm_mon += 2;
    if( datum->tm_mon > 11 ) {
	    datum->tm_mon -= 12;
	    datum->tm_year++;
    }
    Naptar( datum->tm_mon, datum->tm_year, 10, 56, KICSI, Kis_fejlec );

    PozKurzor( 22, 1 );
    getch();
}

/* Adott �v adott h�napj�hoz tartoz� napt�r megjelen�t�se */
void Naptar( int honap, int ev, int sor, int oszlop,
	     int szelesseg, char * fejlec )
{
    register int		kezdet;
    register int		napok;
    register int		keret_szelesseg;
    register char		*str;
    register int		i;

    textcolor(LIGHTGRAY);
    keret_szelesseg = 7 * szelesseg - 1;
    Keret( sor, oszlop, keret_szelesseg, 8 );
    str = HonapNev[ honap ];
    PozKurzor( sor - 1,
	       oszlop + 1 + ( keret_szelesseg - strlen( str ) - 5 ) / 2 );
    cprintf( "19%d. %s\n",ev, str );
    PozKurzor( sor + 1, oszlop + 1 );
    cprintf( fejlec );

    kezdet = ev + ev / 4 + Ugras[ honap ] + 6;
    if( ( ev % 4 == 0 ) && ( honap <= FEBRUAR ) ) {
	     --kezdet;
    }
    kezdet = kezdet % 7 + 1;

    if( ( ev % 4 == 0 ) && ( honap == FEBRUAR ) ) {
	    napok = 29;
    } else {
	    napok = HonapNap[ honap ];
    }

    sor += 3;
    for( i = 1; i <= napok; ++i ) {
	   PozKurzor( sor, oszlop + szelesseg * kezdet - 2 );
	  if (kezdet==7) textcolor(YELLOW);
	   else textcolor(WHITE);
	  if (Unnep_e(honap,i)) textcolor(LIGHTRED);

   cprintf( "%2d", i );
	 if( kezdet == 7 ) {
	     cprintf( "\n" );
	    ++sor;
	    kezdet = 1;
  	} else {
	    ++kezdet;
	}
    }
}

/* Keret rajzol�sa */
void Keret( int sor, int oszlop, int szelesseg, int magassag)
{
    register int		i;

    Vonal( sor    , oszlop, szelesseg, '�', '�', '�' );
    Vonal( sor + 1, oszlop, szelesseg, '�', ' ', '�' );
    Vonal( sor + 2, oszlop, szelesseg, '�', '�', '�' );
    for( i = 3; i <= magassag; ++i ) {
	Vonal( sor + i, oszlop, szelesseg, '�', ' ', '�' );
    }
    Vonal( sor + magassag + 1, oszlop, szelesseg, '�', '�', '�' );
}


/* A keret sorainak rajzol�s�hoz haszn�lt f�ggv�ny */
void Vonal( int sor, int oszlop, int szelesseg,
	    char bal, char kozep, char jobb )
{
    char			puffer[ 80 ];

    puffer[ 0 ] = bal;
    memset( &puffer[ 1 ], kozep, szelesseg );
    puffer[ szelesseg + 1 ] = jobb;
    puffer[ szelesseg + 2 ] = '\0';
    PozKurzor( sor, oszlop );
    cprintf( puffer );
}

int Unnep_e(int honap, int nap)
{
   int maxi=sizeof(Unnep)/sizeof(struct Unnepnap);
   int i;
   int ok=0;

   for (i=0; i<maxi; i++)
     if ((Unnep[i].honap==honap) && (Unnep[i].nap==nap)) ok=1;

   return ok;
}


void Husvet(int ev, int * honap, int * nap)
{
 int g,c,x,z,d,e;

 g = ev % 19 +1;
 c  = ev / 100 +1;
 x  = 3 * c /4 -12;
 z  = (8*c+5) / 25 -5;
 d  = 5 * ev /4 -x -10;
 e  = (11* g + 20 +z -x) % 30;

 if (e < 0) e+=30;
 if ((e==25) && (g>11) || (e==24)) e++;
 *nap = 44-e;

 if (*nap<21) *nap+=30;
 *nap = *nap+ 7-(d+*nap) % 7;

 if (*nap>31) {
		*nap-=31;
		*honap=4;
	     }
  else  *honap=3;

  (*honap)--;
}


void Husvet_Punkosd(int ev)
{
 int ho, nap;
 Husvet(1900+ev, &ho, &nap);

 /* H�sv�t */
 Unnep[0].honap=ho;
 Unnep[0].nap  =nap;
 Unnep[1]=Unnep[0];
 if ((nap+1)>HonapNap[ho])
  {
    Unnep[1].honap++;
    Unnep[1].nap=1;
  }
 else Unnep[1].nap++;

 /* P�nk�sd */
 nap+=49;
 if (nap>60)
   { nap-=HonapNap[ho]+HonapNap[ho+1];
     ho+=2;
   }
 else
    { nap-=HonapNap[ho];
      ho++;
    }
 Unnep[2].nap=nap;
 Unnep[2].honap=ho;
 Unnep[3]=Unnep[2];
 if ((nap+1)>HonapNap[ho])
  {
    Unnep[2].honap++;
    Unnep[2].nap=1;
  }
 else Unnep[2].nap++;

}
