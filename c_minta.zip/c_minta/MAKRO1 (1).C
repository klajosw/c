#include <stdio.h>
#include <stdlib.h>


#define EOS      '\0'		/* a sztringv�ge karakter */
#define TRUE     1
#define FALSE    0
#define BOOL     int
#define NOT      !
#define IGEN     1
#define NEM      !IGEN
#define URES			/* p�lda �res makr�ra */
#define STRING0   ""		/* �res sztring */
#define UDV       "�dv�z�llek dics� lovag ....!"
#define PMERET    1024
#define HA        if
#define KIIR      printf

main()
{
    BOOL *p=(BOOL *)malloc(sizeof(BOOL)*PMERET);
    KIIR(UDV);
    HA (NOT IGEN)
	KIIR("URES");  /* Sztringben nem v�gzi el a helyettes�t�t! */
    HA (NEM)
	KIIR(STRING0);
    free(p);
}


