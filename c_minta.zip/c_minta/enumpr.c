/* ENUMPR.C */
#include <stdio.h>

main()
{
 enum napok {hetfo, kedd, szerda,csutortok, pentek, szombat, vasarnap};
 enum napok ma;

  ma = vasarnap;
}