/* MERTANI.C */
#include <stdio.h>
#include <math.h>
int buff[] = { 0,0,0,0};

main()
{
 int index = 0;
 int ch;
 double mertani;
  printf("Sz�mok folyamatos g�pel�se\n");
  printf("Kil�p�s: Ctrl Z Enter\n");
  while (EOF != (ch = fgetc(stdin)))
  {
    if ('0' <= ch  &&  ch <= '9')
    {
      buff[index] = ch - '0';
      index = (index+1) % 4; /* rendre 0,1,2,3 lesz */
    }
  }
  mertani = sqrt(sqrt(buff[0]*buff[1]*buff[2]*buff[3]));
  printf("%d, %d, %d �s %d sz�mok m�rtani k�zepe: %12.5g\n",
	 buff[0], buff[1], buff[2], buff[3], mertani);
}
