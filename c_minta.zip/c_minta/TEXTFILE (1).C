#include <stdio.h>
#include <stdlib.h>

main()
{
    FILE * tf;
    int i, a;
    double sum, adat;

    tf = fopen("ADATOK.TXT", "wt");
    if (tf==NULL) {
       fprintf(stderr, "Sikertelen file-nyit�si kis�rlet!\n");
       exit(-1);
    }
    for (i=0; i<10; i++)
	fprintf(tf, "%4d,%10.8f\n", i, i*3.14159265);
    fflush(tf);
    fclose(tf);

    if (!(tf = fopen("adatok.txt", "rt"))) {
       fprintf(stderr, "Sikertelen file-nyit�si kis�rlet!\n");
       exit(-1);
    }
    sum = i = 0;
    while (!feof(tf)){
	  fscanf(tf,"%d,%lf\n", &a, &adat);
	  sum += adat;
	  i += a;
	  printf("%d. adatsor feldolgoz�sa megt�rt�nt!\n", a);
    }
    fclose(tf);

    printf("A %d db. PI �tlaga: %10.8f\n", i, sum/i);

}