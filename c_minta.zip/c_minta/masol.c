/* MASOL.C */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char filename[80],kifile[80];
int main(int argc, char *argv[])
{
FILE *finp,*fout;
int i1,i2;

  if (argc == 1)
   {
      printf("File name: "); scanf("%s",filename);
   }
   else
     strcpy(filename,argv[1]);

   finp = fopen(filename,"r");
   if (finp == NULL) { printf("File n�v nem l�tezik!\n"); exit(1); }
   i1=0;
   strcpy(kifile,filename);

   while(kifile[i1] && kifile[i1] != '.') i1++;
   if(kifile[i1]) kifile[i1]='\0';
   strcat(kifile,".out");

   fout = fopen(kifile,"w");
   if (fout == NULL) { printf("Hib�s nyit�s!\n"); exit(1);}
   i2 = fgetc(finp);
   while( i2 != EOF)
   {
     i2 = toupper(i2);
     fputc(i2,fout);
     i2 = fgetc(finp);
   }
   fclose(finp);
   fclose(fout);
 return 1;
}
