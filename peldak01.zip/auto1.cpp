// auto1.cpp: P�ldaprogram a C++ strukt�r�k bemutat�s�ra, G�pj�rm� oszt�ly
// Eddig jutottunk el az els� laboron.
// H�zi feladat: Kieg�sz�teni az oszt�lyt a GetAjto-SetAjto p�roshoz hasonl� f�ggv�nyekkel,
//               amelyek a t�bbi adatmez� el�r�s�t biztos�tj�k.


#include <iostream.h>

struct Gepjarmu
{
private:
	char*	rendszam;
	char*	tipus;
	int		ajtoszam;
	int		henger;
	int		ev;
	float	fogyasztas;
	int		suly;
	int		kilometerora;

public:
	Gepjarmu();
	Gepjarmu( int a, int h, int e, float f );

	void	SetAjto( int a ) { ajtoszam = a; }
	int		GetAjto() { return ajtoszam; }

};

Gepjarmu::Gepjarmu()
{
	rendszam = "";
	tipus = "";
	ajtoszam = 0;
	henger = ev = suly = kilometerora = 0;
	fogyasztas = 0.0;

};

Gepjarmu::Gepjarmu( int a, int h, int e, float f )
{
	rendszam = "";
	tipus = "";
	ajtoszam = a;
	henger = h;
	ev = e;
	suly = kilometerora = 0;
	fogyasztas = f;

};


void main()
{
	Gepjarmu g;
	Gepjarmu gj(3, 1600, 2000, 6.5);
	int a;

	cout << "Add meg az ajtok szamat: ";
	cin >> a;

	g.SetAjto(a);

	cout << "g auto parameterei:" << endl;

	cout << "Ajtoszam: " << g.GetAjto() << endl;

	cout << "gj auto parameterei:" << endl;

	cout << "Ajtoszam: " << gj.GetAjto() << endl;

}