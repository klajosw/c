// streamek.cpp : P�ldaprogram a streamek bemutat�s�ra


#include <iostream.h>
#include <iomanip.h>

int main(int argc, char* argv[])
{
  int number = 901;
  cout << setw(10) << setfill('#') << number << endl;
  cout << setw(6) << number << endl;
  cout << dec << number << endl;
  cout << hex << number << endl;
  cout << setw(12) << number << endl;
  cout << setw(16) << setfill('@') << number << endl;
  cout << "Text" << endl;
  cout << 123 << endl;
  cout << setw(8) << setfill('*') << "Text" << endl;
  double d1 = 3.141592;
  double d2 = 45.9876;
  double d3 = 123.9577;
  cout << "d1 is " << d1 << endl;
  cout << "setting precision 3 " << setprecision(3) << d1 << endl;
  cout << d2 << endl;
  cout << d3 << endl;
  cout << 4214.8968 << endl;
  return 0;
}
