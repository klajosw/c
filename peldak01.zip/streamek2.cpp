// streamek2.cpp : M�sodik p�ldaprogram a streamek bemutat�s�ra

#include <iostream.h>
#include <iomanip.h>

int main(int argc, char* argv[])
{
	int a = 123;
	float	f = 1.0e23;

	cout << "Hello Vilag!" << endl << endl;

	cout << "A= " << a << endl;
	cout << "F= " << f << endl;

	cout << setw(10) << f << setw(10) << f << endl;

unsigned int x = 10;

	cout << "Add meg x �rt�k�t: ";

	cin >> x;

	cout << "x= " << x << endl;;

	return 0;
}
