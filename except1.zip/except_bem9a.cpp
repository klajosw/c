#include <stdio.h>

// Transzform�l�s 1: Elkap�s ut�n m�sik kiv�tel dobhat� tov�bb

#define VALAMI_NAGY_BAJ -1

void F1(int X)
{
if(X < -1000) throw "Nagy baj 1";
if(X < -100)  throw "Nagy baj 2";
if(X < -10)   throw "Nagy baj 3";
}

void F2()
{
try{
  F1(-777);  
}
catch(char* x){
  printf("F2: elkaptam: %s\n",x);
  printf("Feldolgoztam, tovabbdobom\n");

  throw VALAMI_NAGY_BAJ;
}
}

int main()
{

try{
  F2();
}
catch(int x){
  printf("main: elkaptam: %d\n",x);

  if(x == VALAMI_NAGY_BAJ)
    printf("Valami nagy baj tortent\n");
}

return 0;
}
