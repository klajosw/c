#include <stdio.h>

// Kiv�telek bemutat�sa. 
// A kiv�tel t�pus�t meg tudjuk �llap�tani

void Dob1(int X)
{
if(X == 0) throw 122;
}

void Dob2(int X)
{
if(X == 0) throw "Baj van!";
}

int main()
{

try{
  Dob1(0);
}
catch(int){
  printf("int kivetel dobasa tortent\n");
}
catch(...){    // minden egy�b kiv�telt elkapunk
  printf("Egyeb kivetel dobasa tortent\n");
}

try{
  Dob2(0);
}
catch(char*){
  printf("char* kivetel dobasa tortent\n");
}
catch(...){    // minden egy�b kiv�telt elkapunk
  printf("Egyeb kivetel dobasa tortent\n");
}

return 0;
}
