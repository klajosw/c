#include <stdio.h>

// Kiv�telek bemutat�sa. 
// Kiv�telt sz�nd�kosan l�tre lehet hozni ('dob�s')

void Dob1(int X)
{
if(X == 0) throw 122;
}

void Dob2(int X)
{
if(X == 0) throw "Baj van!";
}

int main()
{

try{
  Dob1(0);
}
catch(...){    // minden kiv�telt elkapunk
  printf("Kivetel dobasa tortent\n");
}

try{
  Dob2(0);
}
catch(...){    // minden kiv�telt elkapunk
  printf("Kivetel dobasa tortent\n");
}

return 0;
}
