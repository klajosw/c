#include <stdio.h>

// A kiv�tel tov�bbdobhat�

void F1() { throw 42; }

void F2()
{
try{
  F1();  
}
catch(int x){
  printf("F2: elkaptam: %d\n",x);
  printf("Feldolgoztam, tovabbdobom\n");

  throw;
}
}

int main()
{

try{
  F2();
}
catch(int x){
  printf("main: elkaptam: %d\n",x);
}

return 0;
}
