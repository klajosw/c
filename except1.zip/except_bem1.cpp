#include <stdio.h>

// Kiv�telek bemutat�sa. Kiv�tel keletkez�se.

int main()
{
int x,y;

try{
  y = 0;
  x = 1 / y;
}
catch(...){    // minden kiv�telt elkapunk
  printf("Kivetel dobasa tortent\n");
}

return 0;
}
