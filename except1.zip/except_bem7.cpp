#include<stdio.h>

// A kiv�telek �gy m�k�dnek, mint a return.

class A{
public:
  A()  { printf("A::A()\n");  }
  ~A() { printf("~A::A()\n"); }
};

void f(int X)
{
A a;

if(X == 1){
  printf("Kivetelt dobok\n");
  throw 1;
}

printf("Nem dobtam kivetelt\n");
}

void main()
{
f(0);

printf("-------\n");

try{
  f(1);
}
catch(...) {}

printf("Mindig lefut A::~A()!\n");
} 
