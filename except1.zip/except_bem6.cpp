#include <stdio.h>
#include <string.h>

// Kiv�telek bemutat�sa. 
// A kiv�tel objektum is lehet

class MyException{
public:

  MyException(char* RSz,char*HSz);
  char  RovidSzoveg[30];
  char  HosszuSzoveg[100];
};

MyException::MyException(char* RSz,char*HSz)
{
strcpy(RovidSzoveg,RSz);
strcpy(HosszuSzoveg,HSz);
}

void Dob(int X)
{
if(X <= 0)  throw MyException("X <= 0","Ajjaj, nagy baj van");
}

int main()
{

try{
  Dob(0);
}
catch(MyException k){
  printf("MyException kivetel dobasa tortent\n");
  printf("Rovid szoveg: %s Hosszu szoveg: %s\n",k.RovidSzoveg,k.HosszuSzoveg);
}
catch(...){    // minden egy�b kiv�telt elkapunk
  printf("Egyeb kivetel dobasa tortent\n");
}

return 0;
}
