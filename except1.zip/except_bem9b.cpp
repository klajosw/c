#include <stdio.h>

// Transzform�l�s 2: Elkap�s ut�n hibak�dot adunk vissza

#define VALAMI_NAGY_BAJ -1

void F1(int X)
{
if(X < -1000) throw "Nagy baj 1";
if(X < -100)  throw "Nagy baj 2";
if(X < -10)   throw "Nagy baj 3";
}

int F2()
{
try{
  F1(-777);  
}
catch(char* x){
  printf("F2: elkaptam: %s\n",x);
  printf("Feldolgoztam\n");

  return VALAMI_NAGY_BAJ;
}

return 0;
}

int main()
{
int rc;

rc = F2();
 
printf("main: F2 visszatero erteke: %d\n",rc);

if(rc == VALAMI_NAGY_BAJ)
  printf("Valami nagy baj tortent\n");

return 0;
}
