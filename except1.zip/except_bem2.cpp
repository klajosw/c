#include <stdio.h>

// Kiv�telek bemutat�sa. 
// A kiv�tel addig terjed, m�g el nem kapjuk.

void KiveteltDob()
{
int x,y;

y = 0; x = 1 / y;
}

void F()
{
KiveteltDob();
}

int main()
{

try{
  KiveteltDob();
}
catch(...){    // minden kiv�telt elkapunk
  printf("Kivetel dobasa tortent\n");
}

try{
  F();
}
catch(...){    // minden kiv�telt elkapunk
  printf("Kivetel dobasa tortent\n");
}

return 0;
}
