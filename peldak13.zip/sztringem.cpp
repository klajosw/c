#include	<string.h>
#include	<iostream.h>

class Sztringem {
public:
  Sztringem() { puffer = NULL; meret = 0; }
  ~Sztringem();
  Sztringem( Sztringem& Masik );
  Sztringem& operator=( Sztringem& Masik );
  
  void Beolvas();
  void Kiir();

private:
  void Masol( Sztringem& Masik );

  char* puffer;  // tulajdon
  int meret;
};

Sztringem::~Sztringem()
{
	delete[] puffer;
	puffer = NULL;
	meret = 0;
}

Sztringem::Sztringem( Sztringem& Masik )
{
	puffer = NULL;
	meret = 0;
	Masol( Masik );
}

Sztringem& Sztringem::operator =( Sztringem& Masik )
{
	Masol( Masik );
	return *this;
}

void Sztringem::Masol( Sztringem& Masik )
{
  if ( this == &Masik ) return;  // ne m�soljunk saj�t mag�ra!
  int l;
  if ( Masik.meret == 0 ) 
     l = 0;
  else
     l = strlen( Masik.puffer );
     
  if ( meret > l ) {
     strcpy( puffer, Masik.puffer );
     return;
  }
  delete[] puffer;
  puffer = NULL;
  meret = 0;
  puffer = new char[l+1];  // lehetne t�bbet is foglalni!
  meret = l+1;
  strcpy( puffer, Masik.puffer );
}

void Sztringem::Kiir()
{
	cout << "Puffer: " << puffer << endl;
}

void Sztringem::Beolvas()
{
	char szoveg[200];
	int len;

	cout << "Mit tegyek a pufferbe: ";
	cin >> szoveg;

	len = strlen(szoveg);

	if ( meret < len )
	{
		delete[] puffer;
		puffer = new char[len+1];
		meret = len+1;
	}

	strcpy( puffer, szoveg );
}	// end of Beolvas


int main()
{
	Sztringem	sz1, sz3;

	cout << "sz1 feltoltese!" << endl;

	sz1.Beolvas();
	sz1.Kiir();

	cout << "sz1 atmasolasa sz2-be masolo konstruktorral!" << endl;

	Sztringem	sz2 = sz1;
	sz2.Kiir();

	cout << "sz1 atmasolasa sz3-ba ertekadas operatorral!" << endl;

	sz3 = sz1;
	sz3.Kiir();

	return 0;
}

