/*
class Vektor {
  public:
    Vektor( double xx, double yy ) { x = xx; y = yy; };
    Vektor( double r, double fi );		// ERROR megegyezik a szignatura!!!

  private:
    double x, y;
}
*/

#include	<math.h>

class Vektor {
  public:
    Vektor() { x = y = 0; }
    Vektor( double xx, double yy ) { x = xx; y = yy; };
    static Vektor * Polarkonst( double r, double fi );

  private:
    double x, y;
};

Vektor * Vektor::Polarkonst( double r, double fi )
{
  Vektor* vp;
  vp = new Vektor;
  vp->x = r * cos( fi );
  vp->y = r * sin( fi );
  return vp;
};


int main() 
{
  Vektor * vp1;  

  vp1 = Vektor::Polarkonst( 3, 0.5 );

  return 0;
};

