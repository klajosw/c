#include	<iostream.h>

class Valami {
  public:

    int x;
};

int main()
{
  Valami v1, v2;
  
  v1.x = 15;
  
  v2 = v1;	// helyes-e? IGEN bitr�l-bitre lem�solja az objektumot

  cout << "Masolas utan" << endl;
  cout << "v1.x = " << v1.x << endl;
  cout << "v2.x = " << v2.x << endl;

  v1.x = 100;

  cout << "v1 modositasa utan" << endl;
  cout << "v1.x = " << v1.x << endl;
  cout << "v2.x = " << v2.x << endl;

  return 0;
}