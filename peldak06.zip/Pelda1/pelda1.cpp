class Valami {
  public:
    Valami() { x = 0; }
    
    void f( Valami & masik );
    
    void SetX( int xx ) { x = xx; }

  private:
    int x;
};

void Valami::f( Valami & masik )
{
  masik.x = 2 * x;		// helyes-e? 
};

int main()
{
  Valami v1, v2;
  v1.SetX( 15 );
  v1.f( v2 );
  // v2.x = 30
  return 0;
};

