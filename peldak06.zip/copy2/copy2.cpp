#include	<string.h>
#include	<iostream.h>

class X {
  public:
    X() { Nev = NULL; }
    ~X() { delete[] Nev; }
    
    char * Nev;	// tulajdona az objektumnak

  private:
//	  X& operator= (X& masik);   // ha kiveszem a kommentb�l, akkor megtiltom az �rt�kad�st
};

int main()
{
  X	x1, x2;
  
  x1.Nev = new char[20];
  strcpy( x1.Nev, "Sopron" );
  
  x2 = x1;
  
  cout << "Masolas utan" << endl;
  cout << "x1.Nev = " << x1.Nev << endl;
  cout << "x2.Nev = " << x2.Nev << endl;

  strcpy( x1.Nev, "Szombathely" );
  
  cout << "x1 modositas utan" << endl;
  cout << "x1.Nev = " << x1.Nev << endl;
  cout << "x2.Nev = " << x2.Nev << endl;

  cout << endl << "Mit mutat ez az eredmeny?" << endl;
  cout << endl << "Miert szall el a program?" << endl;


//  delete[] x1.Nev;	// NE! De en�lk�l is elsz�ll a program, Mi�rt?
  return 0;
}

