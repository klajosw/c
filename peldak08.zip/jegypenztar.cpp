#include	<stdio.h>

class Szemely {
  public:
    virtual int JegyetFizet( int jegyar ) { return jegyar; }
};

class Diak : public Szemely {
  public:
    virtual int JegyetFizet( int Jegyar ) { return Jegyar / 2; }
};

// Kliens f�ggv�ny:

void Jegypenztar( Szemely & sz )
{
  int fizetett;
  fizetett = sz.JegyetFizet( 1000 );
  printf("Fizetett: %d\n", fizetett );
};

int main()
{
  Szemely sz;
  Jegypenztar( sz );		// Fizetett: 1000
  
  Diak d;
  Jegypenztar( d );		// Fizetett: 500

  return 0;
}
