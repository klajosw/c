#include	<stdio.h>

class Szemely {
  public:
    virtual void Koszon();
};

void Szemely::Koszon()
{
  printf("Jo napot!\n");
};

class Diak : public Szemely {
  public:
    virtual void Koszon();
};

void Diak::Koszon()
{
  printf("Jo szerencset!\n");
};

int main()
{
  Szemely sz;
  Diak d;

  sz.Koszon();	// Jo napot!
  d.Koszon();	// Jo szerencset!
  return 0;
};