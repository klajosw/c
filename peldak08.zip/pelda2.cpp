#include	<stdio.h>

class Szemely {
  public:
    virtual void Koszon();
};

void Szemely::Koszon()
{
  printf("Jo napot!\n");
};

class Diak : public Szemely {
  public:
    virtual void Koszon();
};

void Diak::Koszon()
{
	Szemely::Koszon();
	printf("Jo szerencset!\n");
};

int main()
{
  Szemely sz;
  Diak d;

  sz.Koszon();	// Jo napot!
  d.Koszon();	// Jo napot!
				// Jo szerencset!
  // d.Szemely.Koszon();  // Ez nem m�k�dik
  Szemely(d).Koszon();

  return 0;
};