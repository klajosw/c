#include	<stdio.h>

class Szemely {
  public:
    virtual void Koszon() { printf("Jo napot!\n"); };
};

class Diak : public Szemely {
  public:
    virtual void Koszon() { printf("Jo szerencset!\n"); };
};

void f1( Szemely &sz)
{
  printf("f1: ");
  sz.Koszon();
};

void f2(Szemely* szp)
{
  printf("f2: ");
  szp->Koszon();
}

void f3( Szemely sz )
{
  printf("f3: ");
  sz.Koszon();
}


void f4( Diak & d )
{
  printf("f4: ");
  d.Koszon();
}

int main()
{
  Szemely sz;
  printf( "Szemely\n" );
  f1( sz );		// Jo napot!
  f2( &sz );
  f3( sz );
//  f4( sz );	// Ez hiba!
  
  printf( "\nDiak\n" );
  Diak d;
  f1( d );		// ez is helyes, mert minden di�k szem�ly, ez a polimorfizmus l�nyege!
  				// azt �rja ki, hogy Jo szerencset!
  f2( &d );
  f3( d );
  f4( d );
  
  return 0;
};
