#include	<stdio.h>

class Szemely {
  public:
    virtual void Koszon() = 0;
};

class MagyarSzemely : public Szemely {
  public:
    virtual void Koszon() { printf("Jo napot!\n"); };
};
  
class AngolSzemely : public Szemely {
  public:
    virtual void Koszon() { printf("Hello!\n"); };
};

void f( Szemely & sz )	// itt lehet absztrakt oszt�ly
{
  sz.Koszon();
};

int main()
{
//  Szemely sz;	// Hiba!!!
  MagyarSzemely m;	// helyes, mert a Szemely �sszes tiszt�n virtu�lis f�ggv�ny�t implement�ltam
  					//         a MagyarSzemelyben
  AngolSzemely a;	// helyes,  -- " --
  					//         az Angolszemelyben

  f( m );
  f( a );
  return 0;
};

