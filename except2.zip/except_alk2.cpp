#include<stdio.h>

// try-catch haszn�lata
// hib�s param�terek kiv�d�se
// El�sz�r try n�lk�l.

int EnFuggvenyem(char *TeAdatod)
{
if(TeAdatod == NULL){
  printf("Velem nem szursz ki!\n");
  return -1;
}

*TeAdatod = '\0';

return 0;
}

void main()
{
int  rc;
char *p;

p = NULL;
rc = EnFuggvenyem(p);
printf("rc: %d\n",rc);

p++;          // dehogynem sz�rok...

rc = EnFuggvenyem(p);
printf("rc: %d\n",rc);

p = "ABCDE"; // vagy ak�r �gy is...
rc = EnFuggvenyem(p);
printf("rc: %d\n",rc);
} 
