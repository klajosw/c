#include <stdio.h>

// A f�ggv�ny tervezetten kiv�tellel jelez valamilyen rendk�v�li esem�nyt

void F(int X)
{
if(X < 0) throw("Negativ");
}

int main()
{

try{
  F(-3);
}
catch(...){
  printf("Dobott!\n");
}

return 0;
}
