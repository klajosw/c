#include<stdio.h>

// try-catch haszn�lata
// ha nem b�zunk a visszat�r� �rt�keink
// lekezel�s�ben �s nagy baj van.

#define MALLOC_HIBA  -10

int EnFuggvenyem1()
{
char *p;

p = new char[100];
p = NULL; // szimul�ljuk a hib�t
if(p == NULL) throw MALLOC_HIBA;

return 0;
}

int EnFuggvenyem2(int Param)
{
int allapot;

if(Param < 0)
  allapot = 1;
else
  if(Param < 10)
    allapot = 2;
  else
    allapot = 3;

switch(allapot){  // csak 1 vagy 2 lehet
  case 1:
  case 2:
    printf("Valami muvelet\n");
  break;
  default:        // programhiba
    throw -5472;
  break;
}

return 0;
}

void TeFuggvenyed()
{
//...
EnFuggvenyem1();   // nem k�rdezi le a visszat�r� �rt�ket

EnFuggvenyem2(20); // itt sem

}

//--------------


void main()
{
try{
  TeFuggvenyed();
}
catch(int hibakod){
  switch(hibakod){
    case MALLOC_HIBA:
      printf("malloc (new) nem sikerult\n");
    break;
    default:
      printf("Hibakod: %d\n",hibakod);
    break;
  }
}
catch(...){
  printf("Nem int kivetelt kaptam el.\n");
}

} 
