#include<stdio.h>

// Csomagol� (wrapper) f�ggv�nyek 1.
// K�ls� hibajelz�sek lek�pez�se saj�t hibak�dokra

void DBHozzaRendeles(char *Utvonal)  // k�ls� f�ggv�ny (m�s �rta)
{
throw "Ki tudja, mit dob ez";
}

void DBNyitas()                      // k�ls� f�ggv�ny
{
throw "Vagy ez";
}

//--------------

#define DB_NYITAS_HIBA -101

int DBNyitas_Csomagolo(char *Utvonal) // saj�t f�ggv�ny
{
try{
  DBHozzaRendeles(Utvonal);
  DBNyitas();
}

catch(...){
  return DB_NYITAS_HIBA;
}

return 0;
}

int main()
{
int rc;

rc = DBNyitas_Csomagolo("C:\\mydb.mdb");
printf("rc: %d\n",rc);

return 0;
} 
