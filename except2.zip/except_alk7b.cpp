#include<stdio.h>

// Csomagol� (wrapper) f�ggv�nyek 2.
// K�ls� hibajelz�sek lek�pez�se saj�t kiv�telre

void DBHozzaRendeles(char *Utvonal)  // k�ls� f�ggv�ny (m�s �rta)
{
throw "Ki tudja, mit dob ez";
}

void DBNyitas()                      // k�ls� f�ggv�ny
{
throw "Vagy ez";
}

//--------------

#define DB_NYITAS_HIBA -101

void DBNyitas_Csomagolo(char *Utvonal) // saj�t f�ggv�ny
{
try{
  DBHozzaRendeles(Utvonal);
  DBNyitas();
}
catch(...){
  throw DB_NYITAS_HIBA;
}
}

int main()
{
int hibakod;

try{
  DBNyitas_Csomagolo("C:\\mydb.mdb");
}
catch(int x){
  hibakod = x;
}
catch(...){
  printf("Varatlan kivetel\n");
  hibakod = -1000;
}

if(hibakod == 0)
  printf("Rendben\n");
else
  printf("Valami baj tortent (%d)\n",hibakod);

return 0;
} 
