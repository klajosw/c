#include <stdio.h>
#include <math.h>

// Kiv�telek haszn�lata. A f�ggv�nybe nem �p�tettek be
// hibajelz�s-csatorn�t �s ut�lag nem akarjuk m�dos�tani
// a fel�let�t.

/*
Eredetileg:

void Gyok(double& Par) { Par = sqrt(Par); }

*/

#define GYOKVONAS_HIBA -1234

void Gyok(double& Par)
{
if(Par >= 0)  Par = sqrt(Par);
else          throw GYOKVONAS_HIBA;
}

int main()
{
double d;

try{
  d = -5;
  Gyok(d);
}
catch(int x){
  if(x == GYOKVONAS_HIBA)
    printf("Gyokvonas hiba tortent\n");
  else
    printf("int kivetel: %d\n",x);
}
catch(...){
  printf("Egyeb kivetel\n");
}

return 0;
}
