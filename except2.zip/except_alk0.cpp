#include<stdio.h>

// kiv�telek alkalmaz�sa: saj�t programhiba jelz�se

class ProgramHiba{
public:
  ProgramHiba(int K) { Kod = K; }

  int Kod;
};

void f(int Par)
{
switch(Par){
  case 1:
    printf("Csinalunk valamit\n");
  break;
  case 2:
    printf("Itt is\n");
  break;
  default:  // programhiba
    throw ProgramHiba(-1234);
  break;
}
}

int main()
{
try{
  f(3);
}
catch(ProgramHiba& p){
  printf("Programhiba %d\n",p.Kod);
}
catch(...){
  printf("Egyeb kivetel\n");
}


return 0;
} 
