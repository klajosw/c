#include<stdio.h>

// try-catch haszn�lata
// hib�s param�terek kiv�d�se

int EnFuggvenyem(char *TeAdatod)
{
try{
  *TeAdatod = '\0';
  return 0;
}
catch(...){
  printf("Mondom, hogy nem szursz ki velem!\n");
  return -1;
}
}

void main()
{
int  rc;
char *p;

p = NULL;     // bosszantsuk �gy...
rc = EnFuggvenyem(p);
printf("rc: %d\n",rc);

p++;          // vagy �gy...
rc = EnFuggvenyem(p);
printf("rc: %d\n",rc);

p = "ABCDE";  // esetleg �gy...
rc = EnFuggvenyem(p);
printf("rc: %d\n",rc);

printf("Hat ez tenyleg jol birja a strapat!\n");
} 
