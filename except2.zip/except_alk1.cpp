#include<stdio.h>

// try-catch haszn�lata
// k�ls� programok hib�inak vagy
// hib�s haszn�lat�nak kontroll�l�sa

void MasEmberFuggvenye()
{
int x,y;

x = 0;
y = 1 / x;
}

void main()
{
try{
  MasEmberFuggvenye();
}
catch(...){                    // minden kiv�telt elkapunk
  printf("Ejnye, MasEmber.\n");
}

} 
