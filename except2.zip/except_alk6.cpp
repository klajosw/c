#include<stdio.h>
#include<string.h>

// A kiv�telben inform�ci�kat tov�bb�tunk

class MyException{
public:
  MyException();

  int   HibaKod;
  char  HibaUzenet[100];  // ezt lehet megmutatni a felhaszn�l�nak a k�perny�n
  char  LogUzenet[200];   // ezt jegyezz�k fel hibakeres�shez
};

MyException::MyException()
{
HibaKod = 0;
HibaUzenet[0] = 0;
LogUzenet[0] = 0;
}

void DBMegnyit(char* Utvonal)
{
if(true){    // Hib�t szimul�lunk
  MyException e;

  e.HibaKod = -15;
  strcpy(e.HibaUzenet,"DB nyitas sikertelen");
  sprintf(e.LogUzenet,"DB nyitas hiba, utvonal: %s",Utvonal);

  throw e;
}    

}

int main()
{

try{
  DBMegnyit("C:\\x\\MyDB");
}
catch(MyException& e){
  printf("MyException-t kaptam el\n");
  printf("Hibakod: %d Hibauzenet: %s\n",e.HibaKod,e.HibaUzenet);
  printf("Ezt fogom a log fajlba irni: %s\n",e.LogUzenet);
}
catch(...){
  printf("Egyeb kivetel\n");
}

return 0;
} 
