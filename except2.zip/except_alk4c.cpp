#include<stdio.h>

// Kiv�tel alkalmaz�sa: katasztrof�lis hib�k megk�l�nb�ztet�se az enyh�bbekt�l

int F1(int Par)
{
if(Par <= 0) return -1;    // hib�s param�ter

char* p;

p = new char[Par];
p = NULL;                  // szimul�ljuk a hib�t

if(p == NULL) throw -1;    // katasztr�fa

//...

return 0;
}

int F2()   // kiv�tel alkalmaz�sa n�lk�l
{
char* p;

p = new char[10];

p = NULL;                    // szimul�ljuk a hib�t

if(p == NULL) return -1001;  // katasztr�fa

return 0;
}

int main()
{
int rc;

try{
  rc = F1(10);
  if(rc != 0) printf("Valami problema van\n");
}
catch(...){
  printf("Oriasi baj van\n");
}

// Kiv�tel alkalmaz�sa n�lk�l:

rc = F2();
if(rc != 0)
  if(rc < -1000) printf("Oriasi baj van\n");
  else           printf("Valami problema van\n");

return 0;
}
