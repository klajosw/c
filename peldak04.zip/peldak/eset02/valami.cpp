#include <stdio.h>

class Valami
{
public:
	int X;

	Valami() 
	{ 
		printf("Valami-Konstruktor\n"); 
	}

	~Valami() 
	{ 
		printf("Valami-Destruktor\n"); 
	}
};

