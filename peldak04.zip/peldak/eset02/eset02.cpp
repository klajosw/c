#include	"valami.cpp"

void main()
{
  Valami v, *vp;

  v.X = 7;
  vp = &v;
  delete vp;   // formailag helyes, de hib�s, nem new-val foglalt ter�letet szabad�t fel!!!
}
