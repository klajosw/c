#include  <stdio.h>

class Tag{
public:
  Tag() { printf("Tag::Tag\n"); }
};

class Valami{
public:
  Valami() { printf("Valami::Valami\n"); }
  Tag  t;
};

int main(int argc, char* argv[])
{
	Valami v[2], *vp;
	return 0;
}
