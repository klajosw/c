#include	"tag3.cpp"

class Valami3{
public:
	Valami3() { printf("Valami3::Valami3\n"); }

	Tag3   t;
};
