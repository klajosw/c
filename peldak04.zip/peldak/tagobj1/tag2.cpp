#include	<stdio.h>

class Tag2{
public:
  Tag2(int x) { printf("Tag2::Tag2(x)\n"); }
};
