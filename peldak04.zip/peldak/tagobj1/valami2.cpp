#include	"tag2.cpp"

class Valami2{
public:
  Tag2  t;
};
