#include	<stdio.h>

class Tag3{
public:
  Tag3() { printf("Tag3::Tag3\n"); }
};
