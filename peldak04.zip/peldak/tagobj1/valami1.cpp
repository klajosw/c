#include	"tag1.cpp"

class Valami1{
public:
  Tag1  t;
};
