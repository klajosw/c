#include	<stdio.h>

class Tag1{
public:
  Tag1() { printf("Tag1::Tag1\n"); }
};
