#include	"valami1.cpp"
#include	"valami2.cpp"
#include	"valami3.cpp"

int main()
{
//  Valami1 v;		// Ki�rja: Tag1::Tag1
  
//  Valami2 v;		// Hi�nyzik a megfelel� konstruktor
  
	Valami3 v;
  
  return 0;
}
