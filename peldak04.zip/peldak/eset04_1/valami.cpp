#include <stdio.h>

class Valami
{
public:
	int X;
	double D;

	Valami() 
	{ 
		printf("Valami-Konstruktor\n"); 
	}

	~Valami() 
	{ 
		printf("Valami-Destruktor\n"); 
	}
};

