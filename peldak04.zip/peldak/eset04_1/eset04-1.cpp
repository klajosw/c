#include	<iostream.h>
#include	"valami.cpp"

void main()
{
  Valami v, *vp, vt[10], *vpt[10];

  cout << "sizeof(v)= " << sizeof(v) << endl;
  cout << "sizeof(Valami)= " << sizeof(Valami) << endl;
  cout << "sizeof(int)= " << sizeof(int) << endl;
  cout << "sizeof(double)= " << sizeof(double) << endl;
  cout << "sizeof(vp)= " << sizeof(vp) << endl;
  cout << "sizeof(vt)= " << sizeof(vt) << endl;
  cout << "sizeof(vpt)= " << sizeof(vpt) << endl;

}
