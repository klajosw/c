#include	<iostream.h>

void fv1( int ertek, int& ref )
{
	ertek++;
	ref++;
}


int main()
{
	int	i = 0;
	int j = 0;

	fv1( i, j );

	cout << "i = " << i << endl;
	cout << "j = " << j << endl;

	return 0;
}