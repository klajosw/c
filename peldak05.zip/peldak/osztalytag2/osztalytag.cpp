#include	<iostream.h>

class Szamlalo2
{
public:	
	static int db;
	int sorszam;
	
	Szamlalo2()
	{ 
		db++; 
		sorszam = db;
	};

	~Szamlalo2()
	{ db--; };

};

int	Szamlalo2::db = 0;

void main()
{
	Szamlalo2	sz1;
	cout << "sz1 = " << sz1.sorszam << endl;
	
	Szamlalo2	sz2;
	cout << "sz2 = " << sz2.sorszam << endl;

	Szamlalo2	szt[10];
	cout << "szt[0] = " << szt[0].sorszam << endl;
	cout << "szt[9] = " << szt[9].sorszam << endl;

	Szamlalo2	*szp;

	szp = new Szamlalo2;
	cout << "szp = " << szp->sorszam << endl;

	delete szp;


}

