#include	<iostream.h>

class Szamlalo
{
public:	
	static int db;
	
	Szamlalo()
	{ db++; };

	~Szamlalo()
	{ db--; };

};

int	Szamlalo::db = 0;

void main()
{
	Szamlalo	sz1;
	cout << "darab = " << Szamlalo.db << endl;
	
	Szamlalo	sz2;
	cout << "darab = " << Szamlalo.db << endl;

	Szamlalo	szt[10];
	cout << "darab = " << Szamlalo.db << endl;

	Szamlalo	*szp;

	cout << "darab new elott = " << Szamlalo.db << endl;
	szp = new Szamlalo;
	cout << "darab new utan = " << Szamlalo.db << endl;

	delete szp;

	cout << "darab delete utan = " << Szamlalo.db << endl;

}

