#include	<stdio.h>

class Valami{
public:
  Valami() { printf( "Valami alap konstruktor\n"); X = 0; }
  Valami( Valami& Masik );	// m�sol� konstruktor, l�trehoz egy m�solatot
  Valami& operator=( Valami& Masik );	// �rt�kad� oper�tor

  int X;
};


Valami::Valami( Valami& Masik )
{
 X = Masik.X;
 printf( "Valami masolo konstruktor\n" );
}

Valami& Valami::operator=( Valami& Masik )
{
  X = Masik.X;
  printf( "Valami ertekadas\n" );

  return *this;
}

int main()
{
  Valami v1;	// Valami alap konstruktor
  Valami v2(v1);	// Valami masolo konstruktor
  Valami* vp = new Valami(v1);	// Valami masolo konstruktor
  v2 = v1;		// Valami ertekadas
  Valami v3 = v1;	// Valami masolo konstruktor

  return 0;
}
